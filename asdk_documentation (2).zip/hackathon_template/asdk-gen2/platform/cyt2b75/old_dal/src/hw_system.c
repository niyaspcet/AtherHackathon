/*
  @file
  hw_system.c

  @path
  /frdmkw36_driver_examples_i2c_edma_transfer/source/hw_system.c

  @Created on
  Jan 18, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
	System level APIs for initializing clocks and pins, system reset,
	relocate vector table, get reset reason, set power mode...etc.
*/

/*
	Note:

	Core CM4 is used for running ASDK as of this release. CM0+ core is
	used for just enabling CM4 and nothing else.
*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/

/* ASDK includes */
#include "errordef.h"

/* DAL includes */
#include "hw_system.h"
#include "clock_config.h"

/* extern declarations */
extern void Cy_SamplePortPinInit(void);

/* Private functions */
static cy_en_sysclk_status_t set_peripheral_fracdiv24_5(uint64_t targetFreq, uint64_t sourceFreq, uint8_t divNum)
{
    cy_en_sysclk_status_t cy_status = CY_SYSCLK_SUCCESS;
    
    uint64_t temp = ((uint64_t)sourceFreq << 5ull);
    uint32_t divSetting;

    divSetting = (uint32_t)(temp / targetFreq);
    cy_status = Cy_SysClk_PeriphSetFracDivider(CY_SYSCLK_DIV_24_5_BIT, divNum, 
                                   (((divSetting >> 5u) & 0x00000FFFul) - 1ul), 
                                   (divSetting & 0x0000001Ful));
    
    return cy_status;
}

static cy_en_sysclk_status_t set_fractional_clock(cyt2b75_fractional_divider_t frac_div)
{
  cy_en_sysclk_status_t cy_status = CY_SYSCLK_SUCCESS;
  
  if (frac_div.frac_type_is_freq)
  {
    
    switch (frac_div.frac_div_type)
    {
      case CY_SYSCLK_DIV_24_5_BIT:
        cy_status = set_peripheral_fracdiv24_5(frac_div.frac_as.freq.target_freq,
                                  frac_div.frac_as.freq.source_freq,
                                  frac_div.frac_div_no);  
        break;
        
      default:
        cy_status = CY_SYSCLK_INVALID_STATE;
        break;
    }
  }
  else
  {
    cy_status = Cy_SysClk_PeriphSetFracDivider(frac_div.frac_div_type,
                                   frac_div.frac_div_no,
                                   frac_div.frac_as.value.int_part,
                                   frac_div.frac_as.value.frac_part);
  }
  
  return cy_status;
}

static bool initialize_peripheral_clocks ( void )
{
  cy_en_sysclk_status_t cy_status = CY_SYSCLK_SUCCESS;
  cyt2b7_divider_t divider;
  bool status = true;
  
  // todo: initialize all clocks here
  // includes:
  // oscillator, pll, rtc, system clk, 
  // peripheral clocks, low power clocks
  // debug trace clocks, clock-gating enable/disable
  
  for (uint8_t i=0; i<peripheral_clock_config_size; i++)
  {
    cy_status = Cy_SysClk_PeriphAssignDivider(peripheral_clock_config[i].clk_src,
                                  peripheral_clock_config[i].cy_divider_type,
                                  peripheral_clock_config[i].divider_no);
    
    if (cy_status == CY_SYSCLK_SUCCESS)
    {
      divider = peripheral_clock_config[i].divider;

      switch (divider.div_as)
      {
        case CYT2B75_DIV_AS_FRACTIONAL:
          cy_status = set_fractional_clock(divider.frac_div);
          break;
        
        case CYT2B75_DIV_AS_INTEGER:
          cy_status = Cy_SysClk_PeriphSetDivider(peripheral_clock_config[i].cy_divider_type,
                                                 peripheral_clock_config[i].divider_no,
                                                 divider.div_value);
          break;
        
        default :
          cy_status = CY_SYSCLK_BAD_PARAM;
          break;
      }
    }

    if (cy_status == CY_SYSCLK_SUCCESS)
    {    
      cy_status = Cy_SysClk_PeriphEnableDivider(peripheral_clock_config[i].cy_divider_type,
                                                peripheral_clock_config[i].divider_no);
    }
    
    // error in setting peripheral clocks
    if (cy_status != CY_SYSCLK_SUCCESS)
    {
      status = false;
      break;
    }
  }
  
  return status;
}

/*----------------------------------------------------------------------------*/
/* Function : sys_init_default */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initialize system clock for kw36 MCU and its peripheral to default value.

  @param void

  @return asdk_status_t

*/
asdk_status_t sys_init_default ( void )
{
  /* variable to hold Error code value */
  asdk_sys_ec_t error_code = ASDK_SYS_SUCCESS;
  bool pclock_status = false;
  
  // todo: validate if this is the right place
  __enable_irq();
  
  /* CYT2B7 SDL system init */ 
  SystemInit();
  
  // enabling CM4 core is not required as we are running on CM4
  // Cy_SysEnableApplCore(CY_CORTEX_M4_APPL_ADDR);
    
  pclock_status = initialize_peripheral_clocks();
  if ( pclock_status == false )
  {
	error_code = ASDK_SYS_ERROR;
	return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
  }

  // from Generated_Code\pin_mux.c
  Cy_SamplePortPinInit();

  return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);

}/* sys_init_default */

/*----------------------------------------------------------------------------*/
/* Function : sys_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initialize system clock for kw36 MCU and its peripheral to config value.

  @param const asdk_sys_cfg_t *config

  @return asdk_status_t

*/
asdk_status_t sys_init ( const asdk_sys_cfg_t *config  )
{
  /* variable to hold Error code value */
  asdk_sys_ec_t error_code = ASDK_SYS_SUCCESS;
  bool pclock_status = false;
  
  // todo: validate if this is the right place
  __enable_irq();
  
  /* CYT2B7 SDL system init */ 
  SystemInit();
  
  // enabling CM4 core is not required as we are running on CM4
  // Cy_SysEnableApplCore(CY_CORTEX_M4_APPL_ADDR);
    
  pclock_status = initialize_peripheral_clocks();
  if ( pclock_status == false )
  {
	error_code = ASDK_SYS_ERROR;
	return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
  }

  // from Generated_Code\pin_mux.c
  Cy_SamplePortPinInit();

  return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
}/* sys_init */

/*----------------------------------------------------------------------------*/
/* Function : sys_get_state */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets system status .

  @param asdk_sys_st_t *state

  @return asdk_status_t

*/
asdk_status_t sys_get_state ( asdk_sys_st_t *state )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;
	(void)state ;

    error_code = ASDK_SYS_ERROR;
    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);

}/* sys_get_state */

/*----------------------------------------------------------------------------*/
/* Function : sys_sw_reset */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function restarts system using software reset.

  @param void

  @return asdk_status_t

*/
asdk_status_t sys_sw_reset ( void )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

	/* Software reset */

	return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
}/* sys_sw_reset */

/*----------------------------------------------------------------------------*/
/* Function : sys_halt */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function halts system.

  @param void

  @return asdk_status_t

*/
asdk_status_t sys_halt ( void )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

	error_code = ASDK_SYS_ERROR;
	return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);

}/* sys_halt */

/*----------------------------------------------------------------------------*/
/* Function : sys_enable_interrupts */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function enables system interrupt.

  @param void

  @return asdk_status_t

*/
asdk_status_t sys_enable_interrupts ( void )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

	/* enable interrupt  */
	// INT_SYS_EnableIRQGlobal();

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);

}/* sys_enable_interrupts */

/*----------------------------------------------------------------------------*/
/* Function : sys_disable_interrupts */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function disables system interrupts.

  @param void

  @return asdk_status_t

*/
asdk_status_t sys_disable_interrupts ( void )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

	/* disable interrupt  */
	// INT_SYS_DisableIRQGlobal();

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);

}/* sys_disable_interrupts */

/*----------------------------------------------------------------------------*/
/* Function : set_nvic_priority */
/*----------------------------------------------------------------------------*/
/*!
  @brief
   This function Sets the priority of an interrupt.

  @param asdk_module_code_t module_name - module_name

  @param uint32_t priority -  Priority to set

  @return asdk_status_t ASDK_SYS_SUCCESS

  @Note : lower priority number indicates higher interrupt priority.
*/
asdk_status_t set_nvic_priority ( asdk_module_code_t module_name, uint8_t module_no, uint32_t priority  )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
} /* set_nvic_priority */

/*----------------------------------------------------------------------------*/
/* Function : relocate_vector_table */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function jumps context to application address for s32.

  @param const uint32_t app_start_address - app start address

  @param const uint32_t startup_address - startup application address

  @return asdk_status_t ASDK_SYS_SUCCESS

*/
asdk_status_t relocate_vector_table ( const uint32_t app_start_address, const uint32_t startup_address )
{
	/* variable to hold Error code value */
  	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

	/* Relocate vector table */

    error_code = ASDK_SYS_SUCCESS;
    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
} /* relocate_vector_table */

/*----------------------------------------------------------------------------*/
/* Function : sys_get_unique_id */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets cpu unique id.

  @param uint32_t *id

  @return asdk_status_t

*/
asdk_status_t sys_get_unique_id ( uint32_t *id )
{
  /* variable to hold Error code value */
  asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;
	
  return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
}/* sys_get_unique_id */

/*----------------------------------------------------------------------------*/
/* Function : sys_get_reset_reason */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets system restart status.

  @param asdk_reset_t *reason

  @return asdk_status_t

*/
asdk_status_t sys_get_reset_reason (asdk_sys_reset_t *reason )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);

}/* sys_get_reset_reason */

/*----------------------------------------------------------------------------*/
/* Function : sys_mux_configure */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function configures pin mux.

  @param  asdk_clk_cfg_t *config

  @return asdk_status_t

*/
asdk_status_t sys_mux_configure ( asdk_clk_cfg_t *config )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
}/* sys_mux_configure */

/*----------------------------------------------------------------------------*/
/* Function : sys_clk_configure */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function configures system clock.

  @param asdk_mux_cfg_t *config

  @return asdk_status_t

*/
asdk_status_t sys_clk_configure ( asdk_mux_cfg_t *config )
{
	(void)config ;
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

	/* configure system clocks */

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
}/* sys_clk_configure */

/*----------------------------------------------------------------------------*/
/* Function : sys_pm_configure */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function configures system mode.

  @param  asdk_pm_cfg_t *config

  @return asdk_status_t

*/
asdk_status_t sys_pm_configure ( asdk_pm_cfg_t *config )
{
	/* variable to hold Error code value */
  	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

    /* set configured power mode */

    // return error_status;
    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);

}/* sys_pm_configure */

/*Get clock freq*/
asdk_status_t get_clock_frequency( asdk_clk_cfg_t *config, uint32_t *frequency )
{
	/* variable to hold Error code value */
	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t sys_get_multiple_reset_reasons (uint8_t *reason )
{
	/* variable to hold Error code value */
  	asdk_sys_ec_t error_code = ASDK_SYS_UNSUPPORTED_FEATURE;

    return ASDK_SYS_RETURN(ASDK_LC_HARDWARE, error_code);
}
