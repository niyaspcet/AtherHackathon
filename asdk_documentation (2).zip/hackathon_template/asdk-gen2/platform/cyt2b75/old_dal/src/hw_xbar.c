/*
 *@file
 *hw_xbar.c

 *@path
 *dal/src/hw_xbar.c

 *@Created on
 *24-03-2020

 *@Author
 *anup.gandra

 *@Copyright
 *Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

 *@brief
 *This file implements the xbar for MKV46F128 micro-controller.


*/

/*==============================================================================
 *						INCLUDE FILES
 *==============================================================================
 */
#include "hw_xbar.h"

/*==============================================================================
 *				DEFINITIONS AND TYPES : STRUCTURES
 *==============================================================================
 */


/*==============================================================================
 *						LOCAL FUNCTION DEFINITIONS
 *==============================================================================
 */

/*----------------------------------------------------------------------------*/
/* Function : xbar_init */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function initializes the XBAR module.

 *@param uint8_t xbar_no - xbar to initialize

 *@return asdk_status_t ASDK_XBAR_MOD_RANGE_EXCEEDED		- if xbar is exceeded
						ASDK_XBAR_STATUS_SUCCESS			- in case of successful operation
 */

asdk_status_t xbar_init(uint8_t xbar_no)
{
	(void)xbar_no;
	return ASDK_XBAR_RETURN(ASDK_LC_HARDWARE, ASDK_XBAR_NOT_IMPLEMENTED);
}


/*----------------------------------------------------------------------------*/
/* Function : xbar_deinit */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function de-initializes the XBAR module.

 *@param uint8_t xbar_no - XBAR no to de-initialize

 *@return asdk_status_t ASDK_XBAR_MOD_RANGE_EXCEEDED		- if xbar no. is exceeded
						ASDK_XBAR_STATUS_SUCCESS			- in case of successful operation
 */

asdk_status_t xbar_deinit(uint8_t xbar_no)
{
	(void)xbar_no;
	return ASDK_XBAR_RETURN(ASDK_LC_HARDWARE, ASDK_XBAR_NOT_IMPLEMENTED);
}


/*----------------------------------------------------------------------------*/
/* Function : asdk_xbar_setsignalconnection */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function sets xbar input and output signals

 *@param asdk_xbar_user_config_t *dal_xbar_config - xbar config data

 *@return asdk_status_t ASDK_XBAR_MOD_RANGE_EXCEEDED		- if xbar no. is exceeded
						ASDK_XBAR_STATUS_SUCCESS			- in case of successful operation
 */

asdk_status_t xbar_setsignalconnection(asdk_xbar_user_config_t *dal_xbar_config)
{
	(void)dal_xbar_config;
	return ASDK_XBAR_RETURN(ASDK_LC_HARDWARE, ASDK_XBAR_NOT_IMPLEMENTED);
}
