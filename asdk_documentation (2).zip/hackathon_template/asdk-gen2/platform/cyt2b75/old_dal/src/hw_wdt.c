/*
  @file
  hw_wdt.c

  @path
  /platform/asdk/kw36/asdk_drivers/hw_wdt.c

  @Created on
  Nov 21, 2019

  @Author
  anupam.kumar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

/*==============================================================================

						   INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "wdt.h"
#include "hw_wdt.h"
/*==============================================================================

						LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
// static const char filename[] = "hw_wdt.c";

/*==============================================================================

					  LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/

/*==============================================================================

					  LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

					LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

							LOCAL FUNCTION PROTOTYPES

==============================================================================*/

/*==============================================================================

							LOCAL FUNCTION DEFINITIONS

==============================================================================*/
/*----------------------------------------------------------------------------*/
/* Function : asdk_watchdog_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initialize watchdog module

  @param asdk_wdt_config_t* wdt_config_data ( input )

  @return asdk_status_t ASDK_WDT_INVALID_WDT_NO - if invalid wdt range
						ASDK_WDT_STATUS_SUCCESS - after successful wdt initialization
*/
asdk_status_t watchdog_init(asdk_wdt_config_t *wdt_config_data)
{
	/* variable to hold Error code value */
	asdk_wdt_ec_t error_code = ASDK_WDT_NOT_INITIALIZED;
	ASDK_WDT_RETURN(ASDK_LC_HARDWARE, error_code);
} /* asdk_watchdog_init */

/*----------------------------------------------------------------------------*/
/* Function : asdk_watchdog_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function deinitialize watchdog module

  @param uint8_t wdt_no - watchdog module no

  @return asdk_status_t ASDK_WDT_INVALID_WDT_NO - if invalid wdt range
						ASDK_WDT_STATUS_SUCCESS - after successful wdt deinitialization

  @NNote: The COP configuration register is a write-once after reset.
	  To disable the COP Watchdog, call this function first.

*/
asdk_status_t watchdog_deinit(uint8_t wdt_no)
{
    /* variable to hold Error code value */
	asdk_wdt_ec_t error_code = ASDK_WDT_NOT_INITIALIZED;
	ASDK_WDT_RETURN(ASDK_LC_HARDWARE, error_code);
} /* asdk_watchdog_deinit */

/*----------------------------------------------------------------------------*/
/* Function : asdk_watchdog_refresh */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function refreshes watchdog

  @param uint8_t wdt_no - watchdog module no (input)

  @return asdk_status_t ASDK_WDT_INVALID_WDT_NO - if invalid wdt range
						ASDK_WDT_STATUS_SUCCESS - after successful wdt refresh

*/
asdk_status_t watchdog_refresh(uint8_t wdt_no)
{
    /* variable to hold Error code value */
	asdk_wdt_ec_t error_code = ASDK_WDT_NOT_INITIALIZED;
	ASDK_WDT_RETURN(ASDK_LC_HARDWARE, error_code);
} /* asdk_watchdog_refresh */

/*----------------------------------------------------------------------------*/
/* Function : watchdog_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install watchdog callback

  @param uint8_t wdt_no - watchdog module no (input)

  @param asdk_wdt_callback_fun_t *callback_fun - callback function (input)

  @return asdk_status_t ASDK_WDT_INVALID_WDT_NO - if invalid wdt range
						ASDK_WDT_STATUS_ERROR - kw36 doesn't support callback

*/
asdk_status_t watchdog_install_callback(uint8_t wdt_no, asdk_wdt_callback_fun_t callback_fun)
{
    /* variable to hold Error code value */
	asdk_wdt_ec_t error_code = ASDK_WDT_NOT_INITIALIZED;
	ASDK_WDT_RETURN(ASDK_LC_HARDWARE, error_code);
} /* watchdog_install_callback */
