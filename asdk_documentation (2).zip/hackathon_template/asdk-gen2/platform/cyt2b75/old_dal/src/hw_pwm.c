/*
  @file
  hw_timer.c

  @path
  hw_timer.c

  @Created on
  Jul 01, 2020

  @Author
  anshuman.tripathi

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
  This file implements the pwm module hardware dependent component
  for mkv46f microcontroller.
*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include "hw_pwm.h"

/*==============================================================================

                        LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
//static const char filename[] = "hw_pwm.c";

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/

/*==============================================================================
s
                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/* Function : pwm_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initialize PWM instance - driver and channel

  @param asdk_pwm_config_t* pwm_config - pwm int config

  @return asdk_status_t

*/
asdk_status_t pwm_init(asdk_pwm_config_t *pwm_config)
{
    (void)pwm_config;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);

}

/*----------------------------------------------------------------------------*/
/* Function : pwm_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-initialize PWM instance

  @param uint8_t pwm_module - pwm_module no.

  @param uint8_t pwm_sub_module - pwm_sub_module no.

  @return asdk_status_t

*/
asdk_status_t pwm_deinit(uint8_t pwm_module, uint8_t pwm_sub_module)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_start_timer(uint8_t pwm_module, uint8_t pwm_sub_module)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_stop_timer(uint8_t pwm_module, uint8_t pwm_sub_module)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_start_combined(uint8_t *pwm_sub_mod_array, uint8_t pwm_sub_mod_array_size)
{
    (void)pwm_sub_mod_array;
    (void)pwm_sub_mod_array_size;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_stop_combined(uint8_t *pwm_sub_mod_array, uint8_t pwm_sub_mod_array_size)
{
    (void)pwm_sub_mod_array;
    (void)pwm_sub_mod_array_size;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_update_duty_cycle(uint8_t pwm_module, uint8_t pwm_sub_module,
                                    asdk_pwm_channel_config_t *pwm_channel_configs)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)pwm_channel_configs;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_output_trigger_enable(uint8_t pwm_module, uint8_t pwm_sub_module, asdk_pwm_val_register_t val_register, bool enable)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)val_register;
    (void)enable;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_on_off(uint8_t pwm_module, uint8_t pwm_sub_module, bool operation)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)operation;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_update_deadtime(uint8_t pwm_module, uint8_t pwm_sub_module, uint16_t dead_time_ns)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)dead_time_ns;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_getvalueregister(uint8_t pwm_module, uint8_t pwm_sub_module, asdk_pwm_val_register_t valueregister, uint16_t *result)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)valueregister;
    (void)result;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}
asdk_status_t pwm_updatevalueregister(uint8_t pwm_module, uint8_t pwm_sub_module, asdk_pwm_val_register_t valueregister, uint16_t value)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)valueregister;
    (void)value;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_set_loadOk(uint8_t *pwm_sub_mod_array, uint8_t pwm_sub_mod_array_size)
{
    (void)pwm_sub_mod_array;
    (void)pwm_sub_mod_array_size;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_enable_interrupt(uint8_t pwm_module, uint16_t pwm_sub_module, uint32_t mask)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)mask;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}
asdk_status_t pwm_disable_interrupt(uint8_t pwm_module, uint16_t pwm_sub_module, uint32_t mask)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)mask;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}

asdk_status_t pwm_install_callback(uint8_t pwm_module, uint8_t pwm_sub_module,
                                   asdk_pwm_callback_fun_t pwm_callback_func)
{
    (void)pwm_module;
    (void)pwm_sub_module;
    (void)pwm_callback_func;
    return ASDK_PWM_RETURN(ASDK_LC_HARDWARE, ASDK_PWM_FEATURE_NOT_IMPLEMENTED);
}
