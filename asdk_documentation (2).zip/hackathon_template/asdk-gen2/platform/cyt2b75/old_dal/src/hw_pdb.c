/*
 *@file
 *hw_pdb.c

 *@path
 *dal/src/hw_pdb.c

 *@Created on
 *23-03-2020

 *@Author
 *anup.gandra

 *@Copyright
 *Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

 *@brief
 *This file implements the pwm for MKV46F128 micro-controller.


*/

/*==============================================================================
 *						INCLUDE FILES
 *==============================================================================
 */
#include "hw_pdb.h"
#include "pdb.h"
/*==============================================================================
 *				DEFINITIONS AND TYPES : STRUCTURES
 *==============================================================================
 */


/*==============================================================================
 *						LOCAL FUNCTION DEFINITIONS
 *==============================================================================
 */

/*----------------------------------------------------------------------------*/
/* Function : pdb_init */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function initializes the PDB module.

 *@param asdk_pdb_user_config_t *dal_pdb_config - pdg configuration data

 *@return asdk_status_t ASDK_PDB_MOD_RANGE_EXCEEDED		- if pdb no. is exceeded
						ASDK_PDB_STATUS_SUCCESS			- in case of successful operation
 */

asdk_status_t pdb_init(asdk_pdb_user_config_t *dal_pdb_config)
{
	(void)dal_pdb_config;
	return ASDK_PDB_RETURN(ASDK_LC_HARDWARE, ASDK_PDB_NOT_IMPLEMENTED);
}


/*----------------------------------------------------------------------------*/
/* Function : pdb_deinit */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function de-initializes the PDB module.

 *@param uint8_t pdb_no - PDB no to de-initialize

 *@return asdk_status_t ASDK_PDB_MOD_RANGE_EXCEEDED		- if pdb no. is exceeded
						ASDK_PDB_STATUS_SUCCESS			- in case of successful operation
 */

asdk_status_t pdb_deinit(uint8_t pdb_no)
{
	(void)pdb_no;
	return ASDK_PDB_RETURN(ASDK_LC_HARDWARE, ASDK_PDB_NOT_IMPLEMENTED);
}


/*----------------------------------------------------------------------------*/
/* Function : pdb_config_delay */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function sets interrupt delay from input trigger for PDB block

 *@param uint8_t pdb_no - PDB no. for which delay should be set(input)

 *@return asdk_status_t ASDK_PDB_MOD_RANGE_EXCEEDED		- if pdb no. is exceeded
						ASDK_PDB_STATUS_SUCCESS			- in case of successful operation
 */

asdk_status_t pdb_config_delay(uint8_t pdb_no, uint32_t delay)
{
	(void)pdb_no;
	(void)delay;
	return ASDK_PDB_RETURN(ASDK_LC_HARDWARE, ASDK_PDB_NOT_IMPLEMENTED);
}


/*----------------------------------------------------------------------------*/
/* Function : pdb_config_delay */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function sets loadok bit for loading MOD, IDLY register values for delay

 *@param uint8_t pdb_no - PDB no. for which loadok bit should be set)

 *@return asdk_status_t ASDK_PDB_MOD_RANGE_EXCEEDED		- if pdb no. is exceeded
						ASDK_PDB_STATUS_SUCCESS			- in case of successful operation
 */

asdk_status_t pdb_loadvalues(uint8_t pdb_no)
{
	(void)pdb_no;
	return ASDK_PDB_RETURN(ASDK_LC_HARDWARE, ASDK_PDB_NOT_IMPLEMENTED);
}

/*----------------------------------------------------------------------------*/
/* Function : pdb_install_callback */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function sets call back functions for respective pdb irq's

 *@param uint8_t pdb_no - pdb no. for which callback needs to be set.
 *@param asdk_pdb_callback_fun_t callback_fun - Function pointer to which irq is set

 *@return asdk_status_t ASDK_PDB_MOD_RANGE_EXCEEDED		- if pdb no. is exceeded
						ASDK_PDB_STATUS_SUCCESS			- in case of successful operation
 */
asdk_status_t pdb_install_callback(uint8_t pdb_no, asdk_pdb_callback_fun_t callback_fun)
{
	(void)pdb_no;
	(void)callback_fun;
	return ASDK_PDB_RETURN(ASDK_LC_HARDWARE, ASDK_PDB_NOT_IMPLEMENTED);
}


/*----------------------------------------------------------------------------*/
/* Function : pdb_setmodulusvalue */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function sets pdb dely

 *@param uint8_t pdb_no - pdb no.
 *@param uint32_t delay - delay time.

 *@return asdk_status_t ASDK_PDB_MOD_RANGE_EXCEEDED		- if pdb no. is exceeded
						ASDK_PDB_STATUS_SUCCESS			- in case of successful operation
 */
asdk_status_t pdb_setmodulusvalue(uint8_t pdb_no, uint32_t delay)
{
	(void)pdb_no;
	(void)delay;
	return ASDK_PDB_RETURN(ASDK_LC_HARDWARE, ASDK_PDB_NOT_IMPLEMENTED);
}
