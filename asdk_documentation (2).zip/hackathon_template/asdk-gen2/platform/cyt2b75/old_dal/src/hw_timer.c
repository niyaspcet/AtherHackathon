/*
  @file
  hw_timer.c

  @path
  hw_timer.c

  @Created on
  March 02, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
  This file implements the timer module hardware dependent component
  for cyt2b75 microcontroller.


*/

/* 

To do:

1. Consume configuration for Timers and Systick.
2. Add error checks.
3. Test ISR handler user callback
4. Decide on LPIT, LPTMR and Timer types for CYT2B75
5. Decide on mapping timer_no and channel_no

Date: 12/04/2023
1. Map the irq and init functions as per the timer mode 
2. Hard code needs to be done in the channel no. in the timer channel configuration
3. In the application while updating the duty cycle in the switch case hard code the channel properly as per ldu

Notes:

Following timers (TCPWM0) are available for CYT2B75:
1. 16-bit timer  - TCPWM0 group-0
2. 16-bit pwm    - TCPWM0 group-1
3. 32-bit timer  - TCPWM0 group-2   (unused)
4. systick timer - dedicated

Following mapping is assigned by DAL for compatability with ASDK:
1. PIT/LPIT/LPTMR - group-0
2. PWM            - group-1
3. SYSTICK        - systick

As per asdk_timer_config_t configuration:
        .timer_no - instance (index) of timer peripheral
    .cfg_array_no - no. of ch. for a given instance
 .ch_Config_array - holds configuration

Following timer types are treated as ASDK_TIMER_TYPE_LPTMR:
ASDK_TIMER_TYPE_LPTMR
ASDK_TIMER_TYPE_LPIT
ASDK_TIMER_TYPE_PIT

Following modes are supported:
ASDK_TIMER_TIME_COUNTER

*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

/* SDL includes */
#include "cy_device_headers.h"
#include "sysclk/cy_sysclk.h"
#include "sysint/cy_sysint.h"
#include "tcpwm/cy_tcpwm_counter.h"
#include "tcpwm/cy_tcpwm_pwm.h"

/* ASDK includes */
#include "hw_timer.h"

typedef void (*tcpwm0_isr_handler_p)(void);

/* dedicated counters for every channel */
static uint16_t g0_counter[CYT2B7_TCPWM0_GRP_0_CH_MAX] = {0};
static uint16_t g1_counter[CYT2B7_TCPWM0_GRP_1_CH_MAX] = {0};
static uint32_t g2_counter[CYT2B7_TCPWM0_GRP_2_CH_MAX] = {0};
static uint32_t sys_tick_counter = 0;

/* user callback fptr declarations */
static asdk_timer_ch_callback_fun_t tcpwm0_group0_user_callback[CYT2B7_TCPWM0_GRP_0_CH_MAX] = {0};
static asdk_timer_ch_callback_fun_t tcpwm0_group1_user_callback[CYT2B7_TCPWM0_GRP_1_CH_MAX] = {0};
static asdk_timer_ch_callback_fun_t tcpwm0_group2_user_callback[CYT2B7_TCPWM0_GRP_2_CH_MAX] = {0};

/* TCPWM0 group-0 ISR handlers */
static void group0_ch0_isr_handler(void);
#if 1 // GROUP_0_ISR
static void group0_ch1_isr_handler(void);
static void group0_ch2_isr_handler(void);
static void group0_ch3_isr_handler(void);
static void group0_ch4_isr_handler(void);
static void group0_ch5_isr_handler(void);
static void group0_ch6_isr_handler(void);
static void group0_ch7_isr_handler(void);
static void group0_ch8_isr_handler(void);
static void group0_ch9_isr_handler(void);
static void group0_ch10_isr_handler(void);
static void group0_ch11_isr_handler(void);
static void group0_ch12_isr_handler(void);
static void group0_ch13_isr_handler(void);
static void group0_ch14_isr_handler(void);
static void group0_ch15_isr_handler(void);
static void group0_ch16_isr_handler(void);
static void group0_ch17_isr_handler(void);
static void group0_ch18_isr_handler(void);
static void group0_ch19_isr_handler(void);
static void group0_ch20_isr_handler(void);
static void group0_ch21_isr_handler(void);
static void group0_ch22_isr_handler(void);
static void group0_ch23_isr_handler(void);
static void group0_ch24_isr_handler(void);
static void group0_ch25_isr_handler(void);
static void group0_ch26_isr_handler(void);
static void group0_ch27_isr_handler(void);
static void group0_ch28_isr_handler(void);
static void group0_ch29_isr_handler(void);
static void group0_ch30_isr_handler(void);
static void group0_ch31_isr_handler(void);
static void group0_ch32_isr_handler(void);
static void group0_ch33_isr_handler(void);
static void group0_ch34_isr_handler(void);
static void group0_ch35_isr_handler(void);
static void group0_ch36_isr_handler(void);
static void group0_ch37_isr_handler(void);
static void group0_ch38_isr_handler(void);
static void group0_ch39_isr_handler(void);
static void group0_ch40_isr_handler(void);
static void group0_ch41_isr_handler(void);
static void group0_ch42_isr_handler(void);
static void group0_ch43_isr_handler(void);
static void group0_ch44_isr_handler(void);
static void group0_ch45_isr_handler(void);
static void group0_ch46_isr_handler(void);
static void group0_ch47_isr_handler(void);
static void group0_ch48_isr_handler(void);
static void group0_ch49_isr_handler(void);
static void group0_ch50_isr_handler(void);
static void group0_ch51_isr_handler(void);
static void group0_ch52_isr_handler(void);
static void group0_ch53_isr_handler(void);
static void group0_ch54_isr_handler(void);
static void group0_ch55_isr_handler(void);
static void group0_ch56_isr_handler(void);
static void group0_ch57_isr_handler(void);
static void group0_ch58_isr_handler(void);
static void group0_ch59_isr_handler(void);
static void group0_ch60_isr_handler(void);
static void group0_ch61_isr_handler(void);
static void group0_ch62_isr_handler(void);
#endif // GROUP_0_ISR


#if 1 // GROUP_1_ISR
/* TCPWM0 group-1 ISR handlers */
static void group1_ch0_isr_handler(void);
static void group1_ch1_isr_handler(void);
static void group1_ch2_isr_handler(void);
static void group1_ch3_isr_handler(void);
static void group1_ch4_isr_handler(void);
static void group1_ch5_isr_handler(void);
static void group1_ch6_isr_handler(void);
static void group1_ch7_isr_handler(void);
static void group1_ch8_isr_handler(void);
static void group1_ch9_isr_handler(void);
static void group1_ch10_isr_handler(void);
static void group1_ch11_isr_handler(void);
#endif // GROUP_1_ISR

/* TCPWM0 group-2 ISR handlers */
static void group2_ch0_isr_handler(void);
#if 1 // GROUP_2_ISR
static void group2_ch1_isr_handler(void);
static void group2_ch2_isr_handler(void);
static void group2_ch3_isr_handler(void);
#endif // GROUP_2_ISR

/* SYSTICK ISR handlers */
static void systick_isr_handler(void);

/* Base ptrs for TCPWM0 groups */
volatile stc_TCPWM_GRP_CNT_t *group0_base_ptrs[] = {
    TCPWM0_GRP0_CNT0,  TCPWM0_GRP0_CNT1,   TCPWM0_GRP0_CNT2,  TCPWM0_GRP0_CNT3,
    TCPWM0_GRP0_CNT4,  TCPWM0_GRP0_CNT5,   TCPWM0_GRP0_CNT6,  TCPWM0_GRP0_CNT7,
    TCPWM0_GRP0_CNT8,  TCPWM0_GRP0_CNT9,  TCPWM0_GRP0_CNT10, TCPWM0_GRP0_CNT11,
    TCPWM0_GRP0_CNT12, TCPWM0_GRP0_CNT13, TCPWM0_GRP0_CNT14, TCPWM0_GRP0_CNT15,
    TCPWM0_GRP0_CNT16, TCPWM0_GRP0_CNT17, TCPWM0_GRP0_CNT18, TCPWM0_GRP0_CNT19,
    TCPWM0_GRP0_CNT20, TCPWM0_GRP0_CNT21, TCPWM0_GRP0_CNT22, TCPWM0_GRP0_CNT23,
    TCPWM0_GRP0_CNT24, TCPWM0_GRP0_CNT25, TCPWM0_GRP0_CNT26, TCPWM0_GRP0_CNT27,
    TCPWM0_GRP0_CNT28, TCPWM0_GRP0_CNT29, TCPWM0_GRP0_CNT30, TCPWM0_GRP0_CNT31,
    TCPWM0_GRP0_CNT32, TCPWM0_GRP0_CNT33, TCPWM0_GRP0_CNT34, TCPWM0_GRP0_CNT35,
    TCPWM0_GRP0_CNT36, TCPWM0_GRP0_CNT37, TCPWM0_GRP0_CNT38, TCPWM0_GRP0_CNT39,
    TCPWM0_GRP0_CNT40, TCPWM0_GRP0_CNT41, TCPWM0_GRP0_CNT42, TCPWM0_GRP0_CNT43,
    TCPWM0_GRP0_CNT44, TCPWM0_GRP0_CNT45, TCPWM0_GRP0_CNT46, TCPWM0_GRP0_CNT47,
    TCPWM0_GRP0_CNT48, TCPWM0_GRP0_CNT49, TCPWM0_GRP0_CNT50, TCPWM0_GRP0_CNT51,
    TCPWM0_GRP0_CNT52, TCPWM0_GRP0_CNT53, TCPWM0_GRP0_CNT54, TCPWM0_GRP0_CNT55,
    TCPWM0_GRP0_CNT56, TCPWM0_GRP0_CNT57, TCPWM0_GRP0_CNT58, TCPWM0_GRP0_CNT59,
    TCPWM0_GRP0_CNT60, TCPWM0_GRP0_CNT61, TCPWM0_GRP0_CNT62
};

volatile stc_TCPWM_GRP_CNT_t *group1_base_ptrs[] = {
    TCPWM0_GRP1_CNT0, TCPWM0_GRP1_CNT1,  TCPWM0_GRP1_CNT2,  TCPWM0_GRP1_CNT3,
    TCPWM0_GRP1_CNT4, TCPWM0_GRP1_CNT5,  TCPWM0_GRP1_CNT6,  TCPWM0_GRP1_CNT7,
    TCPWM0_GRP1_CNT8, TCPWM0_GRP1_CNT9, TCPWM0_GRP1_CNT10, TCPWM0_GRP1_CNT11
};

volatile stc_TCPWM_GRP_CNT_t *group2_base_ptrs[] = {
    TCPWM0_GRP2_CNT0, TCPWM0_GRP2_CNT1, TCPWM0_GRP2_CNT2, TCPWM0_GRP2_CNT3,
};

static tcpwm0_isr_handler_p group0_isr_ptrs[] = {
    &group0_ch0_isr_handler,
    &group0_ch1_isr_handler,
    &group0_ch2_isr_handler,
    &group0_ch3_isr_handler,
    &group0_ch4_isr_handler,
    &group0_ch5_isr_handler,
    &group0_ch6_isr_handler,
    &group0_ch7_isr_handler,
    &group0_ch8_isr_handler,
    &group0_ch9_isr_handler,
    &group0_ch10_isr_handler,
    &group0_ch11_isr_handler,
    &group0_ch12_isr_handler,
    &group0_ch13_isr_handler,
    &group0_ch14_isr_handler,
    &group0_ch15_isr_handler,
    &group0_ch16_isr_handler,
    &group0_ch17_isr_handler,
    &group0_ch18_isr_handler,
    &group0_ch19_isr_handler,
    &group0_ch20_isr_handler,
    &group0_ch21_isr_handler,
    &group0_ch22_isr_handler,
    &group0_ch23_isr_handler,
    &group0_ch24_isr_handler,
    &group0_ch25_isr_handler,
    &group0_ch26_isr_handler,
    &group0_ch27_isr_handler,
    &group0_ch28_isr_handler,
    &group0_ch29_isr_handler,
    &group0_ch30_isr_handler,
    &group0_ch31_isr_handler,
    &group0_ch32_isr_handler,
    &group0_ch33_isr_handler,
    &group0_ch34_isr_handler,
    &group0_ch35_isr_handler,
    &group0_ch36_isr_handler,
    &group0_ch37_isr_handler,
    &group0_ch38_isr_handler,
    &group0_ch39_isr_handler,
    &group0_ch40_isr_handler,
    &group0_ch41_isr_handler,
    &group0_ch42_isr_handler,
    &group0_ch43_isr_handler,
    &group0_ch44_isr_handler,
    &group0_ch45_isr_handler,
    &group0_ch46_isr_handler,
    &group0_ch47_isr_handler,
    &group0_ch48_isr_handler,
    &group0_ch49_isr_handler,
    &group0_ch50_isr_handler,
    &group0_ch51_isr_handler,
    &group0_ch52_isr_handler,
    &group0_ch53_isr_handler,
    &group0_ch54_isr_handler,
    &group0_ch55_isr_handler,
    &group0_ch56_isr_handler,
    &group0_ch57_isr_handler,
    &group0_ch58_isr_handler,
    &group0_ch59_isr_handler,
    &group0_ch60_isr_handler,
    &group0_ch61_isr_handler,
    &group0_ch62_isr_handler,
    
  
};

static tcpwm0_isr_handler_p group1_isr_ptrs[] = {
    &group1_ch0_isr_handler, 
    &group1_ch1_isr_handler, 
    &group1_ch2_isr_handler, 
    &group1_ch3_isr_handler, 
    &group1_ch4_isr_handler, 
    &group1_ch5_isr_handler, 
    &group1_ch6_isr_handler, 
    &group1_ch7_isr_handler, 
    &group1_ch8_isr_handler, 
    &group1_ch9_isr_handler, 
    &group1_ch10_isr_handler, 
    &group1_ch11_isr_handler,
    
};

static tcpwm0_isr_handler_p group2_isr_ptrs[] = {
    &group2_ch0_isr_handler,
    &group2_ch1_isr_handler,
    &group2_ch2_isr_handler,
    &group2_ch3_isr_handler
};

static cy_stc_tcpwm_counter_config_t /*const*/ MyCounter_config =
{
    // .period             = 999, // 15625ul - 1ul,                        // 15,625 / 15625 = 1s
    .clockPrescaler     = CY_TCPWM_PRESCALER_DIVBY_2, // CY_TCPWM_PRESCALER_DIVBY_128,         // 2,000,000Hz / 128 = 15,625Hz
    .runMode            = CY_TCPWM_COUNTER_CONTINUOUS,
    .countDirection     = CY_TCPWM_COUNTER_COUNT_UP,
    .debug_pause        = 0uL,
    .compareOrCapture   = CY_TCPWM_COUNTER_MODE_COMPARE,
    .compare0           = 0ul,
    .compare0_buff      = 0ul,
    .compare1           = 0ul,
    .compare1_buff      = 0ul,
    .enableCompare0Swap = false,
    .enableCompare1Swap = false,
    .interruptSources   = CY_TCPWM_INT_NONE,
    .capture0InputMode  = CY_TCPWM_INPUT_LEVEL,
    .capture0Input      = 0ul,
    .reloadInputMode    = CY_TCPWM_INPUT_LEVEL,
    .reloadInput        = 0ul,
    .startInputMode     = CY_TCPWM_INPUT_LEVEL,
    .startInput         = 0ul,
    .stopInputMode      = CY_TCPWM_INPUT_LEVEL,
    .stopInput          = 0ul,
    .capture1InputMode  = CY_TCPWM_INPUT_LEVEL,
    .capture1Input      = 0ul,
    .countInputMode     = CY_TCPWM_INPUT_LEVEL,
    .countInput         = 1ul,
    .trigger0EventCfg   = CY_TCPWM_COUNTER_OVERFLOW,
    .trigger1EventCfg   = CY_TCPWM_COUNTER_OVERFLOW,
};

cy_stc_tcpwm_pwm_config_t /*const*/ MyPWM_config =
{
    .pwmMode            = CY_TCPWM_PWM_MODE_PWM,//CY_TCPWM_PWM_MODE_DEADTIME,
    .clockPrescaler     = CY_TCPWM_PRESCALER_DIVBY_1,
    .debug_pause        = false,
    .cc0MatchMode       = CY_TCPWM_PWM_TR_CTRL2_CLEAR,
    .overflowMode       = CY_TCPWM_PWM_TR_CTRL2_SET,
    .underflowMode      = CY_TCPWM_PWM_TR_CTRL2_NO_CHANGE,
    .cc1MatchMode       = CY_TCPWM_PWM_TR_CTRL2_NO_CHANGE,
    .deadTime           = 0,//TCPWMx_DEADTIME,
    .deadTimeComp       = 0,//TCPWMx_DEADTIME_COMPL,
    .runMode            = CY_TCPWM_PWM_CONTINUOUS,
    .period             = 10000ul,//1500,//TCPWMx_PERIOD - 1ul,
    .period_buff        = 0ul,
    .enablePeriodSwap   = false,
    .compare0           = 5000ul,//0xFF,
    .compare1           = 0ul,
    .enableCompare0Swap = false,
    .enableCompare1Swap = false,
    .interruptSources   = CY_TCPWM_INT_NONE,
    .invertPWMOut       = 0ul,
    .invertPWMOutN      = 0ul,
    .killMode           = CY_TCPWM_PWM_STOP_ON_KILL,
    .switchInputMode    = CY_TCPWM_INPUT_LEVEL,
    .switchInput        = 0ul,
    .reloadInputMode    = CY_TCPWM_INPUT_LEVEL,
    .reloadInput        = 0ul,
    .startInputMode     = CY_TCPWM_INPUT_LEVEL,
    .startInput         = 0ul,
    .kill0InputMode     = CY_TCPWM_INPUT_LEVEL,
    .kill0Input         = 0ul,
    .kill1InputMode     = CY_TCPWM_INPUT_LEVEL,
    .kill1Input         = 0ul,
    .countInputMode     = CY_TCPWM_INPUT_LEVEL,
    .countInput         = 1ul,
};

static cy_stc_sysint_irq_t my_irq_cfg = 
{
    .sysIntSrc  = tcpwm_0_interrupts_1_IRQn,
    .intIdx     = CPUIntIdx3_IRQn,
    .isEnabled  = true,
};

static void systick_isr_handler(void)
{
    sys_tick_counter++;
}

static void cy_timer_init(asdk_timer_config_t *timer_config)
{
    uint8_t ch_no = timer_config->ch_Config_array->channel_no;
    tcpwm0_isr_handler_p isr_handler_p = NULL;
    volatile stc_TCPWM_GRP_CNT_t *timer_base_p = NULL;

    switch (timer_config->timer_type)
    {
        asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;
        uint8_t timer_channel_index = 0;
        
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
          if(timer_config->timer_no == 0)
          {
            
            for(timer_channel_index = 0; timer_channel_index < (timer_config->cfg_array_no) ; timer_channel_index++)
            {
                MyCounter_config.period = timer_config->ch_Config_array[timer_channel_index].period;
                uint8_t ch_no = timer_config->ch_Config_array[timer_channel_index].channel_no ;
                isr_handler_p = group0_isr_ptrs[ch_no];
                timer_base_p = group0_base_ptrs[ch_no];
                if (timer_config->ch_Config_array[timer_channel_index].callback_fun != NULL)
                    tcpwm0_group0_user_callback[ch_no] = timer_config->ch_Config_array[timer_channel_index].callback_fun;
              
                my_irq_cfg.sysIntSrc = (cy_en_intr_t)(tcpwm_0_interrupts_0_IRQn + (timer_config->ch_Config_array[timer_channel_index].channel_no));
                Cy_SysInt_InitIRQ(&my_irq_cfg);
                Cy_SysInt_SetSystemIrqVector(my_irq_cfg.sysIntSrc, isr_handler_p);
                NVIC_SetPriority(my_irq_cfg.intIdx, 4ul);
                NVIC_EnableIRQ(my_irq_cfg.intIdx);
                
                Cy_Tcpwm_Counter_Init(timer_base_p, &MyCounter_config);
                Cy_Tcpwm_Counter_Enable(timer_base_p);
                Cy_Tcpwm_Counter_SetTC_IntrMask(timer_base_p); /* Enable Interrupt */
              
            }
            
            
          }
          else if(timer_config->timer_no == 1)
          {
              //Initialize the isrs with the chnanel isrs
             for(timer_channel_index = 0; timer_channel_index < (timer_config->cfg_array_no) ; timer_channel_index++)
                {
                  MyCounter_config.period = timer_config->ch_Config_array[timer_channel_index].period;
                  uint8_t ch_no = timer_config->ch_Config_array[timer_channel_index].channel_no;
                  isr_handler_p = group1_isr_ptrs[ch_no];
                  timer_base_p = group1_base_ptrs[ch_no];
                  if (timer_config->ch_Config_array[timer_channel_index].callback_fun != NULL)
                      tcpwm0_group1_user_callback[ch_no] = timer_config->ch_Config_array[timer_channel_index].callback_fun;
                  
                  my_irq_cfg.sysIntSrc = (cy_en_intr_t)(tcpwm_0_interrupts_256_IRQn + (timer_config->ch_Config_array[timer_channel_index].channel_no));
                  Cy_SysInt_InitIRQ(&my_irq_cfg);
                  Cy_SysInt_SetSystemIrqVector(my_irq_cfg.sysIntSrc, isr_handler_p);
                  NVIC_SetPriority(my_irq_cfg.intIdx, 4ul);
                  NVIC_EnableIRQ(my_irq_cfg.intIdx);
                  
                  Cy_Tcpwm_Counter_Init(timer_base_p, &MyCounter_config);
                  Cy_Tcpwm_Counter_Enable(timer_base_p);
                  Cy_Tcpwm_Counter_SetTC_IntrMask(timer_base_p); /* Enable Interrupt */
                  
                  
                }
            
          }
          else if(timer_config->timer_no == 2)
          {
            for(timer_channel_index = 0; timer_channel_index < (timer_config->cfg_array_no) ; timer_channel_index++)
              {
                MyCounter_config.period = timer_config->ch_Config_array[timer_channel_index].period;
                uint8_t ch_no = timer_config->ch_Config_array[timer_channel_index].channel_no;
                isr_handler_p = group2_isr_ptrs[ch_no];
                timer_base_p = group2_base_ptrs[ch_no];
                if (timer_config->ch_Config_array[timer_channel_index].callback_fun != NULL)
                    tcpwm0_group2_user_callback[ch_no] = timer_config->ch_Config_array[timer_channel_index].callback_fun;
                
                my_irq_cfg.sysIntSrc = (cy_en_intr_t)(tcpwm_0_interrupts_512_IRQn + (timer_config->ch_Config_array[timer_channel_index].channel_no));
                Cy_SysInt_InitIRQ(&my_irq_cfg);
                Cy_SysInt_SetSystemIrqVector(my_irq_cfg.sysIntSrc, isr_handler_p);
                NVIC_SetPriority(my_irq_cfg.intIdx, 4ul);
                NVIC_EnableIRQ(my_irq_cfg.intIdx);
                
                Cy_Tcpwm_Counter_Init(timer_base_p, &MyCounter_config);
                Cy_Tcpwm_Counter_Enable(timer_base_p);
                Cy_Tcpwm_Counter_SetTC_IntrMask(timer_base_p); /* Enable Interrupt */
              }
          }
            /*Cy_SysInt_InitIRQ(&my_irq_cfg);
            Cy_SysInt_SetSystemIrqVector(my_irq_cfg.sysIntSrc, isr_handler_p);
            NVIC_SetPriority(my_irq_cfg.intIdx, 4ul);
            NVIC_EnableIRQ(my_irq_cfg.intIdx);

            Cy_Tcpwm_Counter_Init(timer_base_p, &MyCounter_config);
            Cy_Tcpwm_Counter_Enable(timer_base_p);
            Cy_Tcpwm_Counter_SetTC_IntrMask(timer_base_p);  */
            break;

    }


}

//Init function of the PWM peripheral
static asdk_timer_ec_t cy_pwm_init(asdk_timer_config_t *timer_config)
{
        asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS ;
        uint8_t i = 0;
        MyPWM_config.period = timer_config->ch_Config_array->period;
        tcpwm0_isr_handler_p isr_handler_p = NULL;
        volatile stc_TCPWM_GRP_CNT_t *timer_base_p = NULL;

        /* check for ftm-timer mode range */
        if (((timer_config->ch_Config_array->timer_mode) > ASDK_FTM_MODE_NOT_INITIALIZED ) &&
            ((timer_config->ch_Config_array->timer_mode) < ASDK_FTM_MODE_UP_DOWN_TIMER ))
        {
            /* Do nothing */
        }   
        else
        {
            return ASDK_TIMER_INIT_FAIL;
        }

        

        if(timer_config->timer_no == 0)
        {
            
                for(i=0; (i < timer_config->cfg_array_no); i++)
                {
                        uint8_t ch_no = timer_config->ch_Config_array[i].channel_no;
                        MyCounter_config.period = timer_config->ch_Config_array[i].period;
                        isr_handler_p = group0_isr_ptrs[ch_no];
                        timer_base_p = group0_base_ptrs[ch_no];
                        if (timer_config->ch_Config_array[i].callback_fun != NULL)
                            tcpwm0_group0_user_callback[ch_no] = timer_config->ch_Config_array[i].callback_fun;
                        
                        my_irq_cfg.sysIntSrc = (cy_en_intr_t)(tcpwm_0_interrupts_0_IRQn + (timer_config->ch_Config_array[i].channel_no));
                        Cy_SysInt_InitIRQ(&my_irq_cfg);
                        Cy_SysInt_SetSystemIrqVector(my_irq_cfg.sysIntSrc, isr_handler_p);
                        NVIC_SetPriority(my_irq_cfg.intIdx, 4ul);
                        NVIC_EnableIRQ(my_irq_cfg.intIdx);
                        
                        /* Initialize TCPWMx_GRPx_CNTx_PWM_PR as PWM-DT Mode & Enable */
                        error_code = Cy_Tcpwm_Pwm_Init(timer_base_p, &MyPWM_config);
                        Cy_Tcpwm_Pwm_Enable(timer_base_p);
                        Cy_Tcpwm_TriggerStart(timer_base_p); /*Enable the interrupt*/

                        /*Alignement of PWM (Left, Right , Centre*/
                        if(timer_config->ch_Config_array[i].timer_mode == ASDK_FTM_MODE_CEN_ALIGNED_PWM)
                        {
                            Cy_Tcpwm_Pwm_CentreAlign(timer_base_p);
                        }
                        else if(timer_config->ch_Config_array[i].timer_mode == ASDK_FTM_MODE_EDGE_ALIGNED_PWM)
                        {
                            Cy_Tcpwm_Pwm_LeftAlign(timer_base_p);
                        }
                        else
                        {
                            return ASDK_TIMER_INIT_FAIL;

                        }
                        
                        
                }
        }
        else if(timer_config->timer_no == 1)
        {
            //Initialize the isrs with the chnanel isrs
            for(i=0; (i < timer_config->cfg_array_no); i++)
                {
                    uint8_t ch_no = timer_config->ch_Config_array[i].channel_no;
                    MyPWM_config.period = timer_config->ch_Config_array[i].period;
                    isr_handler_p = group1_isr_ptrs[ch_no];
                    timer_base_p = group1_base_ptrs[ch_no];
                    if (timer_config->ch_Config_array[i].callback_fun != NULL)
                        tcpwm0_group1_user_callback[ch_no] = timer_config->ch_Config_array[i].callback_fun;
                    
                    my_irq_cfg.sysIntSrc = (cy_en_intr_t)(tcpwm_0_interrupts_256_IRQn + (timer_config->ch_Config_array[i].channel_no));
                    Cy_SysInt_InitIRQ(&my_irq_cfg);
                    Cy_SysInt_SetSystemIrqVector(my_irq_cfg.sysIntSrc, isr_handler_p);
                    NVIC_SetPriority(my_irq_cfg.intIdx, 4ul);
                    NVIC_EnableIRQ(my_irq_cfg.intIdx);
                    
                    /* Initialize TCPWMx_GRPx_CNTx_PWM_PR as PWM-DT Mode & Enable */
                    error_code = Cy_Tcpwm_Pwm_Init(timer_base_p, &MyPWM_config);
                    Cy_Tcpwm_Pwm_Enable(timer_base_p);
                    Cy_Tcpwm_TriggerStart(timer_base_p); /*Enable the interrupt*/
                    
                                            /*Alignement of PWM (Left, Right , Centre*/
                    if(timer_config->ch_Config_array[i].timer_mode == ASDK_FTM_MODE_CEN_ALIGNED_PWM)
                    {
                        Cy_Tcpwm_Pwm_CentreAlign(timer_base_p);
                    }
                    else if(timer_config->ch_Config_array[i].timer_mode == ASDK_FTM_MODE_EDGE_ALIGNED_PWM)
                    {
                        Cy_Tcpwm_Pwm_LeftAlign(timer_base_p);
                    }
                    else
                    {
                        return ASDK_TIMER_INIT_FAIL;

                    }
                }
        }
        else if(timer_config->timer_no == 2)
        {
            
            for(i=0; (i < timer_config->cfg_array_no); i++)
                {
                    uint8_t ch_no = timer_config->ch_Config_array[i].channel_no;
                    MyPWM_config.period = timer_config->ch_Config_array[i].period;
                    isr_handler_p = group2_isr_ptrs[ch_no];
                    timer_base_p = group2_base_ptrs[ch_no];
                    if (timer_config->ch_Config_array[i].callback_fun != NULL)
                        tcpwm0_group2_user_callback[ch_no] = timer_config->ch_Config_array[i].callback_fun;
                    
                    my_irq_cfg.sysIntSrc = (cy_en_intr_t)(tcpwm_0_interrupts_512_IRQn + (timer_config->ch_Config_array[i].channel_no));
                    Cy_SysInt_InitIRQ(&my_irq_cfg);
                    Cy_SysInt_SetSystemIrqVector(my_irq_cfg.sysIntSrc, isr_handler_p);
                    NVIC_SetPriority(my_irq_cfg.intIdx, 4ul);
                    NVIC_EnableIRQ(my_irq_cfg.intIdx);
                    
                                                    /* Initialize TCPWMx_GRPx_CNTx_PWM_PR as PWM-DT Mode & Enable */
                    error_code = Cy_Tcpwm_Pwm_Init(timer_base_p, &MyPWM_config);
                    Cy_Tcpwm_Pwm_Enable(timer_base_p);
                    Cy_Tcpwm_TriggerStart(timer_base_p); /*Enable the interrupt*/
                    
                    /*Alignement of PWM (Left, Right , Centre*/
                    if(timer_config->ch_Config_array[i].timer_mode == ASDK_FTM_MODE_CEN_ALIGNED_PWM)
                    {
                        Cy_Tcpwm_Pwm_CentreAlign(timer_base_p);
                    }
                    else if(timer_config->ch_Config_array[i].timer_mode == ASDK_FTM_MODE_EDGE_ALIGNED_PWM)
                    {
                        Cy_Tcpwm_Pwm_LeftAlign(timer_base_p);
                    }
                    else
                    {
                        return ASDK_TIMER_INIT_FAIL;

                    }
                }
                    
            }
    else
    {
        error_code = ASDK_TIMER_INVALID_TIMER_NO;
    }

        
    if(error_code)
    {
        error_code = ASDK_TIMER_INIT_FAIL;
    }
        
     return error_code;
    
}

asdk_status_t timer_init( asdk_timer_config_t *timer_config)
{
    /* Local Variables to store TIMER status */
    asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS ;

	/* check for timer type */
    switch(timer_config->timer_type)
    {
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
            cy_timer_init(timer_config);
            break;
        
        // TCPWM0 group-1 timer
        case ASDK_TIMER_TYPE_FTM: // PWM
            cy_pwm_init(timer_config);
            break;

        case ASDK_TIMER_TYPE_SYSTICK:
            Cy_SysTick_Init(CY_SYSTICK_CLOCK_SOURCE_CLK_CPU, 80000);
            Cy_SysTick_SetCallback(0ul, systick_isr_handler);
            // Cy_SysTick_Enable();
            break;
        
        default:
            error_code  = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
    }

    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t timer_start ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t ch_no )
{
    /* Local Variables to store TIMER status */
	asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;

    switch(timer_type)
    {
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
        case ASDK_TIMER_TYPE_FTM: // PWM
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
                Cy_Tcpwm_TriggerStart(group0_base_ptrs[ch_no]);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
                Cy_Tcpwm_TriggerStart(group1_base_ptrs[ch_no]);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
                Cy_Tcpwm_TriggerStart(group2_base_ptrs[ch_no]);
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
        
        // TCPWM0 group-1 timer
       /* case ASDK_TIMER_TYPE_FTM: // PWM
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
                Cy_Tcpwm_TriggerStart(group0_base_ptrs[ch_no]);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
                Cy_Tcpwm_TriggerStart(group1_base_ptrs[ch_no]);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
                Cy_Tcpwm_TriggerStart(group2_base_ptrs[ch_no]);
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;*/
        
        case ASDK_TIMER_TYPE_SYSTICK:
            Cy_SysTick_Enable();
            break;

        default :
			error_code  = ASDK_TIMER_MOD_RANGE_EXCEEDED;
		    break;
    }

    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t timer_stop ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t ch_no)
{
    /* Local Variables to store TIMER status */
	asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;

    switch(timer_type)
    {
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
        case ASDK_TIMER_TYPE_FTM :
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
                Cy_Tcpwm_TriggerStopOrKill(group0_base_ptrs[ch_no]);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
                Cy_Tcpwm_TriggerStopOrKill(group1_base_ptrs[ch_no]);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
                Cy_Tcpwm_TriggerStopOrKill(group2_base_ptrs[ch_no]);
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
        
        // TCPWM0 group-1 timer
        /*case ASDK_TIMER_TYPE_FTM: // PWM
            Cy_Tcpwm_TriggerStopOrKill(group1_base_ptrs[ch_no]);
            break;*/
        
        case ASDK_TIMER_TYPE_SYSTICK:
            Cy_SysTick_Disable();
            break;

        default :
			error_code  = ASDK_TIMER_MOD_RANGE_EXCEEDED;
		    break;
    }

    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t timer_deinit(uint8_t timer_no, asdk_timer_type_t timer_type)
{
    /* Local Variables to store TIMER status */
	asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;

    	/* check for timer type */
    switch(timer_type)
    {
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
        case ASDK_TIMER_TYPE_FTM:
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
            {
                for(uint8_t ch_no=0; ch_no<CYT2B7_TCPWM0_GRP_0_CH_MAX; ch_no++)
                {
                    Cy_Tcpwm_Counter_DeInit(group0_base_ptrs[ch_no]);
                }
            }
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
            {
                for(uint8_t ch_no=0; ch_no<CYT2B7_TCPWM0_GRP_1_CH_MAX; ch_no++)
                {
                  Cy_Tcpwm_Pwm_DeInit(group1_base_ptrs[ch_no]);
                }
            }
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
            {
                for(uint8_t ch_no=0; ch_no<CYT2B7_TCPWM0_GRP_2_CH_MAX; ch_no++)
                {
                    Cy_Tcpwm_Counter_DeInit(group2_base_ptrs[ch_no]);
                }
            }
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
        
        // TCPWM0 group-1 timer
       /* case ASDK_TIMER_TYPE_FTM: // PWM
            for(uint8_t ch_no=0; ch_no<CYT2B7_TCPWM0_GRP_1_CH_MAX; ch_no++)
                Cy_Tcpwm_Pwm_DeInit(group1_base_ptrs[ch_no]);
            break;*/
        
        case ASDK_TIMER_TYPE_SYSTICK:
            Cy_SysTick_Clear();
            Cy_SysTick_Disable();
            break;
        
        default:
            error_code  = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
    }

    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t timer_set_timer_period(uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t time_us)
{
    /* Local Variables to store TIMER status */
	asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;

    	/* check for timer type */
    switch(timer_type)
    {
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
                //Cy_Tcpwm_Counter_SetPeriod(TCPWM0_GRP0_CNT0, (uint32_t) time_us);
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
                Cy_Tcpwm_Counter_SetPeriod(group0_base_ptrs[channel], (uint32_t) time_us);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
                Cy_Tcpwm_Counter_SetPeriod(group1_base_ptrs[channel], (uint32_t) time_us);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
                Cy_Tcpwm_Counter_SetPeriod(group2_base_ptrs[channel], (uint32_t) time_us);
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
        
        // TCPWM0 group-1 timer
        case ASDK_TIMER_TYPE_FTM: // PWM
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
                Cy_Tcpwm_Pwm_SetPeriod(group0_base_ptrs[channel], (uint32_t) time_us);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
                Cy_Tcpwm_Pwm_SetPeriod(group1_base_ptrs[channel], (uint32_t) time_us);
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
                Cy_Tcpwm_Pwm_SetPeriod(group2_base_ptrs[channel], (uint32_t) time_us);
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;

        
        case ASDK_TIMER_TYPE_SYSTICK:
            Cy_SysTick_SetReload((uint32_t) time_us);
            break;

        default:
            error_code  = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
    }

    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t timer_set_timer_duty(uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t time_us)
{
    /* Local Variables to store TIMER status */
	asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;
        if (timer_no == CYT2B7_TCPWM0_GROUP_0)
            Cy_Tcpwm_Pwm_SetCompare0(group0_base_ptrs[channel], (uint32_t) time_us);
        else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
            Cy_Tcpwm_Pwm_SetCompare0(group1_base_ptrs[channel], (uint32_t) time_us);
        else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
            Cy_Tcpwm_Pwm_SetCompare0(group2_base_ptrs[channel], (uint32_t) time_us);
        else
            error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
     
       // Cy_Tcpwm_Pwm_SetCompare0(group1_base_ptrs[channel], time_us);
    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t timer_get_current_time_ms ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t *current_time_ms )
{
    /* Local Variables to store TIMER status */
    asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;

    /* check for timer type */
    switch(timer_type)
    {
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
        case ASDK_TIMER_TYPE_FTM:
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
                *current_time_ms = g0_counter[channel];
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
                *current_time_ms = g1_counter[channel];
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
                *current_time_ms = g2_counter[channel];
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
        
        // TCPWM0 group-1 timer
      /*  case ASDK_TIMER_TYPE_FTM: // PWM
            *current_time_ms = g1_counter[channel];
            break;*/
        
        case ASDK_TIMER_TYPE_SYSTICK:
            *current_time_ms = sys_tick_counter;
            break;
        
        default:
            error_code  = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
    }

    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}

asdk_status_t timer_get_current_time_us ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t *current_time_us  )
{
    /* Local Variables to store TIMER status */
	asdk_timer_ec_t error_code = ASDK_TIMER_STATUS_SUCCESS;

        /* check for timer type */
    switch(timer_type)
    {
        // TCPWM0 group-0 timer
        case ASDK_TIMER_TYPE_LPIT:
        case ASDK_TIMER_TYPE_LPTMR:
        case ASDK_TIMER_TYPE_PIT:
            if (timer_no == CYT2B7_TCPWM0_GROUP_0)
                *current_time_us = g0_counter[channel] * 1000;
            else if (timer_no == CYT2B7_TCPWM0_GROUP_1)
                *current_time_us = g1_counter[channel] * 1000;
            else if (timer_no == CYT2B7_TCPWM0_GROUP_2)
                *current_time_us = g2_counter[channel] * 1000;
            else
                error_code = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
        
        // TCPWM0 group-1 timer
        /*case ASDK_TIMER_TYPE_FTM: // PWM
            *current_time_us = g1_counter[channel] * 1000;
            break;*/
        
        case ASDK_TIMER_TYPE_SYSTICK:
            *current_time_us = sys_tick_counter * 1000;
            break;
        
        default:
            error_code  = ASDK_TIMER_MOD_RANGE_EXCEEDED;
            break;
    }

    return ASDK_TIMER_RETURN(ASDK_LC_HARDWARE, error_code);
}


static void group0_ch0_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_0]++;
    if(Cy_Tcpwm_Counter_GetTC_IntrMasked(TCPWM0_GRP0_CNT0))
    {
        // PC reaches here when the counter gets over the period value.
        Cy_Tcpwm_Counter_ClearTC_Intr(TCPWM0_GRP0_CNT0);
        //g_CntValWhenIntr = Cy_Tcpwm_Counter_GetCounter(TCPWM0_GRP0_CNT1);
    }
    if (tcpwm0_group0_user_callback[CYT2B7_TCPWM0_GRP_0_CH_0] != NULL)
        tcpwm0_group0_user_callback[CYT2B7_TCPWM0_GRP_0_CH_0](CYT2B7_TCPWM0_GROUP_0, ASDK_TIMER_TYPE_PIT, CYT2B7_TCPWM0_GRP_0_CH_0);
}

static void group0_ch1_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_1]++;
    if(Cy_Tcpwm_Counter_GetTC_IntrMasked(TCPWM0_GRP0_CNT1))
    {
        // PC reaches here when the counter gets over the period value.
        Cy_Tcpwm_Counter_ClearTC_Intr(TCPWM0_GRP0_CNT1);
        //g_CntValWhenIntr = Cy_Tcpwm_Counter_GetCounter(TCPWM0_GRP0_CNT1);
    }
}

static void group0_ch2_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_2]++;
}

static void group0_ch3_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_3]++;
}

static void group0_ch4_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_4]++;
}

static void group0_ch5_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_5]++;
}

static void group0_ch6_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_6]++;
}

static void group0_ch7_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_7]++;
}

static void group0_ch8_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_8]++;
}

static void group0_ch9_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_9]++;
}

static void group0_ch10_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_10]++;
}

static void group0_ch11_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_11]++;
}

static void group0_ch12_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_12]++;
}

static void group0_ch13_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_13]++;
}

static void group0_ch14_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_14]++;
}

static void group0_ch15_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_15]++;
}

static void group0_ch16_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_16]++;
}

static void group0_ch17_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_17]++;
}

static void group0_ch18_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_18]++;
}

static void group0_ch19_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_19]++;
}

static void group0_ch20_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_20]++;
}

static void group0_ch21_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_21]++;
}

static void group0_ch22_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_22]++;
}

static void group0_ch23_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_23]++;
}

static void group0_ch24_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_24]++;
}

static void group0_ch25_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_25]++;
}

static void group0_ch26_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_26]++;
}

static void group0_ch27_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_27]++;
}

static void group0_ch28_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_28]++;
}

static void group0_ch29_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_29]++;
}

static void group0_ch30_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_30]++;
}

static void group0_ch31_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_31]++;
}

static void group0_ch32_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_32]++;
}

static void group0_ch33_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_33]++;
}

static void group0_ch34_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_34]++;
}

static void group0_ch35_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_35]++;
}

static void group0_ch36_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_36]++;
}

static void group0_ch37_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_37]++;
}

static void group0_ch38_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_38]++;
}

static void group0_ch39_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_39]++;
}

static void group0_ch40_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_40]++;
}

static void group0_ch41_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_41]++;
}

static void group0_ch42_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_42]++;
}

static void group0_ch43_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_43]++;
}

static void group0_ch44_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_44]++;
}

static void group0_ch45_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_45]++;
}

static void group0_ch46_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_46]++;
}

static void group0_ch47_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_47]++;
}

static void group0_ch48_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_48]++;
}

static void group0_ch49_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_49]++;
}

static void group0_ch50_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_50]++;
}

static void group0_ch51_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_51]++;
}

static void group0_ch52_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_52]++;
}

static void group0_ch53_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_53]++;
}

static void group0_ch54_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_54]++;
}

static void group0_ch55_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_55]++;
}

static void group0_ch56_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_56]++;
}

static void group0_ch57_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_57]++;
}

static void group0_ch58_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_58]++;
}

static void group0_ch59_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_59]++;
}

static void group0_ch60_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_60]++;
}

static void group0_ch61_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_61]++;
}

static void group0_ch62_isr_handler(void)
{
    g0_counter[CYT2B7_TCPWM0_GRP_0_CH_62]++;
}
 // GROUP_0_ISR

/*static void group1_ch0_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_0]++;

    if (tcpwm0_group1_user_callback[CYT2B7_TCPWM0_GRP_1_CH_0] != NULL)
        tcpwm0_group1_user_callback[CYT2B7_TCPWM0_GRP_1_CH_0]( CYT2B7_TCPWM0_GROUP_1, ASDK_TIMER_TYPE_PIT, CYT2B7_TCPWM0_GRP_1_CH_0);
}*/


#if 1// GROUP_1_ISR
static void group1_ch0_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_0]++;
    if (tcpwm0_group1_user_callback[CYT2B7_TCPWM0_GRP_1_CH_0] != NULL)
    tcpwm0_group1_user_callback[CYT2B7_TCPWM0_GRP_1_CH_0]( CYT2B7_TCPWM0_GROUP_1, ASDK_TIMER_TYPE_FTM, CYT2B7_TCPWM0_GRP_1_CH_0);
}

static void group1_ch1_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_1]++;
}

static void group1_ch2_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_2]++;
}

static void group1_ch3_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_3]++;
}

static void group1_ch4_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_4]++;
}

static void group1_ch5_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_5]++;
}

static void group1_ch6_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_6]++;
}

static void group1_ch7_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_7]++;
}

static void group1_ch8_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_8]++;
}

static void group1_ch9_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_9]++;
}

static void group1_ch10_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_10]++;
}

static void group1_ch11_isr_handler(void)
{
    g1_counter[CYT2B7_TCPWM0_GRP_1_CH_11]++;
}
#endif // GROUP_1_ISR

static void group2_ch0_isr_handler(void)
{
    g2_counter[CYT2B7_TCPWM0_GRP_2_CH_0]++;

    if (tcpwm0_group2_user_callback[CYT2B7_TCPWM0_GRP_2_CH_0] != NULL)
        tcpwm0_group2_user_callback[CYT2B7_TCPWM0_GRP_2_CH_0]( CYT2B7_TCPWM0_GROUP_2, ASDK_TIMER_TYPE_PIT, CYT2B7_TCPWM0_GRP_2_CH_0);
}

#if 1 // GROUP_2_ISR
static void group2_ch1_isr_handler(void)
{
    g2_counter[CYT2B7_TCPWM0_GRP_2_CH_1]++;
}

static void group2_ch2_isr_handler(void)
{
    g2_counter[CYT2B7_TCPWM0_GRP_2_CH_2]++;
}

static void group2_ch3_isr_handler(void)
{
    g2_counter[CYT2B7_TCPWM0_GRP_2_CH_3]++;
}
#endif // GROUP_2_ISR
