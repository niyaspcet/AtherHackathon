/*
  @file
  hw_spi.c

  @path
  /asdk/src/hw_spi.c

  @Created on
  Apr 04, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hw_spi.h"
#include "scb/cy_scb_spi.h"
#include "scb_config.h"
#include "hw_scb_int.h"

/*==============================================================================

                        LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
// static const char filename[] = "hw_spi.c";

/*! Driver state structure */
static cy_stc_scb_spi_context_t g_stc_spi_context[MAX_SPI_MOD];

/* static array of function pointer to hold user callback function */
static asdk_spi_callback_fun_t user_spi_callback_fun_list[MAX_SPI_MOD];

/* Callback for all peripherals which supports SPI features */
void SPI0_ISR_UserCallback(void);
void SPI1_ISR_UserCallback(void);

scb_user_cb_type SPI_User_callbacks[MAX_SPI_MOD] = {
    SPI0_ISR_UserCallback,
    SPI1_ISR_UserCallback,
};

extern volatile stc_SCB_t *scb_base_ptrs[];
extern uint8_t scb_spi[];
uint32_t master_transferStatus;

void scb_spi0_callback_handler(uint32_t event_t);
void scb_spi1_callback_handler(uint32_t event_t);
static cy_stc_scb_spi_config_t SCB_SPI_cfg =
    {
        .spiMode = CY_SCB_SPI_SLAVE,        /*** Specifies the mode of operation    ***/
        .subMode = CY_SCB_SPI_MOTOROLA,     /*** Specifies the submode of SPI operation    ***/
        .sclkMode = CY_SCB_SPI_CPHA0_CPOL0, /*** Clock is active low, data is changed on first edge ***/
        .oversample = SCB_SPI_OVERSAMPLING, /*** SPI_CLOCK divided by SCB_SPI_OVERSAMPLING shoud be baudrate  ***/
        .rxDataWidth = 16,                  /*** The width of RX data (valid range 4-16). It must be the same as \ref txDataWidth except in National sub-mode. ***/
        .txDataWidth = 16,                  /*** The width of TX data (valid range 4-16). It must be the same as \ref rxDataWidth except in National sub-mode. ***/
        .enableMsbFirst = true,             /*** Enables the hardware to shift out the data element MSB first, otherwise, LSB first ***/
        .enableFreeRunSclk = false,         /*** Enables the master to generate a continuous SCLK regardless of whether there is data to send  ***/
        .enableInputFilter = false,         /*** Enables a digital 3-tap median filter to be applied to the input of the RX FIFO to filter glitches on the line. ***/
        .enableMisoLateSample = true,       /*** Enables the master to sample MISO line one half clock later to allow better timings. ***/
        .enableTransferSeperation = true,   /*** Enables the master to transmit each data element separated by a de-assertion of the slave select line (only applicable for the master mode) ***/
        .ssPolarity0 = 0,                   /*** SS0: active low ***/
        .ssPolarity1 = 0,                   /*** SS1: active low ***/
        .ssPolarity2 = 0,                   /*** SS2: active low ***/
        .ssPolarity3 = 0,                   /*** SS3: active low ***/
        .enableWakeFromSleep = 0,           /*** When set, the slave will wake the device when the slave select line becomes active. Note that not all SCBs support this mode. Consult the device datasheet to determine which SCBs support wake from deep sleep. ***/
        // In case of using high level APIs, an user does not need to set these parameter. These parameter will be set in high level APIs such as "Cy_SCB_SPI_Transfer".
        .txFifoTriggerLevel = 0,       /*** When there are fewer entries in the TX FIFO, then at this level the TX trigger output goes high. This output can be connected to a DMA channel through a trigger mux. Also, it controls the \ref CY_SCB_SPI_TX_TRIGGER interrupt source. ***/
        .rxFifoTriggerLevel = 255,     /*** When there are more entries in the RX FIFO, then at this level the RX trigger output goes high. This output can be connected to a DMA channel through a trigger mux. Also, it controls the \ref CY_SCB_SPI_RX_TRIGGER interrupt source.  ***/
        .rxFifoIntEnableMask = 0,      /*** Bits set in this mask will allow events to cause an interrupt  ***/
        .txFifoIntEnableMask = 0,      /*** Bits set in this mask allow events to cause an interrupt  ***/
        .masterSlaveIntEnableMask = 0, /*** Bits set in this mask allow events to cause an interrupt  ***/
        .enableSpiDoneInterrupt = 0,
        .enableSpiBusErrorInterrupt = 0,
};
/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/
/*!@brief macro to define SPI_SOURCE_CLOCK */
// #define SPI_SOURCE_CLOCK	48000000U

/*!@brief macro to define TIMEOUT_MS */
// #define TIMEOUT_MS	100000

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/

/*==============================================================================

                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/* Function : spi_master_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Initializes an SPI master operation instance

  @param spi_master_config_t spi_config_data

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_STATUS_SUCCESS if successful uart init;
                                        ASDK_SPI_INIT_FAIL if an error occurred

*/
asdk_status_t spi_master_init(asdk_spi_master_config_t *spi_config_data)
{

        /* Local status Variables */
        asdk_spi_ec_t error_code;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_config_data->spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_config_data->spi_no >= MAX_SPI_MOD ) */

        /* cyt2b7 supports maximum 4 Slave Select Lines */
        if (MAX_SLAVE_SELECTS <= spi_config_data->which_pcs)
        {
                error_code = ASDK_PEC_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if( spi_config_data->which_pcs > MAX_SPI_MOD) */

        scb_index = scb_spi[spi_config_data->spi_no];
        scb = scb_base_ptrs[scb_index];

        SCB_SPI_cfg.spiMode = CY_SCB_SPI_MASTER;
        SCB_SPI_cfg.rxDataWidth = spi_config_data->bit_count;
        SCB_SPI_cfg.txDataWidth = spi_config_data->bit_count;
        if ((spi_config_data->clk_phase == 0) && (spi_config_data->clk_polarity == 0))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA0_CPOL0;
        }
        else if ((spi_config_data->clk_phase == 0) && (spi_config_data->clk_polarity == 1))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA0_CPOL1;
        }
        else if ((spi_config_data->clk_phase == 1) && (spi_config_data->clk_polarity == 0))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA1_CPOL0;
        }
        else if ((spi_config_data->clk_phase == 1) && (spi_config_data->clk_polarity == 1))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA1_CPOL1;
        }
        SCB_SPI_cfg.enableMsbFirst = (1 - (spi_config_data->direction));
        // SCB_SPI_cfg.enableFreeRunSclk  = true;
        // SCB_SPI_cfg.enableTransferSeperation = true;
        /* Configure the user interrupt handler to make the high-level API work*/
        SCB_Set_DAL_Callback(scb_index, SPI_User_callbacks[spi_config_data->spi_no]);

        /*Initialize the SPI Instance*/
        Cy_SCB_SPI_DeInit(scb);

        /*SCB Initilization for SPI communication*/
        error_code = (asdk_spi_ec_t)Cy_SCB_SPI_Init(scb, &SCB_SPI_cfg, &g_stc_spi_context[spi_config_data->spi_no]);

        /*Slave Select from four available Slave Selects*/
        Cy_SCB_SPI_SetActiveSlaveSelect(scb, spi_config_data->which_pcs);

        /*Enable the SPI module*/
        Cy_SCB_SPI_Enable(scb);

        // Set delay between transfers to 1uS
        // if (error_code == ASDK_SPI_STATUS_SUCCESS)
        // error_code = LPSPI_DRV_MasterSetDelay(spi_config_data->spi_no, 1, 0, 0);
        // else
        //	error_code = ASDK_SPI_INIT_FAIL;

        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_master_init */

/*----------------------------------------------------------------------------*/
/* Function : spi_master_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-Initializes an SPI master operation instance

  @param uint8_t spi_no

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_DEINIT_FAIL if an error occurred

*/
asdk_status_t spi_master_deinit(uint8_t spi_no)
{
        /* Local status Variables */
        asdk_spi_ec_t error_code = ASDK_SPI_STATUS_SUCCESS;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        scb_index = scb_spi[spi_no];
        scb = scb_base_ptrs[scb_index];
        /* Algorithm */
        Cy_SCB_SPI_DeInit(scb);
        SCB_Clear_DAL_Callback(scb_index);

        if (error_code)
                error_code = ASDK_SPI_DEINIT_FAIL;

        /* return status */
        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_master_deinit */

/*----------------------------------------------------------------------------*/
/* Function : spi_master_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback for spi master data transfer.

  @param uint8_t spi_no

  @param spi_callback_config_t *callback_data

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_STATUS_SUCCESS if successful callback installation
*/
asdk_status_t spi_master_install_callback(uint8_t spi_no, asdk_spi_callback_fun_t callback_fun)
{

        /* Local status Variables */
        asdk_spi_ec_t error_code;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        scb_index = scb_spi[spi_no];
        scb = scb_base_ptrs[scb_index];

        /* assign hw callback function name */
        switch (spi_no)
        {
        case 0:
                Cy_SCB_SPI_RegisterCallback(scb, (scb_spi_handle_events_t)scb_spi0_callback_handler, &g_stc_spi_context[spi_no]);
                break;
        case 1:
                Cy_SCB_SPI_RegisterCallback(scb, (scb_spi_handle_events_t)scb_spi1_callback_handler, &g_stc_spi_context[spi_no]);
                break;
        default:
                break;
        }

        /* store callback function */
        user_spi_callback_fun_list[spi_no] = callback_fun;

        error_code = ASDK_SPI_STATUS_SUCCESS;
        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_master_install_callback */

/*----------------------------------------------------------------------------*/
/* Function : spi_master_transfer_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function transfers data out through the SPI master module using blocking method

  @param uint8_t spi_no

  @param uint8_t *send_buf

  @param uint8_t *recv_buf

  @param uint8_t length

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_TRANSFER_FAIL if transfer fails

*/
asdk_status_t spi_master_transfer_blocking(uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length)
{

        /* Local Variables */
        asdk_spi_ec_t error_code;
        // uint8_t scb_index;
        //  volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        // scb_index = scb_spi[spi_no];
        // scb = scb_base_ptrs[scb_index];

        // error_code = LPSPI_DRV_MasterTransferBlocking(spi_no, send_buf, recv_buf, length, TIMEOUT_MS);

        // if (error_code)
        //	error_code = ASDK_SPI_TRANSFER_FAIL;
        error_code = ASDK_SPI_FEATURE_NOT_IMPLEMENTED;

        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_master_transfer_blocking */

/*----------------------------------------------------------------------------*/
/* Function : spi_master_transfer_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function transfers data out through the SPI master module using non-blocking method

  @param uint8_t spi_no

  @param uint8_t *send_buf

  @param uint8_t *recv_buf

  @param uint8_t length

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_TRANSFER_FAIL if transfer fails

*/
asdk_status_t spi_master_transfer_non_blocking(uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length)
{

        /* Local Variables */
        asdk_spi_ec_t error_code;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        scb_index = scb_spi[spi_no];
        scb = scb_base_ptrs[scb_index];

        error_code = (asdk_spi_ec_t)Cy_SCB_SPI_Transfer(scb, send_buf, recv_buf, length, &g_stc_spi_context[spi_no]);

        // while(spi_state[spi_no].isTransferInProgress);

        if (error_code)
                error_code = ASDK_SPI_TRANSFER_FAIL;

        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_master_transfer_non_blocking */

asdk_status_t spi_master_transfer_status(uint8_t spi_no)
{
        asdk_spi_ec_t error_code = ASDK_SPI_STATUS_SUCCESS;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        scb_index = scb_spi[spi_no];
        scb = scb_base_ptrs[scb_index];

        master_transferStatus = Cy_SCB_SPI_GetTransferStatus(scb, &g_stc_spi_context[spi_no]);

        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
}

/*----------------------------------------------------------------------------*/
/* Function : spi_slave_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Initializes an SPI slave operation instance

  @param spi_slave_config_t spi_config_data

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_PEC_RANGE_EXCEEDED if pec invalid
                                        ASDK_SPI_INIT_FAIL if init fails

*/
asdk_status_t spi_slave_init(asdk_spi_slave_config_t *spi_config_data)
{

        /* Local status Variables */
        asdk_spi_ec_t error_code = ASDK_SPI_STATUS_ERROR;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_config_data->spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_config_data->spi_no >= MAX_SPI_MOD) */

        /* cyt2b7 supports maximum 4 Slave Selects */
        if (MAX_SLAVE_SELECTS <= spi_config_data->which_pcs)
        {
                error_code = ASDK_PEC_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if( spi_config_data->which_pcs > MAX_SPI_MOD) */

        scb_index = scb_spi[spi_config_data->spi_no];
        scb = scb_base_ptrs[scb_index];

        SCB_SPI_cfg.spiMode = CY_SCB_SPI_SLAVE;
        SCB_SPI_cfg.rxDataWidth = spi_config_data->bit_count;
        SCB_SPI_cfg.txDataWidth = spi_config_data->bit_count;
        if ((spi_config_data->clk_phase == 0) && (spi_config_data->clk_polarity == 0))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA0_CPOL0;
        }
        else if ((spi_config_data->clk_phase == 0) && (spi_config_data->clk_polarity == 1))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA0_CPOL1;
        }
        else if ((spi_config_data->clk_phase == 1) && (spi_config_data->clk_polarity == 0))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA1_CPOL0;
        }
        else if ((spi_config_data->clk_phase == 1) && (spi_config_data->clk_polarity == 1))
        {
                SCB_SPI_cfg.sclkMode = CY_SCB_SPI_CPHA1_CPOL1;
        }

        /* Configure the user interrupt handler to make the high-level API work*/
        SCB_Set_DAL_Callback(scb_index, SPI_User_callbacks[spi_config_data->spi_no]);

        /*Initialize the SPI Instance*/
        Cy_SCB_SPI_DeInit(scb);

        /*SCB Initilization for SPI communication*/
        error_code = (asdk_spi_ec_t)Cy_SCB_SPI_Init(scb, &SCB_SPI_cfg, &g_stc_spi_context[spi_config_data->spi_no]);

        /*Slave Select from four available Slave Selects*/
        Cy_SCB_SPI_SetActiveSlaveSelect(scb, spi_config_data->which_pcs);

        /*Enable the SPI module*/
        Cy_SCB_SPI_Enable(scb);

        // error_code = LPSPI_DRV_SlaveInit(spi_config_data->spi_no, &spi_state[spi_config_data->spi_no], &spi_slave_config);

        if (error_code)
                error_code = ASDK_SPI_INIT_FAIL;

        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_slave_init */

/*----------------------------------------------------------------------------*/
/* Function : spi_slave_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-Initializes an SPI slave operation instance

  @param uint8_t spi_no

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_DEINIT_FAIL if deinit fails

*/
asdk_status_t spi_slave_deinit(uint8_t spi_no)
{

        /* Local Variables */
        asdk_spi_ec_t error_code = ASDK_SPI_STATUS_SUCCESS;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        /* Algorithm */
        scb_index = scb_spi[spi_no];
        scb = scb_base_ptrs[scb_index];
        /* Algorithm */
        Cy_SCB_SPI_DeInit(scb);
        SCB_Clear_DAL_Callback(scb_index);

        if (error_code)
                error_code = ASDK_SPI_DEINIT_FAIL;

        /* return status */
        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_slave_deinit */

/*----------------------------------------------------------------------------*/
/* Function : spi_slave_transfer_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function transfers data out through the SPI slave module using blocking method

  @param uint8_t spi_no

  @param uint8_t *send_buf

  @param uint8_t *recv_buf

  @param uint8_t length

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_TRANSFER_FAIL if transfer fails

*/
asdk_status_t spi_slave_transfer_blocking(uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length)
{

        /* Local Variables */
        asdk_spi_ec_t error_code;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        // error_code = LPSPI_DRV_SlaveTransferBlocking(spi_no, send_buf, recv_buf, length, TIMEOUT_MS);

        // if (error_code)
        error_code = ASDK_SPI_FEATURE_NOT_IMPLEMENTED;

        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_slave_transfer_blocking */

/*----------------------------------------------------------------------------*/
/* Function : spi_slave_transfer_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function transfers data out through the SPI slave module using non-blocking method

  @param uint8_t spi_no

  @param uint8_t *send_buf

  @param uint8_t *recv_buf

  @param uint8_t length

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_TRANSFER_FAIL if transfer fails

*/
asdk_status_t spi_slave_transfer_non_blocking(uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length)
{

        /* Local Variables */
        asdk_spi_ec_t error_code;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        scb_index = scb_spi[spi_no];
        scb = scb_base_ptrs[scb_index];

        error_code = (asdk_spi_ec_t)Cy_SCB_SPI_Transfer(scb, send_buf, recv_buf, length, &g_stc_spi_context[spi_no]);

        // error_code = LPSPI_DRV_SlaveTransfer(spi_no, send_buf, recv_buf, length);

        if (error_code)
                error_code = ASDK_SPI_TRANSFER_FAIL;

        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_slave_transfer_non_blocking */

/*----------------------------------------------------------------------------*/
/* Function : spi_slave_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback for spi slave data transfer.

  @param uint8_t spi_no

  @param spi_callback_config_t *callback_data

  @return asdk_status_t  ASDK_SPI_RANGE_EXCEEDED if spi range exceeded
                                        ASDK_SPI_STATUS_SUCCESS if callback installed

*/
asdk_status_t spi_slave_install_callback(uint8_t spi_no, asdk_spi_callback_fun_t callback_fun)
{
        /* Local Variables */
        asdk_spi_ec_t error_code;
        uint8_t scb_index;
        volatile stc_SCB_t *scb = NULL;

        /* check for max spi module */
        if (MAX_SPI_MOD <= spi_no)
        {
                error_code = ASDK_SPI_RANGE_EXCEEDED;
                return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);
        } /* if(spi_no >= MAX_SPI_MOD) */

        /* assign hw callback function name */
        scb_index = scb_spi[spi_no];
        scb = scb_base_ptrs[scb_index];

        /* assign hw callback function name */
        switch (spi_no)
        {
        case 0:
                Cy_SCB_SPI_RegisterCallback(scb, (scb_spi_handle_events_t)scb_spi0_callback_handler, &g_stc_spi_context[spi_no]);
                break;
        case 1:
                Cy_SCB_SPI_RegisterCallback(scb, (scb_spi_handle_events_t)scb_spi1_callback_handler, &g_stc_spi_context[spi_no]);
                break;
        default:
                break;
        }

        /* store callback function */
        user_spi_callback_fun_list[spi_no] = callback_fun;

        error_code = ASDK_SPI_STATUS_SUCCESS;
        return ASDK_SPI_RETURN(ASDK_LC_HARDWARE, error_code);

} /* spi_master_install_callback */

/*----------------------------------------------------------------------------*/
/* Function : spi_master_callback_handler */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data through the spi master module using non blocking method

  @param void *driverState

  @param spi_event_t event

  @param void *userData

  @return void

*/
void scb_spi0_callback_handler(uint32_t event)
{

        uint8_t spi_no = 0;

        switch (event)
        {
        case CY_SCB_SPI_TRANSFER_CMPLT_EVENT:

                /* process user function after end of transfer */
                user_spi_callback_fun_list[spi_no](spi_no, g_stc_spi_context[0].rxBuf, g_stc_spi_context[0].rxBufIdx, ASDK_SPI_MASTER);
                break;

        default:
                break;
        }
}

/*----------------------------------------------------------------------------*/
/* Function : spi_slave_callback_handler */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data through the spi slave module using non blocking method

  @param void *driverState

  @param spi_event_t event

  @param void *userData

  @return void

*/
void scb_spi1_callback_handler(uint32_t event)
{
        uint8_t spi_no = 1;

        switch (event)
        {
        case CY_SCB_SPI_TRANSFER_CMPLT_EVENT:

                /* process user function after end of transfer */
                user_spi_callback_fun_list[spi_no](spi_no, g_stc_spi_context[1].rxBuf, g_stc_spi_context[1].rxBufIdx, ASDK_SPI_MASTER);
                break;

        default:
                break;
        }
}

void SPI0_ISR_UserCallback(void)
{
        /* I2C interrupt handler for High-Level APIs */
        Cy_SCB_SPI_Interrupt(scb_base_ptrs[scb_spi[0]], &g_stc_spi_context[0]);
}

void SPI1_ISR_UserCallback(void)
{
        /* I2C interrupt handler for High-Level APIs */
        Cy_SCB_SPI_Interrupt(scb_base_ptrs[scb_spi[1]], &g_stc_spi_context[1]);
}
