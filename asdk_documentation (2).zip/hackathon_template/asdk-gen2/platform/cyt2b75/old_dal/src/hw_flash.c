/*
  @file
  hw_flash.c

  @path
  /platform/platform/cyt2b7/dal/src/hw_flash.c

  @Created on
  Feb 27, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

/*==============================================================================

						   INCLUDE FILES

==============================================================================*/
#include "hw_flash.h"
#include <string.h>
#include "flash/cy_flash.h"
#include "srom/cy_srom.h"

/*==============================================================================

						LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
// static const char filename[] = "hw_flash.c";

/*==============================================================================

					  LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define FLASH_USER_MARGIN 					0x1U
#define FLASH_FACTORY_MARGIN			 	0x2U
#define CODE_LARGE_SECTOR_SIZE_CYT2B7 		CY_CODE_LES_SIZE_IN_BYTE // 32KB
#define CODE_SMALL_SECTOR_SIZE_CYT2B7 		CY_CODE_SES_SIZE_IN_BYTE // 8KB
#define WORK_LARGE_SECTOR_SIZE_CYT2B7 		CY_WORK_LES_SIZE_IN_BYTE // 2KB
#define WORK_SMALL_SECTOR_SIZE_CYT2B7 		CY_WORK_SES_SIZE_IN_BYTE // 128B
#define SECTOR_SIZE_142 					0x800								   // Erase only 2kB at a time
#define DATA_WRITE_SIZE 					8
#define WORKFLASH_START_ADDRESS                 0x14000000
#define WORKFLASH_END_ADDRESS                   0x14017fff
#define CODEFLASH_START_ADDRESS                 0x10000000
#define CODEFLASH_END_ADDRESS                   0x1010ffff

#define FLASH_SECTOR_SIZE 				CODE_LARGE_SECTOR_SIZE_CYT2B7
#define FLASH_SECTOR_SIZE_D 				WORK_LARGE_SECTOR_SIZE_CYT2B7
/*==============================================================================

					  LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

					LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/
/* Declare a Flash config struct which initialized by FlashInit, and will be used by all flash operations */
/*flash_ssd_config_t flash_ssd_config;

/*! @brief Configuration structure flashCfg_0 */

/*const flash_user_config_t flash_init_config = {
		.PFlashBase  = 0x00000000U,
		.PFlashSize  = 0x00080000U,
		.DFlashBase  = 0x10000000U,
		.EERAMBase   = 0x14000000U,
		.CallBack    = NULL_CALLBACK
};*/
bool _g_completeFlag = false;
bool _g_NB_ModeEnabled = false;
/*==============================================================================

							LOCAL FUNCTION PROTOTYPES

==============================================================================*/
asdk_flash_callback_fun_t user_flash_callback_function;

/*==============================================================================

							LOCAL FUNCTION DEFINITIONS

==============================================================================*/
static void Cy_FlashHandler(void)
{
	un_srom_api_resps_t apiResp;
	cy_en_srom_api_status_t sromDrvStatus = Cy_Srom_GetApiResponse(&apiResp);
	CY_ASSERT(sromDrvStatus == CY_SROM_STATUS_SUCCESS);
	// Calling the user callback function once the interrupt comes.
	user_flash_callback_function();
	_g_completeFlag = true;
	Cy_Flashc_InvalidateFlashCacheBuffer();
}

/*******************************************************************************
 * Function Cy_Is_SROM_API_Completed
 ****************************************************************************/
/**
 *
 * A Function for user to know whether CM0+ completed erase/program Flash or not.
 * In non-blocking mode, it return "true" always.
 *
 * \return true : CM0+ has completed requested SROM API.
 *         false: CM0+ has not completed requested SROM API yet.
 *
 *******************************************************************************/
bool Cy_Is_SROM_API_Completed(void)
{
	return _g_completeFlag;
}

/*----------------------------------------------------------------------------*/
/* Function : flash_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initialize flash program flash(p-flash) of s32k144.

  @param void

  @return asdk_status_t ASDK_FLASH_STATUS_SUCCESS - on successful init.
						ASDK_FLASH_INIT_FAIL - on failure

*/
asdk_status_t flash_init(void)
{

	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;

	// Change the function call to cy_flash.c and remove from the middleware layer

	// Cy_FlashInit(false/*blocking*/);
	// This needs to be passed as parameter in the init function
	bool non_blocking = false;

	if (non_blocking == true)
	{
		/******  Setting for IPCs    ******/
		Cy_Srom_SetResponseHandler(Cy_FlashHandler, CPUIntIdx3_IRQn);
		NVIC_SetPriority(CPUIntIdx3_IRQn, 3ul);
		NVIC_EnableIRQ(CPUIntIdx3_IRQn);
		_g_NB_ModeEnabled = true;
	}
	else
	{
		_g_NB_ModeEnabled = false;
	}
	(void)_g_NB_ModeEnabled; // avoid "unused" compiler warning if NDEBUG is set

	/*  Flash Write Enable   */
	Cy_Flashc_MainWriteEnable();
	Cy_Flashc_WorkWriteEnable();

	_g_completeFlag = true;
	error_code = ASDK_FLASH_STATUS_SUCCESS; // No return is there in the init of Flash so returning SUCCESS from here itself has to check

	if (error_code)
		error_code = ASDK_FLASH_INIT_FAIL;

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_init */

/*----------------------------------------------------------------------------*/
/* Function : flash_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-initialize code flash of the cyt2b7

  @param void

  @return asdk_status_t ASDK_FLASH_STATUS_SUCCESS - on successful de-init.

*/
asdk_status_t flash_deinit(void)
{

	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;

	// memset(&flash_ssd_config, ASDK_NULL, sizeof (flash_ssd_config_t));
	Cy_Flashc_MainWriteDisable();
	Cy_Flashc_WorkWriteDisable();
	// FLASH_DRV_DisableCmdCompleteInterupt();

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_deinit */

/*----------------------------------------------------------------------------*/
/* Function : flash_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback for flash.

  @param asdk_flash_callback_fun_t callback_fun - callback function

  @return asdk_status_t ASDK_FLASH_STATUS_SUCCESS - on successful callback installation.

  @note! Call back function to service the time critical events. Any code reachable from this function
		must not be placed in a Flash block targeted for a program/erase operation.

*/
asdk_status_t flash_install_callback(asdk_flash_callback_fun_t callback_fun)
{

	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;

	/* set callback */
	// To do for the callback function if implemented in the non blocking mode
	// flash_ssd_config.CallBack = callback_fun;
	// The interrupt handler for the callback is being configured in the Flash init function if it is for non blocking mode.
	// If the interrupt occurs Cy_FlashHandler will be invoked

	user_flash_callback_function = callback_fun;

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_install_callback */

/*----------------------------------------------------------------------------*/
/* Function : flash_read */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function reads data into p-flash area.

  @param uint32_t dest -destination address ( p-flash address).

  @param uint32_t size - data size.

  @param uint8_t *data - data buffer.

  @return asdk_status_t - ASDK_FLASH_STATUS_SUCCESS - on successful data read
						  ASDK_FLASH_INVALID_FLASH_ADDRESS - if p-flash  address is invalid.
						  ASDK_FLASH_INVALID_DATA_ALIGNMENT - if data alignment not of 8byte.

*/
asdk_status_t flash_read(uint32_t dest, uint32_t size, uint8_t *data)
{

	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;

	/* Check the pflash memory region and dflash region*/
	if (!((CY_FLASH_LG_SBM_TOP <= dest) && ((CY_FLASH_SM_SBM_END) >= (dest + size)))) // && ( ( CY_WFLASH_SM_SBM_TOP <= dest ) &&( ( CY_WFLASH_SM_SBM_END ) >= ( dest + size ) ) ) ) )
	{

		if (!((CY_WFLASH_LG_SBM_TOP <= dest) && ((CY_WFLASH_SM_SBM_END) >= (dest + size))))
		{
			error_code = ASDK_FLASH_INVALID_FLASH_ADDRESS;
			return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
		}
	}

	/* check for data alignment */
	// Not necessary to be checked later
	if (size % DATA_WRITE_SIZE)
	{
		error_code = ASDK_FLASH_INVALID_DATA_ALIGNMENT; /* DATA size not multiple of 8 */
		return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
	}

	/* disable interrupt  */
	// __disable_irq();

	memcpy((void *)data, (void *)dest, size);

	/* enable interrupt  */
	//__enable_irq();

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_read */

/*----------------------------------------------------------------------------*/
/* Function : flash_get_sector_size */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets sector size of p-flash.

  @param uint32_t* size - flash size.

  @return asdk_status_t - ASDK_FLASH_STATUS_SUCCESS - on successful flash sector size

*/
asdk_status_t flash_get_sector_size(uint32_t *size)
{
	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;

	*size = CODE_LARGE_SECTOR_SIZE_CYT2B7;

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_get_sector_size */

/*----------------------------------------------------------------------------*/
/* Function : flash_write */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function writes data into p-flash area.

  @param uint32_t dest - destination address ( p-flash address).

  @param uint32_t size - data size.

  @param uint8_t *data - source data address.

  @return asdk_status_t - ASDK_FLASH_STATUS_SUCCESS - on successful data write
						  ASDK_FLASH_INVALID_FLASH_ADDRESS - if p-flash  address is invalid.
						  ASDK_FLASH_INVALID_DATA_ALIGNMENT - if data alignment not of 8byte.
						  ASDK_FLASH_STATUS_ERROR - in case of unsuccessful write

*/
asdk_status_t flash_write(uint32_t dest, uint32_t size, uint8_t *data)
{

	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;

	// This needs to be passed as parameter
	bool blocking = CY_FLASH_DRIVER_BLOCKING;
	// uint32_t fail_dddr;
	if (blocking == CY_FLASH_DRIVER_NON_BLOCKING)
	{
		CY_ASSERT(_g_NB_ModeEnabled == true);

		/* Only for non-blocking operation */
		_g_completeFlag = false;
	}


	/* Check the pflash memory region and dflash region*/
	if (!((CY_FLASH_LG_SBM_TOP <= dest) && ((CY_FLASH_SM_SBM_END) >= (dest + size)))) // && ( ( CY_WFLASH_SM_SBM_TOP <= dest ) &&( ( CY_WFLASH_SM_SBM_END ) >= ( dest + size ) ) ) ) )
	{

		if (!((CY_WFLASH_LG_SBM_TOP <= dest) && ((CY_WFLASH_SM_SBM_END) >= (dest + size))))
		{
			error_code = ASDK_FLASH_INVALID_FLASH_ADDRESS;
			return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
		}
	}
        
        
        cy_stc_flash_programrow_config_t programRowConfig = {0};
        programRowConfig.blocking = CY_FLASH_PROGRAMROW_BLOCKING;
        programRowConfig.skipBC   = CY_FLASH_PROGRAMROW_SKIP_BLANK_CHECK;
        programRowConfig.dataSize = CY_FLASH_PROGRAMROW_DATA_SIZE_32BIT;
        programRowConfig.dataLoc  = CY_FLASH_PROGRAMROW_DATA_LOCATION_SRAM;
        programRowConfig.intrMask = CY_FLASH_PROGRAMROW_NOT_SET_INTR_MASK;
        programRowConfig.destAddr = (uint32_t*)dest;
        programRowConfig.dataAddr = (uint32_t*)data;

	/* check for data alignment */
	/*Put condition for size <8 and size > 8*/
	if (size % DATA_WRITE_SIZE)
	{
		error_code = ASDK_FLASH_INVALID_DATA_ALIGNMENT; /* DATA size not multiple of 8 */
		return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
	}

        if(((WORKFLASH_START_ADDRESS) <= (dest))  && ((WORKFLASH_END_ADDRESS) >= (dest)))
        {
          uint16_t size_of_32bits_to_write = size/4;
          programRowConfig.dataSize = CY_FLASH_PROGRAMROW_DATA_SIZE_32BIT;
          for (int i = 0; i < size_of_32bits_to_write; i++)
          {
                   programRowConfig.destAddr = ((uint32_t *)(dest + i * 4));// ((uint32_t *)(dest + i * 8));
                   programRowConfig.dataAddr = ((uint32_t *)(data + i * 4));// ((uint32_t *)(data + i * 8));
                  /* write data */
                   error_code = Cy_Flash_ProgramRow(NULL, &programRowConfig, programRowConfig.blocking);
          }
        }
        else if (((CODEFLASH_START_ADDRESS) <= (dest))  && ((CODEFLASH_END_ADDRESS) >= (dest)))
        {
          uint16_t size_of_64bits_to_write = size/8;
          programRowConfig.dataSize = CY_FLASH_PROGRAMROW_DATA_SIZE_64BIT;
          for (int i = 0; i < size_of_64bits_to_write; i++)
          {
                   programRowConfig.destAddr = ((uint32_t *)(dest + i * 8));
                   programRowConfig.dataAddr = ((uint32_t *)(data + i * 8));
                  /* write data */
                   error_code = Cy_Flash_ProgramRow(NULL, &programRowConfig, programRowConfig.blocking);
          }
          
        }
	/* Verify programming by Program Check command with user margin levels */
	if (!error_code)
	{
        //   uint32_t* pProgramData = (uint32_t*)dest;
        //   for(int i= 0; i< (size/4); i++)
        //   {
        //     CY_ASSERT(pProgramData[i] == data[i]);
        //   }
	}

	/* enable interrupt  */
	//__enable_irq();

	if (error_code)
		error_code = ASDK_FLASH_STATUS_ERROR;

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_write */

/*----------------------------------------------------------------------------*/
/* Function : flash_erase_all_block */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function erase entire s32k144 p-flash area.

  @param void

  @return asdk_status_t ASDK_FLASH_STATUS_SUCCESS - on successful p-flash area erase
						ASDK_FLASH_STATUS_ERROR - in case of unsuccessful erase

*/
asdk_status_t flash_erase_all_block(void)
{

	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;
	uint8_t security_status;

	/* disable interrupt  */
	//__disable_irq();

	/* get security state */
	// FLASH_DRV_GetSecurityState(&security_status);
	cy_un_flash_context_t flashContext = {0ul};
	// if ( /*security_status == FLASH_NOT_SECURE*/)
	{
		/* Algorithm */
		error_code = Cy_Flash_EraseAll(&flashContext, true);
	}

	/* enable interrupt  */
	//__enable_irq();

	if (error_code)
		error_code = ASDK_FLASH_STATUS_ERROR;

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_erase_all_block */

/*----------------------------------------------------------------------------*/
/* Function : flash_erase_sector */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function erases s32k144 flash sector wise.

  @param uint32_t dest - p-flash sector start address

  @param uint32_t size - size

   @return asdk_status_t ASDK_FLASH_STATUS_SUCCESS - on successful p-flash sector erase
						 ASDK_FLASH_STATUS_ERROR - in case of unsuccessful erase
						 ASDK_FLASH_INVALID_SECTOR_SIZE - in case of invalid sector size
						 ASDK_FLASH_INVALID_FLASH_ADDRESS - in case of invalid address

*/
asdk_status_t flash_erase_sector(uint32_t dest, uint32_t size)
{

	/* Local Variables to store FLASH status */
	asdk_flash_ec_t error_code = ASDK_FLASH_STATUS_SUCCESS;
	uint32_t sector_cnt;
	uint32_t sector_size;
	uint32_t codeflash_large_sector_count = (size / CODE_LARGE_SECTOR_SIZE_CYT2B7);
	uint32_t workflash_large_sector_count_d = (size / WORK_LARGE_SECTOR_SIZE_CYT2B7);
	uint32_t codeflash_small_sector_count = (size / CODE_SMALL_SECTOR_SIZE_CYT2B7);
	uint32_t workflash_small_sector_count_d = (size / WORK_SMALL_SECTOR_SIZE_CYT2B7);
	uint8_t index;
	uint32_t base_start = dest;
	// This needs to be passed as parameter
	bool blocking = CY_FLASH_DRIVER_BLOCKING;

	if (blocking == CY_FLASH_DRIVER_NON_BLOCKING)
	{
		CY_ASSERT(_g_NB_ModeEnabled == true);

		_g_completeFlag = false;
	}

	cy_stc_flash_erasesector_config_t eraseSectorConfig = {0};
	// Erase work flash and verify
	eraseSectorConfig.blocking = CY_FLASH_ERASESECTOR_BLOCKING;
	eraseSectorConfig.intrMask = CY_FLASH_ERASESECTOR_NOT_SET_INTR_MASK;
	eraseSectorConfig.Addr = (uint32_t *)dest;
	/* Return protection status */
	// uint8_t security_status;

	/* Check for valid sector size */
	if (size % FLASH_SECTOR_SIZE && size % FLASH_SECTOR_SIZE_D)
	{
		error_code = ASDK_FLASH_INVALID_SECTOR_SIZE;
		return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
	}

	/* Check the pflash memory region and dflash region*/
	/*     if ( !( ( CY_FLASH_LG_SBM_TOP <= dest ) && (( CY_FLASH_LG_SBM_END ) >= ( dest + size ))) //&& ( ( CY_FLASH_SM_SBM_TOP <= dest ) &&( CY_FLASH_SM_SBM_END ) >= ( dest + size ) ) )
		&& !( ( CY_WFLASH_LG_SBM_TOP <= dest ) && ( ( CY_WFLASH_LG_SBM_END ) >= ( dest + size ) )))// && ( ( CY_WFLASH_SM_SBM_TOP <= dest ) &&( ( CY_WFLASH_SM_SBM_END ) >= ( dest + size ) ) ) ) )
	  {
		  error_code = ASDK_FLASH_INVALID_FLASH_ADDRESS;
		  return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
	  }*/
	/* Check the pflash memory region and dflash region*/
	if (!((CY_FLASH_LG_SBM_TOP <= dest) && ((CY_FLASH_SM_SBM_END) >= (dest + size)))) // && ( ( CY_WFLASH_SM_SBM_TOP <= dest ) &&( ( CY_WFLASH_SM_SBM_END ) >= ( dest + size ) ) ) ) )
	{

		if (!((CY_WFLASH_LG_SBM_TOP <= dest) && ((CY_WFLASH_SM_SBM_END) >= (dest + size))))
		{
			error_code = ASDK_FLASH_INVALID_FLASH_ADDRESS;
			return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
		}
	}
	/* disable global interrupt  */
	//__disable_irq();

	/* get security state */
	// FLASH_DRV_GetSecurityState(&security_status);

	/*if ( security_status != FLASH_NOT_SECURE)
	{
		error_code = ASDK_FLASH_STATUS_ERROR;
		return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);
	}*/
	// Need to check if the Small Sectors will also be used for the flash programming
	if ((CY_FLASH_LG_SBM_TOP <= dest) && ((CY_FLASH_LG_SBM_END) >= (dest + size)))
	{
		sector_cnt = codeflash_large_sector_count;
		sector_size = CODE_LARGE_SECTOR_SIZE_CYT2B7;
	}
	else if ((CY_FLASH_SM_SBM_TOP <= dest) && ((CY_FLASH_SM_SBM_END) >= (dest + size)))
	{
		sector_cnt = codeflash_small_sector_count;
		sector_size = CODE_SMALL_SECTOR_SIZE_CYT2B7;
	}
	// Need to check if the Small Sectors will also be used for the wflash programming
	else if ((CY_WFLASH_LG_SBM_TOP <= dest) && ((CY_WFLASH_LG_SBM_END) >= (dest + size)))
	{
		sector_cnt = workflash_large_sector_count_d;
		sector_size = WORK_LARGE_SECTOR_SIZE_CYT2B7;
	}
	else if ((CY_WFLASH_SM_SBM_TOP <= dest) && ((CY_WFLASH_SM_SBM_END) >= (dest + size)))
	{
		sector_cnt = workflash_small_sector_count_d;
		sector_size = WORK_SMALL_SECTOR_SIZE_CYT2B7;
	}

	/* Erase sector by sector pflash */
	for (index = 0; index < sector_cnt; index++)
	{
		error_code = Cy_Flash_EraseSector(NULL, &eraseSectorConfig, true);
		base_start += sector_size;

		if (error_code != ASDK_FLASH_STATUS_SUCCESS)
			break;
	}

	/* enable global interrupt  */
	//__enable_irq();

	if (error_code)
		error_code = ASDK_FLASH_STATUS_ERROR;

	return ASDK_FLASH_RETURN(ASDK_LC_HARDWARE, error_code);

} /* flash_erase_sector */
