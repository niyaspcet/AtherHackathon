/*
  @file
  hw_adc.c

  @path
  hw_adc.c

  @Created on
  Feb 15, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
  This file implements the adc for cyt2b7 micro-controller.


*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "hw_adc.h"
#include "adc.h"
#include "adc/cy_adc.h"
#include "cy_device_headers.h"
#include "cy_project.h"

/*==============================================================================

                        LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/
/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
// static const char filename[] = "hw_adc.c";

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define ADC_MAX_CH_NO           32u
#define MAX_ADC_MOD              3u
#define ADC_0                    0
#define ADC_1                    1
#define ADC_2                    2
#define TEMP_DELAY              1000
#define ADC_CHN_INDEX           0u
#define MAX_BATCH_SIZE          20u

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/
static asdk_adc_callback_fun_t user_adc_callback_fun_list[MAX_ADC_MOD][ADC_MAX_CH_NO];

// Base pointer for the SAR0 ADC Module
// Can be extended to other Module like SAR1 ADC by adding the base pointer in ADC_BASE_PTRS array
volatile stc_PASS_SAR_t *const adc_module[] = {PASS0_SAR0, PASS0_SAR1, PASS0_SAR2};

/**
 * \var static cy_stc_adc_ch_status_t statusBuff
 * \brief ADC conversion status buffer place holder
 */
static cy_stc_adc_ch_status_t statusBuff;
static cy_stc_adc_group_status_t grpstatus;

/*Initilization of the config structure of an ADC like SAR0*/
/* Configuration structure of a ADC */
cy_stc_adc_config_t adcConfig = {
    .preconditionTime = 0u,
    .powerupTime = 0u,
    .enableIdlePowerDown = false,
    .msbStretchMode = CY_ADC_MSB_STRETCH_MODE_1CYCLE,
    .enableHalfLsbConv = 0u,
    .sarMuxEnable = true,
    .adcEnable = true,
    .sarIpEnable = true,
};

// cy_stc_adc_channel_config_t adcChannelConfig;

/* Configuration of ADC channel */
cy_stc_adc_channel_config_t adcChannelConfig =
    {
        .triggerSelection = CY_ADC_TRIGGER_OFF,
        .channelPriority = 0u,
        .preenptionType = CY_ADC_PREEMPTION_FINISH_RESUME,
        .isGroupEnd = true,
        .doneLevel = CY_ADC_DONE_LEVEL_PULSE,
        .pinAddress = ((cy_en_adc_pin_address_t)13), // BB_POTI_ANALOG_INPUT_NO,
        .portAddress = CY_ADC_PORT_ADDRESS_SARMUX0,
        .extMuxSelect = 0u,
        .extMuxEnable = true,
        .preconditionMode = CY_ADC_PRECONDITION_MODE_OFF,
        .overlapDiagMode = CY_ADC_OVERLAP_DIAG_MODE_OFF,
        .sampleTime = 120,//13, // ADC_CH_SAMPLE_TIME,//11,//112,//12,//8,//ADC_CH_SAMPLE_TIME,
        .calibrationValueSelect = CY_ADC_CALIBRATION_VALUE_REGULAR,
        .postProcessingMode = CY_ADC_POST_PROCESSING_MODE_NONE,
        .resultAlignment = CY_ADC_RESULT_ALIGNMENT_RIGHT,
        .signExtention = CY_ADC_SIGN_EXTENTION_UNSIGNED,
        .averageCount = 0u,
        .rightShift = 0u,
        .rangeDetectionMode = CY_ADC_RANGE_DETECTION_MODE_INSIDE_RANGE,
        .rangeDetectionLoThreshold = 0x0000u,
        .rangeDetectionHiThreshold = 0x0FFFu,
        .mask.grpDone = true,
        .mask.grpCancelled = false,
        .mask.grpOverflow = false,
        .mask.chRange = false,
        .mask.chPulse = false,
        .mask.chOverflow = false,
};

//
/*cy_stc_sysint_irq_t irq_cfg ={
      .sysIntSrc  = (cy_en_intr_t)((uint32_t)CY_ADC_POT_IRQN),
      .intIdx     = CPUIntIdx3_IRQn,
      .isEnabled  = true,
};*/

//@ref config structure being passed from the application layer as pointer.
/*static asdk_adc_config_t adc_read_config_ADC0_SE10 = {
     .adc_no = ADC_MODULE0,
     .adc_ch_no = 10u,
     .adc_clock_divide = ASDK_ADC_CLK_DIVIDE_8,
     .adc_resolution = ASDK_ADC_RESOLUTION_12BIT,
     .adc_trigger = ASDK_ADC_TRIGGER_SOFTWARE,
     .transfer = ASDK_ADC_USING_INTERRUPTS,
     .adc_reference_voltage = ASDK_ADC_VOLTAGEREF_VREF,
     .adc_continuous_conv_enable = false,
     .group_flag = false
};*/

static asdk_adc_batch_data_t batch[MAX_BATCH_SIZE] = {{0}, {0}};
static uint8_t group_flag = 0;
static uint8_t max_instance = 0;
static uint8_t instance_no = 0; // ranges from 0 to max_instance-1
/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/
void ADC0_ISR(void);
void ADC1_ISR(void);
void ADC2_ISR(void);

/*==============================================================================

                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/* Function : adc_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initialize ADC instance

  @param asdk_adc_config_t* adc_config - adc module config

  @return asdk_status_t ASDK_ADC_MOD_RANGE_EXCEEDED - in case of adc module range exceeds
                        ASDK_ADC_CH_RANGE_EXCEEDED  - in case of adc channel range exceeds
                        ASDK_ADC_INIT_FAILED - in case adc initialization fail

*/
asdk_status_t adc_init(asdk_adc_config_t *adc_config)
{

  /* Local Variables to store ADC status */
  asdk_adc_ec_t error_code = ASDK_ADC_STATUS_SUCCESS;

  /* check for maximum adc no */
  if (adc_config->adc_no >= MAX_ADC_MOD)
  {
    error_code = ASDK_ADC_MOD_RANGE_EXCEEDED;
    return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
  } /* if(adc_no > MAX_ADC_MOD) */

  /* check for valid adc channel number */
  if (adc_config->adc_ch_no >= ADC_MAX_CH_NO)
  {
    error_code = ASDK_ADC_CH_RANGE_EXCEEDED;
    return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
  } /* if(adc_ch_no >= ADC_MAX_CH_NO) */

  // Initialize the ADC channel
  adcChannelConfig.pinAddress = ((cy_en_adc_pin_address_t)adc_config->adc_ch_no);

  /*Initialize the ADC Module */
  Cy_Adc_Init(adc_module[adc_config->adc_no], &adcConfig);
  /*Initializ the respective channel of the particular ADC Module*/
  error_code = Cy_Adc_Channel_Init(&adc_module[adc_config->adc_no]->CH[adc_config->adc_ch_no], &adcChannelConfig);

  /* Register ADC interrupt handler and enable interrupt */
  cy_stc_sysint_irq_t irq_cfg;
  irq_cfg = (cy_stc_sysint_irq_t){
      .sysIntSrc = (cy_en_intr_t)((uint32_t)pass_0_interrupts_sar_0_IRQn + adc_config->adc_ch_no), // adc_config->adc_ch_no + 25),
      .intIdx = CPUIntIdx4_IRQn,
      .isEnabled = true,
  };

  if (adc_config->adc_no == ADC_0)
  {
    irq_cfg.sysIntSrc = (cy_en_intr_t)((uint32_t)pass_0_interrupts_sar_0_IRQn + adc_config->adc_ch_no);
  }
  else if (adc_config->adc_no == ADC_1)
  {
    irq_cfg.sysIntSrc = (cy_en_intr_t)((uint32_t)pass_0_interrupts_sar_32_IRQn + adc_config->adc_ch_no);
  }
  else if (adc_config->adc_no == ADC_2)
  {
    irq_cfg.sysIntSrc = (cy_en_intr_t)((uint32_t)pass_0_interrupts_sar_64_IRQn + adc_config->adc_ch_no);
  }

  if (adc_config->adc_no == ADC_0)
  {
    Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, ADC0_ISR);
  }
  else if (adc_config->adc_no == ADC_1)
  {
    Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, ADC1_ISR);
  }
  else if (adc_config->adc_no == ADC_2)
  {
    Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, ADC2_ISR);
  }

  Cy_SysInt_InitIRQ(&irq_cfg);
  NVIC_SetPriority(irq_cfg.intIdx, 3ul);
  NVIC_EnableIRQ(irq_cfg.intIdx);

  /* Enable ADC ch. */
  Cy_Adc_Channel_Enable(&adc_module[adc_config->adc_no]->CH[adc_config->adc_ch_no]);

  return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);

} /* adc_init */

/*----------------------------------------------------------------------------*/
/* Function : adc_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-initialize adc module

  @param uint8_t adc_no - adc module no

  @return asdk_status_t ASDK_ADC_MOD_RANGE_EXCEEDED - in case of adc module range exceeds
                        ASDK_ADC_CH_RANGE_EXCEEDED  - in case of adc channel range exceeds

*/
asdk_status_t adc_deinit(uint8_t adc_no)
{

  /* Local Variables to store ADC status */
  asdk_adc_ec_t error_code = ASDK_ADC_STATUS_SUCCESS;

  /* check for maximum adc no */
  if (adc_no >= MAX_ADC_MOD)
  {
    error_code = ASDK_ADC_MOD_RANGE_EXCEEDED;
    return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
  } /* if(adc_no > MAX_ADC_MOD) */

  /* Algorithm */
  Cy_Adc_DeInit(adc_module[adc_no]);

  return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);

} /* adc_deinit */

/*----------------------------------------------------------------------------*/
/* Function : adc_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback_for ADC module instance

  @param uint8_t adc_no - adc module no

  @param  uint8_t adc_ch_no - adc channel no

  @param asdk_adc_callback_fun_t  callback_fun - adc callback function

  @return asdk_status_t ASDK_ADC_MOD_RANGE_EXCEEDED - in case of adc module range exceeds
                        ASDK_ADC_STATUS_SUCCESS  - in case of successful callback installation

*/

asdk_status_t adc_install_callback(uint8_t adc_no, uint8_t adc_channel_no, asdk_adc_callback_fun_t callback_fun)
{

  /* Local Variables to store ADC status */
  asdk_adc_ec_t error_code = ASDK_ADC_STATUS_SUCCESS;

  /* check for maximum adc no */
  if (adc_channel_no >= ADC_MAX_CH_NO)
  {
    error_code = ASDK_ADC_MOD_RANGE_EXCEEDED;
    return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
  } /* if(adc_no > MAX_ADC_MOD) */

  user_adc_callback_fun_list[adc_no][adc_channel_no] = callback_fun;

  return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);

} /* adc_install_callback */

/*----------------------------------------------------------------------------*/
/* Function : ADC_ISR */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets ADC channel conversion value using non-blocking.

  @param void

  @return void

*/
void ADC0_ISR(void)
{
  uint32_t result = 0;
  uint32_t channel_no;

  channel_no = adc_module[ADC_0]->unSTATUS.stcField.u5CUR_CHAN;
  cy_stc_adc_interrupt_source_t intrSource = {false};
  /* Get interrupt source */
  Cy_Adc_Channel_GetInterruptMaskedStatus(&adc_module[ADC_0]->CH[channel_no], &intrSource);

  if (intrSource.grpDone)
  {

    if (user_adc_callback_fun_list[ADC_0][channel_no] != NULL)
    {
      // Cy_GPIO_Inv(GPIO_PRT19, 0);
      Cy_Adc_Channel_GetResult(&adc_module[ADC_0]->CH[channel_no], (uint16_t *)&result, &statusBuff);
      user_adc_callback_fun_list[ADC_0][channel_no](ADC_0, channel_no, &result);
    }

    /* Clear interrupt source */
    Cy_Adc_Channel_ClearInterruptStatus(&adc_module[ADC_0]->CH[channel_no], &intrSource);

  }

  if (group_flag == 1)
  {
    instance_no += 1;
    if (instance_no < max_instance)
    {
      adc_get_non_blocking_conv_value(batch[instance_no].adc_no, batch[instance_no].adc_ch_no);
    }

    else
    {
      group_flag = 0;
    }
  }
}

void ADC1_ISR(void)
{
  uint32_t result = 0;
  uint32_t channel_no;

  channel_no = adc_module[ADC_1]->unSTATUS.stcField.u5CUR_CHAN;

  cy_stc_adc_interrupt_source_t intrSource = {false};
  /* Get interrupt source */
  Cy_Adc_Channel_GetInterruptMaskedStatus(&adc_module[ADC_1]->CH[channel_no], &intrSource);

  if (intrSource.grpDone)
  {
    if (user_adc_callback_fun_list[ADC_1][channel_no] != NULL)
    {
      Cy_Adc_Channel_GetResult(&adc_module[ADC_1]->CH[channel_no], (uint16_t *)&result, &statusBuff);
      user_adc_callback_fun_list[ADC_1][channel_no](ADC_1, channel_no, &result);
    }

    /* Clear interrupt source */
    Cy_Adc_Channel_ClearInterruptStatus(&adc_module[ADC_1]->CH[channel_no], &intrSource);
  }
  if (group_flag == 1)
  {
    instance_no += 1;
    if (instance_no < max_instance)
    {
      adc_get_non_blocking_conv_value(batch[instance_no].adc_no, batch[instance_no].adc_ch_no);
    }

    else
    {
      group_flag = 0;
    }
  }
}

void ADC2_ISR(void)
{
  uint32_t result = 0;
  uint32_t channel_no;

  channel_no = adc_module[ADC_2]->unSTATUS.stcField.u5CUR_CHAN;
  cy_stc_adc_interrupt_source_t intrSource = {false};
  /* Get interrupt source */
  Cy_Adc_Channel_GetInterruptMaskedStatus(&adc_module[ADC_2]->CH[channel_no], &intrSource);

  if (intrSource.grpDone)
  {
    if (user_adc_callback_fun_list[ADC_2][channel_no] != NULL)
    {
      Cy_Adc_Channel_GetResult(&adc_module[ADC_2]->CH[channel_no], (uint16_t *)&result, &statusBuff);
      user_adc_callback_fun_list[ADC_2][channel_no](ADC_2, channel_no, &result);
    }

    /* Clear interrupt source */
    Cy_Adc_Channel_ClearInterruptStatus(&adc_module[ADC_2]->CH[channel_no], &intrSource);
  }
  if (group_flag == 1)
  {
    instance_no += 1;
    if (instance_no < max_instance)
    {
      adc_get_non_blocking_conv_value(batch[instance_no].adc_no, batch[instance_no].adc_ch_no);
    }

    else
    {
      group_flag = 0;
    }
  }
}

/*----------------------------------------------------------------------------*/
/* Function : adc_get_blocking_conv_value */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function return ADC channel conversion value using blocking.

  @param uint8_t adc_no - adc module no

  @param uint8_t adc_channel_no

  @param uint32_t* adc_channel_value

  @return asdk_status_t ASDK_ADC_MOD_RANGE_EXCEEDED - in case of adc module range exceeds
                        ASDK_ADC_CONVR_SUCCESS  - in case of successful adc conversion
                        ASDK_ADC_CONVR_FAILED - in case of unsuccessful adc conversion

*/

/*Blocking API has not been implemented since there's no blocking driver layer code for the implementation*/
asdk_status_t adc_get_blocking_conv_value(uint8_t adc_no, uint8_t adc_channel_no, uint32_t *adc_channel_value)
{

  /* Local Variables to store ADC status */
  asdk_adc_ec_t error_code = ASDK_ADC_CONVR_FAILED;

  /*initialize the control channel configuration to default values*/
  /* check for valid adc channel number */
  if (adc_channel_no >= ADC_MAX_CH_NO)
  {
    error_code = ASDK_ADC_CH_RANGE_EXCEEDED;
    return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
  } /* if(adc_channel_no >= ADC_MAX_CH_NO) */

  error_code = ASDK_ADC_FEATURE_NOT_IMPLEMENTED;

  return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);

} /* adc_get blocking_conv_value */

/*----------------------------------------------------------------------------*/
/* Function : adc_get_non_blocking_conv_value */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function return ADC channel conversion value using blocking.

  @param uint8_t adc_channel_no

  @param uint32_t* adc_channel_value

   @param uint8_t adc_no - adc module no

  @return asdk_status_t ASDK_ADC_MOD_RANGE_EXCEEDED - in case of adc module range exceeds
                        ASDK_ADC_CH_RANGE_EXCEEDED  - in case of adc channel range exceeds

*/
asdk_status_t adc_get_non_blocking_conv_value(uint8_t adc_no, uint8_t adc_channel_no)
{

  /* Local Variables to store ADC status */
  asdk_adc_ec_t error_code = ASDK_ADC_STATUS_SUCCESS;

  /* check for valid adc channel number */
  if (adc_channel_no >= ADC_MAX_CH_NO)
  {
    error_code = ASDK_ADC_CH_RANGE_EXCEEDED;
    return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
  } /* if(adc_channel_no >= ADC_MAX_CH_NO) */

  Cy_Adc_Channel_GetGroupStatus(&adc_module[adc_no]->CH[adcChannelConfig.pinAddress], &grpstatus);

  if (grpstatus.grpBusy != 0)
  {
    error_code = ASDK_ADC_CONVR_BUSY;
    return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
  }

  // Initialize the ADC channel
  adcChannelConfig.pinAddress = ((cy_en_adc_pin_address_t)adc_channel_no);

  /*Initializ the respective channel of the particular ADC Module*/
  Cy_Adc_Channel_Init(&adc_module[adc_no]->CH[adc_channel_no], &adcChannelConfig);

  /* Enable ADC ch. */
  Cy_Adc_Channel_Enable(&adc_module[adc_no]->CH[adc_channel_no]);
  
  /* Issue SW trigger */
  Cy_Adc_Channel_SoftwareTrigger(&adc_module[adc_no]->CH[adc_channel_no]);

  return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);

} /* adc_get_non_blocking_conv_value */


asdk_status_t adc_get_batch_non_blocking_conv_value(asdk_adc_batch_data_t *adc_batch_data, uint8_t batch_size)
{
  asdk_adc_ec_t error_code = ASDK_ADC_STATUS_SUCCESS;
  max_instance = batch_size;
  memset(batch, ASDK_NULL, (sizeof(asdk_adc_batch_data_t) * MAX_BATCH_SIZE));
  memcpy(batch, adc_batch_data, (sizeof(asdk_adc_batch_data_t) * batch_size));
  group_flag = 1;
  instance_no = 0;

  /* store channel no for callback */
  uint8_t adc_callback_channel_no = adc_batch_data[0].adc_ch_no;

  uint8_t adc_callback_instance_no = adc_batch_data[0].adc_no;

  adc_get_non_blocking_conv_value(adc_callback_instance_no, adc_callback_channel_no);

  return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, error_code);
}

/*----------------------------------------------------------------------------*/
/* Function : adc_add_sample */
/*----------------------------------------------------------------------------*/
/*!
 *@brief
 *This function initialize ADC instance

 *@param asdk_adc_channel_data_t *adc_channel_data - adc channel data to which another adc sample to be added(input)

 *@param uint8_t sample_no - adc sample number to be added to channel(input)

 *@return asdk_status_t ASDK_ADC_MOD_RANGE_EXCEEDED		- in case of adc module range exceeds
						ASDK_ADC_CH_RANGE_EXCEEDED		- in case of adc channel range exceeds
						ASDK_ADC_INIT_FAILED - in case adc initialization fail
						ASDK_ADC_STATUS_SUCCESS - on successful operation.
 */
asdk_status_t adc_add_sample(asdk_adc_channel_data_t *adc_channel_data, uint8_t sample_no)
{

	/* Not implemented for KW36 */
	return ASDK_ADC_RETURN(ASDK_LC_HARDWARE, ASDK_ADC_STATUS_ERROR);
	
}/* adc_add_sample */