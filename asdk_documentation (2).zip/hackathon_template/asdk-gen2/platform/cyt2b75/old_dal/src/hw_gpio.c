/*
  @file
  hw_gpio.c

  @path
  cyt2b7_gpio.c

  @Created on
  Jan 18, 2022

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include "errordef.h"
#include "system.h"
#include "gpio.h"
#include "hw_gpio.h"
#include "cy_device_headers.h"
#include "cy_project.h"
#include "gpio/cy_gpio.h"
#include "cy_project.h"

/*==============================================================================

                        LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
//static const char filename[] = "s32k144_gpio.c";

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define GPIO_MAX_PORT_PIN          8			// change according to CYT2B7
#define MAX_GPIO_PORT              24
#define CLEAR_PIN                  0			// change according to CYT2B7
#define SET_PIN                    1			// change according to CYT2B7

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

//Enums for the interrupt of GPIO Ports
typedef enum{
  PORT0 = ioss_interrupts_gpio_0_IRQn,
  PORT1 = ioss_interrupts_gpio_1_IRQn,
  PORT2 = ioss_interrupts_gpio_2_IRQn,
  PORT3 = ioss_interrupts_gpio_3_IRQn,
  PORT4 = ioss_interrupts_gpio_4_IRQn,
  PORT5 = ioss_interrupts_gpio_5_IRQn,
  PORT6 = ioss_interrupts_gpio_6_IRQn,
  PORT7 = ioss_interrupts_gpio_7_IRQn,
  PORT8 = ioss_interrupts_gpio_8_IRQn,
  PORT9 = ioss_interrupts_gpio_9_IRQn,
  PORT10 = ioss_interrupts_gpio_10_IRQn,
  PORT11 = ioss_interrupts_gpio_11_IRQn,
  PORT12 = ioss_interrupts_gpio_12_IRQn,
  PORT13= ioss_interrupts_gpio_13_IRQn,
  PORT14= ioss_interrupts_gpio_14_IRQn,
  PORT15 = ioss_interrupts_gpio_15_IRQn,
  PORT16 = ioss_interrupts_gpio_16_IRQn,
  PORT17 = ioss_interrupts_gpio_17_IRQn,
  PORT18 = ioss_interrupts_gpio_18_IRQn,
  PORT19 = ioss_interrupts_gpio_19_IRQn,
  PORT20 = ioss_interrupts_gpio_20_IRQn,
  PORT21 = ioss_interrupts_gpio_21_IRQn,
  PORT22 = ioss_interrupts_gpio_22_IRQn,
  PORT23 = ioss_interrupts_gpio_23_IRQn
}dal_gpio_en_interrupt_t;

/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/
// GPIO Base ptrs
volatile stc_GPIO_PRT_t *const gpio_port[] = {
	GPIO_PRT0, GPIO_PRT1, GPIO_PRT2, GPIO_PRT3,
	GPIO_PRT4, GPIO_PRT5, GPIO_PRT6, GPIO_PRT7,
	GPIO_PRT8, GPIO_PRT9, GPIO_PRT10, GPIO_PRT11,
	GPIO_PRT12, GPIO_PRT13, GPIO_PRT14, GPIO_PRT15,
	GPIO_PRT16, GPIO_PRT17, GPIO_PRT18, GPIO_PRT19,
	GPIO_PRT20, GPIO_PRT21, GPIO_PRT22, GPIO_PRT23
};

//Array of enum PORTs to set the interrupt for each port in the InstallInterrupt Hnadler function
//These are declared here because of the IAR error 
uint8_t port_irqn[24] = {PORT0, PORT1, PORT2, PORT3, PORT4, PORT5, PORT6, PORT7, 
                        PORT8, PORT9, PORT10, PORT11, PORT12, PORT13, PORT14,
                        PORT15, PORT16, PORT17, PORT18, PORT19, PORT20, PORT21,
                        PORT22, PORT23 };

/* static array of function pointer to hold user callback function */
static asdk_gpio_callback_fun_t user_gpio_callback_fun[MAX_GPIO_PORT];

/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/

void gpio0_isr(void) ;
void gpio1_isr(void) ;
void gpio2_isr(void) ;
void gpio3_isr(void) ;
void gpio4_isr(void) ;
void gpio5_isr(void) ;
void gpio6_isr(void) ;
void gpio7_isr(void) ;
void gpio8_isr(void) ;
void gpio9_isr(void) ;
void gpio10_isr(void) ;
void gpio11_isr(void) ;
void gpio12_isr(void) ;
void gpio13_isr(void) ;
void gpio14_isr(void) ;
void gpio15_isr(void) ;
void gpio16_isr(void) ;
void gpio17_isr(void) ;
void gpio18_isr(void) ;
void gpio19_isr(void) ;
void gpio20_isr(void) ;
void gpio21_isr(void) ;
void gpio22_isr(void) ;
void gpio23_isr(void) ;


/*==============================================================================

                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/
/*!
  @brief
  Initializes the GPIO module.

  @param int number_of_pins
  This parameter mentions the number of gpio pins that
  need to be configured.

  @param asdk_gpio_config_t config_array

  @return int

*/
asdk_status_t gpio_init ( asdk_gpio_config_t *gpio_config )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code;

    /*Local variable of type asdk_gpio_config_t*/
    

    /* check for maximum gpio port no */
	if(gpio_config->port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* check for maximum gpio pin no */
	if(gpio_config->pin_number >= GPIO_MAX_PORT_PIN)
	{
		error_code  = ASDK_GPIO_INVALID_PIN;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(pin > GPIO_MAX_PORT_PIN) */

	// PINS_DRV_SetPinDirection ( gpio_port[gpio_config->port], gpio_config->pin_number, gpio_config->direction );

	// note: Above API is not available in CYT2B75 SDL v7.8.0
	// also, all pins are getting initalized via hw_system.c during system_init
	// by using pin_mux configuration from generated_code

	if ( gpio_config->direction  == ASDK_GPIO_OUTPUT_DIRECTION )
	{
		Cy_GPIO_Write(gpio_port[gpio_config->port], gpio_config->pin_number, gpio_config->output_logic);
	}

	error_code = ASDK_GPIO_SUCCESS;
	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}/*gpio_init*/

/*----------------------------------------------------------------------------*/
/* Function : gpio_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-initialize gpio pin number.

  @param asdk_gpio_port_t port - gpio port number

  @param uint8_t pin - gpio pin number

  @param bool interrupt_status - gpio interrupt status

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS in case of successful gpio deinit

*/
asdk_status_t gpio_deinit ( asdk_gpio_port_t port, uint8_t pin, bool interrupt_status )
{

	/* Local Variables to store ADC status */
	asdk_gpio_ec_t error_code = ASDK_GPIO_SUCCESS;

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* check for maximum gpio pin no */
	if(pin >= GPIO_MAX_PORT_PIN)
	{
		error_code  = ASDK_GPIO_INVALID_PIN;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(pin > GPIO_MAX_PORT_PIN) */

	// note: doesn't deinit at pin level
	Cy_GPIO_Port_Deinit(gpio_port[port]);

	/* clear interrupt */
      if ( interrupt_status )
      {
          user_gpio_callback_fun[port] = NULL;
      }

      return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}/* gpio_deinit */

/*----------------------------------------------------------------------------*/
/* Function : gpio_pin_set */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function sets the GPIO pin specified.

  @param asdk_gpio_port_t port - gpio port number

  @param uint8_t pin - gpio pin number

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS success

*/
asdk_status_t gpio_pin_set ( asdk_gpio_port_t port, uint8_t pin )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code;

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* check for maximum gpio pin no */
	if(pin >= GPIO_MAX_PORT_PIN)
	{
		error_code  = ASDK_GPIO_INVALID_PIN;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(pin > GPIO_MAX_PORT_PIN) */
    //Calling the GPIO_Set function to set the particular pin of the Port
	Cy_GPIO_Set(gpio_port[port], pin);

	error_code  = ASDK_GPIO_SUCCESS;
	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}/* gpio_pin_set */

/*----------------------------------------------------------------------------*/
/* Function : gpio_pin_clear */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function clears the specified GPIO pin

  @param asdk_gpio_port_t port - gpio port number

  @param uint8_t pin - gpio pin number

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS success

*/
asdk_status_t gpio_pin_clear ( asdk_gpio_port_t port, uint8_t pin )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code;

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* check for maximum gpio pin no */
	if(pin >= GPIO_MAX_PORT_PIN)
	{
		error_code  = ASDK_GPIO_INVALID_PIN;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(pin > GPIO_MAX_PORT_PIN) */

	Cy_GPIO_Clr(gpio_port[port], pin);

	error_code  = ASDK_GPIO_SUCCESS;
	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}/* gpio_pin_clear */

/*----------------------------------------------------------------------------*/
/* Function : gpio_pin_toggle */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function toggles the GPIO pin specified.

  @param asdk_gpio_port_t port - gpio port number

  @param uint8_t pin - gpio pin number

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS success

*/
asdk_status_t gpio_pin_toggle (asdk_gpio_port_t port, uint8_t pin )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code;

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* check for maximum gpio pin no */
	if(pin >= GPIO_MAX_PORT_PIN)
	{
		error_code  = ASDK_GPIO_INVALID_PIN;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(pin > GPIO_MAX_PORT_PIN) */

    /* clear gpio port pin */
	//Cy_GPIO_Inv(gpio_port[port],(uint32_t)PIN_MASK(pin));
        Cy_GPIO_Inv(gpio_port[port], pin);

	error_code  = ASDK_GPIO_SUCCESS;
	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}/* gpio_pin_toggle */

/*----------------------------------------------------------------------------*/
/* Function : gpio_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function installs an IRQ handler mentioned

  @param asdk_gpio_port_t port - gpio port number

  @param uint8_t pin - gpio pin number

  @param asdk_gpio_interrupt_config_t interrupt_config - pin interrupt config

  @param asdk_gpio_callback_fun_t callback_fun - gpio callback fun

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS success

*/


asdk_status_t gpio_install_callback ( asdk_gpio_port_t port, uint8_t pin,
                 asdk_gpio_interrupt_config_t interrupt_config,  asdk_gpio_callback_fun_t callback_fun )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code = ASDK_GPIO_SUCCESS;
        
        /* Setup GPIO for interrupt */
        const cy_stc_sysint_irq_t irq_cfg =
          {
                  .sysIntSrc  = port_irqn[port],
                  .intIdx     = CPUIntIdx3_IRQn,
                  .isEnabled  = true,
          };

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* check for maximum gpio pin no */
	if(pin >= GPIO_MAX_PORT_PIN)
	{
		error_code = ASDK_GPIO_INVALID_PIN;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(pin > GPIO_MAX_PORT_PIN) */
        
         Cy_SysInt_InitIRQ(&irq_cfg);
        //Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, ButtonIntHandler);

       switch(port)
	{
	case 0 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio0_isr);

		break ;

	case 1 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio1_isr);
		break ;

	case 2 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio2_isr);
		break ;

	case 3 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio3_isr);
		break ;

	case 4 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio4_isr);
		break ;
                
        case 5 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio5_isr);

		break ;

	case 6 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio6_isr);
		break ;

	case 7 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio7_isr);
		break ;

	case 8 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio8_isr);
		break ;

	case 9 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio9_isr);
		break ;
        case 10 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio10_isr);

		break ;

	case 11 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio11_isr);
		break ;

	case 12 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio12_isr);
		break ;

	case 13 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio13_isr);
		break ;

	case 14 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio14_isr);
		break ;
         case 15 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio15_isr);

		break ;

	case 16 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio16_isr);
		break ;

	case 17 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio17_isr);
		break ;

	case 18 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio18_isr);
		break ;

	case 19 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio19_isr);
		break ;
        case 20 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio20_isr);

		break ;

	case 21 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio21_isr);
		break ;

	case 22 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio22_isr);
		break ;

	case 23 :
		/* Enable interrupt for the given port */
		Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, gpio23_isr);
		break ;
	
        default :
		break ;		
	}

	//Set the priority of the interrupt and enable the IRQ
	 NVIC_SetPriority(irq_cfg.intIdx, 3ul);
         NVIC_EnableIRQ(irq_cfg.intIdx);
	 error_code = Cy_GPIO_GetInterruptStatusMasked(gpio_port[port], pin);
	 user_gpio_callback_fun[port] = callback_fun;


	/* check error code */
	if( error_code )
	{
		error_code  = ASDK_GPIO_CALLBACK_FAIL;
	}

	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}/* gpio_install_callback */

/*----------------------------------------------------------------------------*/
/* Function : gpio_clear_interrupt */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function clears an interrupt on a GPIO line.

  @param asdk_gpio_port_t port - gpio port number

  @param uint8_t pin - gpio pin number

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS success

*/
asdk_status_t gpio_clear_interrupt ( asdk_gpio_port_t port, uint8_t pin )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code;

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* check for maximum gpio pin no */
	if(pin >= GPIO_MAX_PORT_PIN)
	{
		error_code = ASDK_GPIO_INVALID_PIN;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(pin > GPIO_MAX_PORT_PIN) */

	Cy_GPIO_ClearInterrupt(gpio_port[port], pin);

	//PINS_DRV_SetPinIntSel(gpio_port_base[port], pin, ASDK_GPIO_PORT_DMA_INT_DISABLED);

	error_code  = ASDK_GPIO_SUCCESS;
	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}/* gpio_clear_interrupt */

/*----------------------------------------------------------------------------*/
/* Function : gpio_get_pins_input */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  Returns the GPIO values of pins configured as input.

  @param asdk_gpio_port_t port - gpio port number

  @param bool *data - port pin status

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS success

*/
asdk_status_t gpio_get_pins_input ( asdk_gpio_port_t port, uint8_t pin, bool *data  )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code;

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* read port pins  */
	*data = (Cy_GPIO_Read(gpio_port[port], pin ));

	error_code  = ASDK_GPIO_SUCCESS;
	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}

/*----------------------------------------------------------------------------*/
/* Function : gpio_get_pins_output */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  Returns the GPIO values of pins configured as output.

  @param asdk_gpio_port_t port - gpio port number

  @param bool *data - port pin status

  @return asdk_status_t ASDK_GPIO_INVALID_PORT - if port no is invalid
						ASDK_GPIO_INVALID_PIN if gpio pin range is invalid
						ASDK_GPIO_SUCCESS success

*/
asdk_status_t gpio_get_pins_output ( asdk_gpio_port_t port, uint8_t pin, bool *data  )
{

	/* Local Variables to store gpio status */
	asdk_gpio_ec_t error_code;

    /* check for maximum gpio port no */
	if(port >= MAX_GPIO_PORT)
	{
		error_code  = ASDK_GPIO_INVALID_PORT;
		return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(port > MAX_GPIO_PORT) */

    /* get output pins */
	*data  = Cy_GPIO_ReadOut(gpio_port[port], pin );

	error_code  = ASDK_GPIO_SUCCESS;
	return ASDK_GPIO_RETURN(ASDK_LC_HARDWARE, error_code);

}

/*----------------------------------------------------------------------------*/
/* Function : GPIO_IRQHandler */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  Interrupt service function for given port.

  @param void

  @return void

*/

#if 0
void gpio_isr(void)
{//SEGGER_SYSVIEW_RecordEnterISR();

	uint32_t pin_numbers_mask;
	uint8_t i,j ;

for(i = 0 ; i<MAX_GPIO_PORT ; i++){
	/* Get pin interrupt flag */
	pin_numbers_mask = PINS_DRV_GetPortIntFlag(gpio_port_base[i]);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	if(user_gpio_callback_fun[i] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[i](i, pin_numbers_mask );
	}

	/* Clear external interrupt flag. */
	PINS_DRV_ClearPinIntFlagCmd(gpio_port_base[i],j);
	}
}
//SEGGER_SYSVIEW_RecordExitISR();
}
#endif

void gpio0_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask = (gpio_port[0]-> unINTR_MASKED.u32Register);//PINS_DRV_GetPortIntFlag(gpio_port_base[0]);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[0],j);

	if(user_gpio_callback_fun[0] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[0](0, pin_numbers_mask );
	}
	}
}

void gpio1_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[1]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[0],j);

	if(user_gpio_callback_fun[1] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[1](1, pin_numbers_mask );
	}
	}
}

void gpio2_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[2]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[2],j);

	if(user_gpio_callback_fun[2] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[2](2, pin_numbers_mask );
	}
	}
}

void gpio3_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[3]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[2],j);

	if(user_gpio_callback_fun[3] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[3](3, pin_numbers_mask );
	}
	}
}


void gpio4_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[4]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[4],j);

	if(user_gpio_callback_fun[4] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[4](4, pin_numbers_mask );
	}
	}

}/* PORT4_IRQHandler */

void gpio5_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[5]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[5],j);

	if(user_gpio_callback_fun[5] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[5](5, pin_numbers_mask);
	}
	}

}/* PORT5_IRQHandler */

void gpio6_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[6]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[6],j);

	if(user_gpio_callback_fun[6] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[6](6, pin_numbers_mask );
	}
	}

}/* PORT6_IRQHandler */

void gpio7_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[7]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[7],j);

	if(user_gpio_callback_fun[7] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[7](7, pin_numbers_mask );
	}
	}

}/* PORT7_IRQHandler */

void gpio8_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[8]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[8],j);

	if(user_gpio_callback_fun[8] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[8](8, pin_numbers_mask );
	}
	}

}/* PORT8_IRQHandler */

void gpio9_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[9]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[9],j);

	if(user_gpio_callback_fun[9] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[9](9, pin_numbers_mask );
	}
	}

}/* PORT9_IRQHandler */

void gpio10_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[10]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[10],j);

	if(user_gpio_callback_fun[10] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[10](10, pin_numbers_mask );
	}
	}

}/* PORT10_IRQHandler */

void gpio11_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[11]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[11],j);

	if(user_gpio_callback_fun[11] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[11](11, pin_numbers_mask );
	}
	}

}/* PORT11_IRQHandler */

void gpio12_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[12]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[12],j);

	if(user_gpio_callback_fun[12] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[12](12, pin_numbers_mask );
	}
	}

}/* PORT12_IRQHandler */

void gpio13_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[13]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[13],j);

	if(user_gpio_callback_fun[13] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[13](13, pin_numbers_mask );
	}
	}

}/* PORT13_IRQHandler */

void gpio14_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[14]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[14],j);

	if(user_gpio_callback_fun[14] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[14](14, pin_numbers_mask );
	}
	}

}/* PORT14_IRQHandler */

void gpio15_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[15]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[15],j);

	if(user_gpio_callback_fun[15] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[15](15, pin_numbers_mask );
	}
	}

}/* PORT15_IRQHandler */

void gpio16_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[16]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[16],j);

	if(user_gpio_callback_fun[16] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[16](16, pin_numbers_mask );
	}
	}

}/* PORT16_IRQHandler */

void gpio17_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[17]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[17],j);

	if(user_gpio_callback_fun[17] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[17](17, pin_numbers_mask );
	}
	}

}/* PORT17_IRQHandler */

void gpio18_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[18]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[18],j);

	if(user_gpio_callback_fun[18] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[18](18, pin_numbers_mask );
	}
	}

}/* PORT18_IRQHandler */

void gpio19_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[19]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[19],j);

	if(user_gpio_callback_fun[19] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[19](19, pin_numbers_mask );
	}
	}

}/* PORT19_IRQHandler */

void gpio20_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[20]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[20],j);

	if(user_gpio_callback_fun[20] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[20](20, pin_numbers_mask );
	}
	}

}/* PORT20_IRQHandler */


void gpio21_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[21]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[21],j);

	if(user_gpio_callback_fun[21] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[21](21, pin_numbers_mask );
	}
	}

}/* PORT21_IRQHandler */

void gpio22_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[22]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[22],j);

	if(user_gpio_callback_fun[22] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[22](22, pin_numbers_mask );
	}
	}

}/* PORT22_IRQHandler */

void gpio23_isr(void)
{
	uint32_t pin_numbers_mask;
	uint8_t j ;

	/* Get pin interrupt flag */
	pin_numbers_mask =(gpio_port[23]-> unINTR_MASKED.u32Register);

	if (pin_numbers_mask )
	{
		for( j=0;j<GPIO_MAX_PORT_PIN;j++)
			if(pin_numbers_mask & 1<<j )
				break;

	/* Clear external interrupt flag. */
	Cy_GPIO_ClearInterrupt(gpio_port[23],j);

	if(user_gpio_callback_fun[23] != NULL )
	{
		/* call user callback function */
		user_gpio_callback_fun[23](23, pin_numbers_mask );
	}
	}

}/* PORT3_IRQHandler */







