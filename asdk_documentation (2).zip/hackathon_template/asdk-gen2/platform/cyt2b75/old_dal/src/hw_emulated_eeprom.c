/*
  @file
  hw_emulated_eeprom.c

  @path
  /platform/platform/apis/hw_emulated_eeprom.c

  @Created on
  Dec 16, 2019

  @Author
  anupam.kumar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include <string.h>
#include "emulated_eeprom.h"

/*==============================================================================

                       	LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
//static const char filename[] = "hw_emulated_eeprom.c";

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/


/*==============================================================================

                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/
/*----------------------------------------------------------------------------*/
/* Function : emulated_eeprom_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function make flexRAM available as emulated eeprom.

  @param asdk_emulated_eeprom_config_t  *emulated_eeprom_config - eeprom config

  @return asdk_status_t  ASDK_EMULATED_EEPROM_STATUS_SUCCESS - on successful init
                         ASDK_EMULATED_EEPROM_INIT_FAIL - on failure

  @Note :- Important: This function should be called before any interrupts are configured and enabled

*/
asdk_status_t emulated_eeprom_init ( asdk_emulated_eeprom_config_t  *emulated_eeprom_config )
{

	/* Local Variables to store EMULATED_EEPROM status */
	asdk_emulated_eeprom_ec_t error_code = ASDK_EMULATED_EEPROM_STATUS_ERROR;

	return ASDK_EMULATED_EEPROM_RETURN(ASDK_LC_HARDWARE, error_code);

}/* emulated_eeprom_init */

/*----------------------------------------------------------------------------*/
/* Function : emulated_eeprom_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function make flexRAM available as RAM.

  @param void

  @return asdk_status_t  ASDK_EMULATED_EEPROM_STATUS_SUCCESS - on successful deinit
                         ASDK_EMULATED_EEPROM_DEINIT_FAIL - on failure

*/
asdk_status_t emulated_eeprom_deinit ( void )
{

	/* Local Variables to store EMULATED_EEPROM status */
	asdk_emulated_eeprom_ec_t error_code = ASDK_EMULATED_EEPROM_STATUS_ERROR;

	return ASDK_EMULATED_EEPROM_RETURN(ASDK_LC_HARDWARE, error_code);

}/* emulated_eeprom_deinit */

/*----------------------------------------------------------------------------*/
/* Function : emulated_eeprom_update */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function update emulated_eeprom data.

  @param void

  @return asdk_status_t  ASDK_EMULATED_EEPROM_STATUS_SUCCESS - on successful update
                         ASDK_EMULATED_EEPROM_UPDATE_FAIL - on failure

*/

asdk_status_t emulated_eeprom_update ( void )
{

	/* Local Variables to store EMULATED_EEPROM status */
	asdk_emulated_eeprom_ec_t error_code = ASDK_EMULATED_EEPROM_STATUS_ERROR;

	return ASDK_EMULATED_EEPROM_RETURN(ASDK_LC_HARDWARE, error_code);

}/* emulated_eeprom_update */


/*----------------------------------------------------------------------------*/
/* Function : emulated_eeprom_read */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function reads data from emulated_eeprom

  @param uint8_t *source - data source address

  @param uint8_t *target - emulated eeprom target address

  @param uint32_t size - data size

  @return asdk_status_t  ASDK_EMULATED_EEPROM_STATUS_SUCCESS - on successful update
                         ASDK_EMULATED_EEPROM_INVALID_ADDRESS - if target address is invalid
                         ASDK_EMULATED_EEPROM_WRITE_FAIL - on failure

*/
asdk_status_t emulated_eeprom_read ( uint8_t *source, uint8_t *target, uint32_t size )
{

	/* Local Variables to store EMULATED_EEPROM status */
	asdk_emulated_eeprom_ec_t error_code = ASDK_EMULATED_EEPROM_STATUS_ERROR;

	return ASDK_EMULATED_EEPROM_RETURN(ASDK_LC_HARDWARE, error_code);

}/* emulated_eeprom_read */


/*----------------------------------------------------------------------------*/
/* Function : emulated_eeprom_write */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function writes data in emulated_eeprom

  @param uint8_t *source - data source address

  @param uint8_t *target - emulated eeprom target address

  @param uint32_t size - data size

  @return asdk_status_t  ASDK_EMULATED_EEPROM_STATUS_SUCCESS - on successful update
                         ASDK_EMULATED_EEPROM_INVALID_ADDRESS - if target address is invalid
                         ASDK_EMULATED_EEPROM_WRITE_FAIL - on failure

*/
asdk_status_t emulated_eeprom_write ( uint8_t *source, uint8_t *target, uint32_t size )
{
	/* Local Variables to store EMULATED_EEPROM status */
	asdk_emulated_eeprom_ec_t error_code = ASDK_EMULATED_EEPROM_STATUS_ERROR;

	return ASDK_EMULATED_EEPROM_RETURN(ASDK_LC_HARDWARE, error_code);

}/* emulated_eeprom_write */
