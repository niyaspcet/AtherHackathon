/*
  @file
  hw_can.c

  @path
  hw_can.c

  @Created on
  Feb 15, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
	DAL for CAN peripheral
*/

/*

NOTE:
	1. RxFIFO0 is used with top-pointer logic regardless of HW filtering being enabled or disabled.
		* 6 CAN interfaces are supported
		* FIF0 size is 64 for 8 bytes of Data Field.
		* Filter table can contain upto 128 message IDs.
	2. 1 Mailbox is used for Transmission with index=0.
	3. Extended message IDs are not supported by DAL yet.
	4. HW filtering is enabled.
	5. Error and Bus-off handlers were added.
	> SDL v7.8.0 does not support it, we had to modify the CAN driver file to enable it.
	6. Callback events for Tx complete, Rx complete, Rx FIFO, Error and Bus-off events are supported.
		* Parser callback gets called within Iteration context.
		* Event callback gets called within Interrupt context.

Todo:
	1. Blocking APIs.
	2. Handle transciever mode with GPIO.
	3. Bit time sync. settings based on Vechical CAN.
	4. Baudrate is hardcoded to 500kbps, need derive drivers settings based on baudrate specified in configuration.
	5. Mailbox APIs.

*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/

/* SDL includes */
#include "sysint/cy_sysint.h"
#include "gpio/cy_gpio.h"
#include "canfd/cy_canfd.h"

/* DAL includes */
#include "hw_can.h"

/* ASDK includes */
#include "can.h"

/*==============================================================================

                       	LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
// static const char filename[] = "hw_can.c";

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/

#define MAX_CAN_MOD			(6U)

/* MB in use by DAL */
#define CAN_MB_IN_USE_TX	(1U)
#define CAN_MB_IN_USE_RX	(0U)

/* MB in use for TX */
#define TX_MB_IDX			(0U)

/* RX FIFO size */
#define RX_FIFO_0_SIZE		(64U)
#define RX_FIFO_1_SIZE		(0U) // unused

/* HW filter table size */
#define HW_FILTER_MAX_LEN	(128U)

/* Baudrate defines */
#define CAN_BITRATE_125KB			(125000U)
#define CAN_BITRATE_250KB			(250000U)
#define CAN_BITRATE_500KB			(500000U)
#define CAN_BITRATE_1MB				(1000000U)

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

typedef enum {	
	// CAN0
	CANFD0_CHANNEL0 = 0,
	CANFD0_CHANNEL1,
	CANFD0_CHANNEL2,
	
	// CAN1
	CANFD1_CHANNEL0,
	CANFD1_CHANNEL1,
	CANFD1_CHANNEL2,

	CANFD_MAX_CHANNELS,
	CANFD_NONE = 0xFF,
} can_instance_type;

/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/* CAN base ptrs */
static cy_pstc_canfd_type_t can_mod[MAX_CAN_MOD] = {
	CY_CANFD0_0_TYPE, CY_CANFD0_1_TYPE, CY_CANFD0_2_TYPE,
	CY_CANFD1_0_TYPE, CY_CANFD1_1_TYPE, CY_CANFD1_2_TYPE
};

/* IRQ numbers */
static cy_en_intr_t can_irqn_line0[MAX_CAN_MOD] = {
	canfd_0_interrupts0_0_IRQn,
	canfd_0_interrupts0_1_IRQn,
	canfd_0_interrupts0_2_IRQn,
	canfd_1_interrupts0_0_IRQn,
	canfd_1_interrupts0_1_IRQn,
	canfd_1_interrupts0_2_IRQn
};

/* user callback functions */
static asdk_can_callback_fun_t user_can_callback_fun_list[MAX_CAN_MOD];

/* can rx buffer used by DAL to hold a received msg */
static cy_stc_canfd_msg_t can_rx_msg = {0};
static cy_stc_canfd_msg_t can_rx_fifo0_msg = {0};
static cy_stc_canfd_msg_t can_rx_fifo1_msg = {0};

/* Standard ID Filter configration */
static cy_stc_id_filter_t stdIdFilter[HW_FILTER_MAX_LEN] = {0};
/* for reference: MB HW filtering
static const cy_stc_id_filter_t stdIdFilter[] = 
{
    CANFD_CONFIG_STD_ID_FILTER_CLASSIC_RXBUFF(0x010u, 0u),      // ID=0x010, store into RX buffer Idx0
    CANFD_CONFIG_STD_ID_FILTER_CLASSIC_RXBUFF(0x020u, 1u),      // ID=0x020, store into RX buffer Idx1
};
*/

/* Extended ID Filter configration */
// unused by LDU app, so not supported yet
static cy_stc_extid_filter_t extIdFilter[] = {0};
/* for reference: MB HW filtering
{
    CANFD_CONFIG_EXT_ID_FILTER_CLASSIC_RXBUFF(0x10010u, 2u),    // ID=0x10010, store into RX buffer Idx2
    CANFD_CONFIG_EXT_ID_FILTER_CLASSIC_RXBUFF(0x10020u, 3u),    // ID=0x10020, store into RX buffer Idx3
};
*/

// todo: need to support transceiver wake
// use case not known
static asdk_can_transceiver_mode_t can_transceiver_wake_up[MAX_CAN_MOD];

static can_instance_type active_interrupt_can_instance = CANFD_NONE;
static uint32_t last_can_id = 0;

/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/

static void CAN_RxMsgCallback(bool bRxFifoMsg, uint8_t u8MsgBufOrRxFifoNum, cy_stc_canfd_msg_t* pstcCanFDmsg);
static void CAN_RxFIFOWithTopCallback(uint8_t u8FifoNum, uint8_t u8BufferSizeInWord, uint32_t* pu32RxBuf);
static void CAN_TxCallback ( void );
static void CAN_ErrorCallback ( cy_en_canfd_bus_error_t volatile errorcode );

static void Canfd0Ch0_InterruptHandler(void);
static void Canfd0Ch1_InterruptHandler(void);
static void Canfd0Ch2_InterruptHandler(void);
static void Canfd1Ch0_InterruptHandler(void);
static void Canfd1Ch1_InterruptHandler(void);
static void Canfd1Ch2_InterruptHandler(void);

cy_systemIntr_Handler can_isr[MAX_CAN_MOD] = {
	Canfd0Ch0_InterruptHandler,
	Canfd0Ch1_InterruptHandler,
	Canfd0Ch2_InterruptHandler,
	Canfd1Ch0_InterruptHandler,
	Canfd1Ch1_InterruptHandler,
	Canfd1Ch2_InterruptHandler
};

/*==============================================================================

                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/* Function : can_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initialize CAN instance

  @param asdk_can_config_t* can_config - can init configuration ( input )

  @return asdk_status_t  ASDK_CAN_STATUS_SUCCESS if successful can init
						 ASDK_CAN_RANGE_EXCEEDED if can range is exceeded
						 ASDK_CAN_INIT_FAIL if can init not fail

*/
asdk_status_t can_init ( asdk_can_config_t* can_config )
{
	/* Local Variables to store CAN status */
	cy_stc_sysint_irq_t irq_cfg;
	asdk_can_ec_t error_code = ASDK_CAN_STATUS_SUCCESS;
	cy_en_canfd_status_t cy_can_status = CY_CANFD_SUCCESS;

	/* check for maximum can no */
	if(can_config->can_no > MAX_CAN_MOD)
	{
		error_code  = ASDK_CAN_RANGE_EXCEEDED;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(can_no > MAX_CAN_MOD) */

	/* check valid baudrate */
	if ((can_config->baud_rate == CAN_BITRATE_125KB) || (can_config->baud_rate == CAN_BITRATE_250KB) ||
	    (can_config->baud_rate == CAN_BITRATE_500KB) || (can_config->baud_rate == CAN_BITRATE_1MB))
	{
		/* DO NOTHING */
	}
	else
	{
		error_code  = ASDK_CAN_INVALID_BAUDRATE;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	}

	/* CAN interrupt configuration */
	irq_cfg.sysIntSrc  = can_irqn_line0[can_config->can_no], /* Use interrupt LINE0 */
	irq_cfg.intIdx     = CPUIntIdx3_IRQn,
	irq_cfg.isEnabled  = true,

	/* Initialize CAN interrupt */
	Cy_SysInt_InitIRQ(&irq_cfg);
	Cy_SysInt_SetSystemIrqVector(irq_cfg.sysIntSrc, can_isr[can_config->can_no]);
	NVIC_SetPriority(CPUIntIdx3_IRQn, 0);
	NVIC_ClearPendingIRQ(CPUIntIdx3_IRQn);
	NVIC_EnableIRQ(CPUIntIdx3_IRQn);
	
	// todo: initliaze can configuration
	// todo: map CAN instance to CAN base adresses
	/* CAN configuration */
	cy_stc_canfd_config_t canCfg = 
	{
		.txCallback     = CAN_TxCallback,
		.rxCallback     = CAN_RxMsgCallback,
		.rxFifoWithTopCallback = CAN_RxFIFOWithTopCallback,
		.statusCallback = NULL, // Un-supported now
		.errorCallback  = CAN_ErrorCallback,

		.canFDMode      = false, // Use standard CAN mode

		// todo: derive prescaler settings based on baudrate
		// 40 MHz
		.bitrate        =       // Nominal bit rate settings (sampling point = 75%)
		{
			.prescaler      = 10u - 1u,  // cclk/10, When using 500bps, 1bit = 8tq
			.timeSegment1   = 5u - 1u, // tseg1 = 5tq
			.timeSegment2   = 2u - 1u,  // tseg2 = 2tq
			.syncJumpWidth  = 2u - 1u,  // sjw   = 2tq
		},		
		.tdcConfig      =       // Transceiver delay compensation, unused.
		{
			.tdcEnabled     = false,
			.tdcOffset      = 0,
			.tdcFilterWindow= 0,
		},
		.sidFilterConfig    =   // Standard ID filter
		{
			.numberOfSIDFilters = 0,
			.sidFilter          = stdIdFilter,
		},
		.extidFilterConfig  =   // Extended ID filter
		{
			.numberOfEXTIDFilters   = 0,
			.extidFilter            = extIdFilter,
			.extIDANDMask           = 0x1fffffff,   // No pre filtering.
		},
		.globalFilterConfig =   // Global filter
		{
			.nonMatchingFramesStandard = CY_CANFD_REJECT_NON_MATCHING,  // Reject none match IDs
			.nonMatchingFramesExtended = CY_CANFD_REJECT_NON_MATCHING,  // Reject none match IDs
			.rejectRemoteFramesStandard = true, // No remote frame
			.rejectRemoteFramesExtended = true, // No remote frame
		},
		.rxBufferDataSize = CY_CANFD_BUFFER_DATA_SIZE_8,
		.rxFifo1DataSize  = CY_CANFD_BUFFER_DATA_SIZE_8,
		.rxFifo0DataSize  = CY_CANFD_BUFFER_DATA_SIZE_8,
		.txBufferDataSize = CY_CANFD_BUFFER_DATA_SIZE_8,
		.rxFifo0Config    =		// In use as default by DAL
		{
			.mode = CY_CANFD_FIFO_MODE_BLOCKING,
			.watermark = 0u,
			.numberOfFifoElements = RX_FIFO_0_SIZE,
			.topPointerLogicEnabled = true,
		},
		.rxFifo1Config  = // RX FIFO1, unused.
		{
			.mode = CY_CANFD_FIFO_MODE_BLOCKING,
			.watermark = 0u,
			.numberOfFifoElements = RX_FIFO_1_SIZE,
			.topPointerLogicEnabled = false,
		},
		.noOfRxBuffers  = CAN_MB_IN_USE_RX,
		.noOfTxBuffers  = CAN_MB_IN_USE_TX,
	};

	// Update FIFO_0 HW filter
	if (can_config->can_filter_data.filter_enable)
	{
		if (can_config->can_filter_data.id_count > HW_FILTER_MAX_LEN)
		{
			error_code = ASDK_CAN_STATUS_ERROR;
			return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
		}

		// In FIFO_0 accept messages that match the given filter
		canCfg.sidFilterConfig.numberOfSIDFilters = can_config->can_filter_data.id_count;

		for(uint8_t i=0; i<can_config->can_filter_data.id_count; i++)
		{
			stdIdFilter[i].sfid1 = can_config->can_filter_data.can_filter_id[i];
			stdIdFilter[i].sfid2 = 0x7FF;
        	stdIdFilter[i].sfec  = CY_CANFD_ID_FILTER_ELEMNT_CONFIG_SET_PIORITY_STORE_RXFIFO0;
        	stdIdFilter[i].sft   = (uint32_t)CY_CANFD_STD_ID_FILTER_TYPE_CLASSIC;
		}
	}
	else
	{
		// In FIFO_0 accept all messages by default
		canCfg.sidFilterConfig.numberOfSIDFilters = 1;

		stdIdFilter[0].sfid1 = 0x00;
		stdIdFilter[0].sfid2 = 0x00;
		stdIdFilter[0].sfec  = CY_CANFD_ID_FILTER_ELEMNT_CONFIG_SET_PIORITY_STORE_RXFIFO0;
		stdIdFilter[0].sft   = (uint32_t)CY_CANFD_STD_ID_FILTER_TYPE_CLASSIC;
	}

	cy_can_status = Cy_CANFD_Init(can_mod[can_config->can_no], &canCfg);
	if (cy_can_status != CY_CANFD_SUCCESS)
	{
		error_code = ASDK_CAN_INIT_FAIL;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	}

	// todo: self_wakeup configuration
	#if 0 // self_wakeup
	if( ( can_config->self_wakeup == true ) && ( error_code == ASDK_CAN_STATUS_SUCCESS ))
	{
		error_code = CAN_ConfigTxBuff(can_config->can_no, CAN_TX_MAILBOX, &tx_buff_config);
		if ( error_code == ASDK_CAN_STATUS_SUCCESS && can_config->increase_rx_fifo)
			error_code = CAN_ConfigRxBuff(can_config->can_no, CAN_RX_MAILBOX1, &recv_buff_config, can_filter_id[can_config->can_no]);
	}
	#endif // self_wakeup

	/* Check for error */
	if (error_code )
		error_code = ASDK_CAN_INIT_FAIL;

	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);

}/* can_init */

/*----------------------------------------------------------------------------*/
/* Function : can_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-initialize can module

  @param uint8_t can_no - can module no ( input )

  @return asdk_status_t  ASDK_CAN_STATUS_SUCCESS if successful can de-init
						 ASDK_CAN_RANGE_EXCEEDED if can range is exceeded
						 ASDK_CAN_DEINIT_FAIL if unsuccessful can deinit

*/
asdk_status_t can_deinit ( uint8_t can_no )
{
	/* Local Variables to store CAN status */
	cy_en_canfd_status_t cy_can_status = CY_CANFD_SUCCESS;
	asdk_can_ec_t error_code = ASDK_CAN_STATUS_SUCCESS;

    /* check for maximum can no */
	if(can_no > MAX_CAN_MOD)
	{
		error_code  = ASDK_CAN_RANGE_EXCEEDED;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(can_no > MAX_CAN_MOD) */

	/* Algorithm */
	cy_can_status = Cy_CANFD_DeInit(can_mod[can_no]);
	if ( cy_can_status != CY_CANFD_SUCCESS )
	{
		error_code = ASDK_CAN_DEINIT_FAIL;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	}

	last_can_id = 0;

	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);

}/* can_deinit */

/*----------------------------------------------------------------------------*/
/* Function : can_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback_for CAN module instance

  @param uint8_t can_no - can module no ( input )

  @param asdk_can_callback_fun_t callback_fun - can callback function ( input )

  @return asdk_status_t  ASDK_CAN_STATUS_SUCCESS if successful can callback installation
						 ASDK_CAN_RANGE_EXCEEDED if can range is exceeded
						 ASDK_CAN_STATUS_ERROR in case of failure

*/
asdk_status_t can_install_callback ( uint8_t can_no, asdk_can_callback_fun_t  callback_fun )
{

	/* Local Variables to store CAN status */
	asdk_can_ec_t error_code = ASDK_CAN_STATUS_SUCCESS;

    /* check for maximum can no */
	if(can_no > MAX_CAN_MOD)
	{
		error_code  = ASDK_CAN_RANGE_EXCEEDED;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(can_no > MAX_CAN_MOD) */

	/* 
		In CYT2B7 install can callback API is not available.

		Also, the error and bus-off interrupts are handled
		by driver IRQ handler in Cy_CANFD_ErrorHandling function.
	*/

	user_can_callback_fun_list[can_no] = callback_fun;

	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);

}/* can_install_callback */

/*----------------------------------------------------------------------------*/
/* Function : can_send_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the CAN module using a blocking method

  @param uint8_t can_no - can module no ( input )

  @param uint32_t can_id - can id ( input )

  @param const uint8_t * txBuff - can transmit data buf ( input )

  @param uint32_t txSize - can tx data size (input)

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission

*/
asdk_status_t can_send_blocking ( uint8_t can_no, uint32_t can_id, const uint8_t * txBuff, uint8_t txSize  )
{
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}/* can_send_blocking */

/*----------------------------------------------------------------------------*/
/* Function : can_receive_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data through the CAN module using a blocking method

  @param uint8_t can_no - can module ( input )

   @param uint32_t can_id - can id ( output )

  @param uint8_t  rxBuff[]  - can receive buffer ( output )

  @param uint32_t *rxSize - can receive byte size ( output )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission
                         ASDK_CAN_RECEIVE_FAIL if an error occurred

*/
asdk_status_t  can_receive_blocking ( uint8_t can_no, uint32_t *can_id, uint8_t rxBuff[], uint32_t *rxSize )
{
	/* Such API is not available in CYT2B7 */
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}/* can_receive_blocking */

/*----------------------------------------------------------------------------*/
/* Function : can_mailbox_batch_config */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function assigns mailbox number to an array of config with canid and transfer_type corresponding to asdk_can_message_config_t

  @param uint8_t can_no - can module ( input )

   @param asdk_can_message_config_t *config- config ( input )

  @param uint8_t  size  - size( input )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission
                         ASDK_MAILBOX_CONFIG_FAILED if an error occurred

*/
asdk_status_t can_mailbox_batch_config( uint8_t can_no, asdk_can_message_config_t *config, uint8_t size)
{
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}

/*----------------------------------------------------------------------------*/
/* Function : can_mailbox_config */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function assigns mailbox number to a config with canid and transfer_type corresponding to asdk_can_message_config_t

  @param uint8_t can_no - can module ( input )

   @param asdk_can_message_config_t config- config ( input )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission
                         ASDK_CANID_ALREADY_CONFIGURED if already configured
                         ASDK_CAN_BUFFER_RANGE_EXCEEDED if an error occurred

*/
asdk_status_t can_mailbox_config( uint8_t can_no, asdk_can_message_config_t config )
{	
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}

/*----------------------------------------------------------------------------*/
/* Function : can_get_mailbox_id */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets the mailbox number assigned to a can_id with the specified transfer_type

  @param uint8_t can_no - can module ( input )

   @param asdk_can_message_config_t config- config ( input )

   @param uint8_t *mb_id- *mb_id ( output )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission
                         ASDK_CANID_ALREADY_CONFIGURED if already configured
                         ASDK_CAN_BUFFER_RANGE_EXCEEDED if an error occurred

*/
asdk_status_t can_get_mailbox_id( uint8_t can_no, uint32_t can_id, uint8_t * mb_id, bool transfer)
{
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}

/*----------------------------------------------------------------------------*/
/* Function : can_free_mailbox_id */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function deallocates the mailbox number assigned to a can_id with the specified transfer_type

  @param uint8_t can_no - can module ( input )

   @param asdk_can_message_config_t config- config ( input )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission
                         ASDK_CANID_NOT_CONFIGURED_IN_MAILBOX if not configured

*/
asdk_status_t can_free_mailbox_id( uint8_t can_no, asdk_can_message_config_t config)
{	
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}

/*----------------------------------------------------------------------------*/
/* Function : can_send_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the CAN module using a non_blocking method

  @param uint8_t can_no - can module no ( input )

  @param uint32_t can_id - can id ( input )

  @param const uint8_t * txBuff - can transmit data buf ( input )

  @param uint32_t txSize - can tx data size (input)

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission

*/
asdk_status_t  can_send_non_blocking ( uint8_t can_no, uint32_t can_id, const uint8_t * txBuff, uint8_t txSize )
{
	cy_en_canfd_status_t cy_can_status = CY_CANFD_SUCCESS;
	asdk_can_ec_t error_code = ASDK_CAN_STATUS_SUCCESS;
	cy_stc_canfd_msg_t stcMsg;

	/* check for max can module */
	if(can_no >= MAX_CAN_MOD)
	{
		error_code  = ASDK_CAN_RANGE_EXCEEDED;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(can_no >= MAX_CAN_MOD) */

	/* create can tx packet */
	stcMsg.canFDFormat = false;
	stcMsg.idConfig.extended = false;
	stcMsg.idConfig.identifier = can_id;
	stcMsg.dataConfig.dataLengthCode = txSize;
	memcpy(stcMsg.dataConfig.data, txBuff, txSize);

	last_can_id = can_id;

	cy_can_status = Cy_CANFD_UpdateAndTransmitMsgBuffer(can_mod[can_no], TX_MB_IDX, &stcMsg);
	if (cy_can_status != CY_CANFD_SUCCESS)
		error_code = ASDK_CAN_SEND_FAIL;

	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
}/* can_send_blocking */

/*----------------------------------------------------------------------------*/
/* Function : can_send_non_blocking_mailbox */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the CAN module using a non_blocking method via mailbox
  For S32K144 already happening through can_send_non_blocking

  @param uint8_t can_no - can module no ( input )

  @param uint32_t can_id - can id ( input )

  @param const uint8_t * txBuff - can transmit data buf ( input )

  @param uint32_t txSize - can tx data size (input)

  @return asdk_status_t  Need to discuss before implementing
                         ASDK_CAN_STATUS_SUCCESS on successful transmission

*/
asdk_status_t  can_send_non_blocking_mailbox ( uint8_t can_no, uint32_t can_id, const uint8_t * txBuff, uint8_t txSize )
{
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}

/*----------------------------------------------------------------------------*/
/* Function : can_receive_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data through the CAN module using a non- blocking method

  @param uint8_t can_no - can module no ( input )

  @param uint32_t rxSize - - can rx data size (input)

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission
                         ASDK_CAN_RECEIVE_FAIL if an error occurred

*/
asdk_status_t  can_receive_non_blocking ( uint8_t can_no, uint8_t rxSize )
{
	/* Note: Such API is not available in CYT2B7 driver

	Return success because asdk_can_receive_non_blocking return status is
	further returned by asdk_can_task_init in can_services.c
	if ASDK_CAN_FEATURE_NOT_IMPLEMENTED was returned then asdk_can_task_init
	will also return it which will cause init to fail.
	
	*/

	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_STATUS_SUCCESS);
}/* can_receive_blocking */

asdk_status_t  can_receive_non_blocking_increased_fifo ( uint8_t can_no, uint8_t rxSize )
{
	/* Note: Such API is not available in CYT2B7 driver */
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_STATUS_SUCCESS);
}/* can_receive_non_blocking_increased_fifo */

/*----------------------------------------------------------------------------*/
/* Function : can_receive_non_blocking_mailbox */
/*----------------------------------------------------------------------------*/
/* receive can_message via mailbox. The function first checks if a mailbox is assigned to it through the can_message_mailbox array then
 * configures it and starts the reception process
 *  @param uint8_t can_no - can module no ( input )

  @param uint32_t rxSize - - can rx data size (input)

  @param uint32_t can_id - - can_id (input)

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission
                         ASDK_CAN_RECEIVE_FAIL if an error occurred
 *  */
asdk_status_t  can_receive_non_blocking_mailbox ( uint8_t can_no, uint32_t can_id, uint8_t rxSize )
{
	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, ASDK_CAN_FEATURE_NOT_IMPLEMENTED);
}/* can_receive_non_blocking_via_mailbox */

/*----------------------------------------------------------------------------*/
/* Function : can_is_tx_busy */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets can tx busy status

  @param uint8_t can_no  - can module no ( input )

  @param bool* status - tx busy status ( output )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission

*/
asdk_status_t can_is_tx_busy ( uint8_t can_no, bool *status )
{
    /* Local Variables to store CAN status */
    asdk_can_ec_t error_code = ASDK_CAN_STATUS_SUCCESS;

    /* check for maximum can no */
    if(can_no > MAX_CAN_MOD)
    {
        error_code  = ASDK_CAN_RANGE_EXCEEDED;
        return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
    } /* if(can_no > MAX_CAN_MOD) */

    /* Algorithm */
	// Tx is pending = BUSY, else IDLE
	*status = (can_mod[can_no]->M_TTCAN.unTXBRP.u32Register >> TX_MB_IDX) & 1;

    return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);

}/* can_is_tx_busy */

/*----------------------------------------------------------------------------*/
/* Function : can_set_transceiver_mode */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function sets can transceiver mode

  @param uint8_t can_no - can module no ( input )

  @param asdk_can_transceiver_mode_t mode - can transceiver mode ( input )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission

*/
asdk_status_t can_set_transceiver_mode ( uint8_t can_no, asdk_can_transceiver_mode_t mode  )
{

	/* Local Variables to store CAN status */
	asdk_can_ec_t error_code = ASDK_CAN_STATUS_SUCCESS;

    /* check for maximum can no */
	if(can_no > MAX_CAN_MOD)
	{
		error_code  = ASDK_CAN_RANGE_EXCEEDED;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(can_no > MAX_CAN_MOD) */

	/* Algorithm */
	switch (mode) {

	case ASDK_CAN_HIGH_SPEED_MODE:
		// todo: use GPIO pin to enable high speed mode
		// PINS_DRV_SetPins(gpio_port[CAN_TRANSCEIVER_PORT], (uint32_t)PIN_MASK(CAN_TRANSCEIVER_PIN));
		// Cy_GPIO_Set(gpio_port[CAN_TRANSCEIVER_PORT], (uint32_t)PIN_MASK(CAN_TRANSCEIVER_PIN));
		can_transceiver_wake_up[can_no] = ASDK_CAN_HIGH_SPEED_MODE;
		break;

	case ASDK_CAN_LOW_SPEED_MODE:
		// todo: use GPIO pin enable low speed mode
		// PINS_DRV_ClearPins(gpio_port[CAN_TRANSCEIVER_PORT], (uint32_t)PIN_MASK(CAN_TRANSCEIVER_PIN));
		// Cy_GPIO_Clr(gpio_port[CAN_TRANSCEIVER_PORT], (uint32_t)PIN_MASK(CAN_TRANSCEIVER_PIN));
		can_transceiver_wake_up[can_no] = ASDK_CAN_LOW_SPEED_MODE;
		break;

	default:
		break;
	}

	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);

}/* can_set_transceiver_mode */

/*----------------------------------------------------------------------------*/
/* Function : can_get_transceiver_mode */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function gets can transceiver mode

  @param uint8_t can_no - can module no ( input )

  @param asdk_can_transceiver_mode_t *mode -  can transceiver mode ( output )

  @return asdk_status_t  ASDK_CAN_RANGE_EXCEEDED if can range is more than 1
                         ASDK_CAN_STATUS_SUCCESS on successful transmission

*/
asdk_status_t can_get_transceiver_mode ( uint8_t can_no, asdk_can_transceiver_mode_t *mode  )
{

	/* Local Variables to store CAN status */
	asdk_can_ec_t error_code = ASDK_CAN_STATUS_SUCCESS;

    /* check for maximum can no */
	if(can_no > MAX_CAN_MOD)
	{
		error_code  = ASDK_CAN_RANGE_EXCEEDED;
		return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(can_no > MAX_CAN_MOD) */

	/* Algorithm */
	*mode =	can_transceiver_wake_up[can_no];

	return ASDK_CAN_RETURN(ASDK_LC_HARDWARE, error_code);

}/* can_get_transceiver_mode */

/* CAN ISR Handlers */
static void Canfd0Ch0_InterruptHandler(void)
{
    active_interrupt_can_instance = CANFD0_CHANNEL0;
    Cy_CANFD_IrqHandler(can_mod[active_interrupt_can_instance]);
	active_interrupt_can_instance = CANFD_NONE;
}

static void Canfd0Ch1_InterruptHandler(void)
{
    active_interrupt_can_instance = CANFD0_CHANNEL1;
    Cy_CANFD_IrqHandler(can_mod[active_interrupt_can_instance]);
	active_interrupt_can_instance = CANFD_NONE;
}

static void Canfd0Ch2_InterruptHandler(void)
{
    active_interrupt_can_instance = CANFD0_CHANNEL2;
    Cy_CANFD_IrqHandler(can_mod[active_interrupt_can_instance]);
	active_interrupt_can_instance = CANFD_NONE;
}

static void Canfd1Ch0_InterruptHandler(void)
{
    active_interrupt_can_instance = CANFD1_CHANNEL0;
    Cy_CANFD_IrqHandler(can_mod[active_interrupt_can_instance]);
	active_interrupt_can_instance = CANFD_NONE;
}

static void Canfd1Ch1_InterruptHandler(void)
{
    active_interrupt_can_instance = CANFD1_CHANNEL1;
    Cy_CANFD_IrqHandler(can_mod[active_interrupt_can_instance]);
	active_interrupt_can_instance = CANFD_NONE;
}

static void Canfd1Ch2_InterruptHandler(void)
{
    active_interrupt_can_instance = CANFD1_CHANNEL2;
    Cy_CANFD_IrqHandler(can_mod[active_interrupt_can_instance]);
	active_interrupt_can_instance = CANFD_NONE;
}

/* CAN driver callbacks, Interrupt context */
static void CAN_RxMsgCallback(bool bRxFifoMsg, uint8_t u8MsgBufOrRxFifoNum, cy_stc_canfd_msg_t* pstcCanFDmsg)
{
	cy_stc_canfd_msg_t *p_rx_msg;
	uint8_t can_event = ASDK_CAN_ERROR_EVENT;

	if (bRxFifoMsg)
	{	
		can_event = ASDK_CAN_RECEIVE_FIFO_EVENT;
		p_rx_msg = u8MsgBufOrRxFifoNum ? &can_rx_fifo1_msg :
									      &can_rx_fifo0_msg;
	}
	else
	{
		can_event = ASDK_CAN_RECEIVE_MAILBOX_EVENT;
		p_rx_msg = &can_rx_msg;
	}

	memcpy(p_rx_msg, pstcCanFDmsg, sizeof(cy_stc_canfd_msg_t));

	// for testing only
	// p_rx_msg->idConfig.identifier += 1;
	// Cy_CANFD_UpdateAndTransmitMsgBuffer(CY_CANFD0_1_TYPE,
	// 									TX_MB_IDX,
	// 									p_rx_msg);

	if ( user_can_callback_fun_list[active_interrupt_can_instance] != NULL )
	{
		user_can_callback_fun_list[active_interrupt_can_instance](
			active_interrupt_can_instance,
			pstcCanFDmsg->idConfig.identifier,
			(uint8_t *) &pstcCanFDmsg->dataConfig.data,
			pstcCanFDmsg->dataConfig.dataLengthCode,
			pstcCanFDmsg->idConfig.extended,
			can_event
		);
	}
}

static void CAN_RxFIFOWithTopCallback(uint8_t u8FifoNum, uint8_t u8BufferSizeInWord, uint32_t* pu32RxBuf)
{
	cy_stc_canfd_msg_t *p_can_rxfifo_msg = u8FifoNum ? 
										   &can_rx_fifo1_msg :
										   &can_rx_fifo0_msg;

	Cy_CANFD_ExtractMsgFromRXBuffer((cy_stc_canfd_rx_buffer_t *) pu32RxBuf, 
									 p_can_rxfifo_msg);

	// for testing only
	// p_can_rxfifo_msg->idConfig.identifier += 1;
	// Cy_CANFD_UpdateAndTransmitMsgBuffer(CY_CANFD0_1_TYPE,
	//                                     TX_MB_IDX,
	// 									p_can_rxfifo_msg);
	
	if ( user_can_callback_fun_list[active_interrupt_can_instance] != NULL )
	{
		user_can_callback_fun_list[active_interrupt_can_instance](
			active_interrupt_can_instance,
			p_can_rxfifo_msg->idConfig.identifier,
			(uint8_t *) &p_can_rxfifo_msg->dataConfig.data,
			p_can_rxfifo_msg->dataConfig.dataLengthCode,
			p_can_rxfifo_msg->idConfig.extended,
			ASDK_CAN_RECEIVE_FIFO_EVENT
		);
	}
}

static void CAN_TxCallback ( void )
{
	if ( user_can_callback_fun_list[active_interrupt_can_instance] != NULL )
	{
		user_can_callback_fun_list[active_interrupt_can_instance](
			active_interrupt_can_instance,
			last_can_id,
			0,
			0,
			false,
			ASDK_CAN_TRANSMIT_COMPLETE_EVENT
		);
	}
}

static void CAN_ErrorCallback (cy_en_canfd_bus_error_t volatile errorcode)
{
	uint8_t can_event = ASDK_CAN_ERROR_EVENT;

	if (errorcode == 5)
		can_event = ASDK_CAN_BUS_OFF_EVENT;

	if ( user_can_callback_fun_list[active_interrupt_can_instance] != NULL )
	{
		user_can_callback_fun_list[active_interrupt_can_instance](
			active_interrupt_can_instance,
			last_can_id,
			0,
			0,
			false,
			can_event
		);
	}
}
