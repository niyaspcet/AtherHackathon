/*
  @file
  hw_i2c.c

  @path
  /frdmkw36_demo_apps_power_manager/source/hw_i2c.c

  @Created on
  Jan 18, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

/* todo:
        1. sub_address for read and write
        2. testing with higher data
        3. blocking APIs
        4. directly assign isr from DAL
        5. const value on left (if)
*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include "hw_i2c.h"
#include <string.h>
#include "sysclk/cy_sysclk.h"
#include "gpio/cy_gpio.h"
#include "scb/cy_scb_i2c.h"

#include "scb_config.h"
#include "hw_scb_int.h"

/*==============================================================================

                        LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
// static const char filename[] = "hw_i2c.c";

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/

#include "scb_config.h"
#include "hw_scb_int.h"

#define MAX_I2C_MOD SCB_MAX_I2C_MODULES
#define TRANSFER_SIZE (32u) // todo: move to generated_code (low pri)

#define E_I2C_INCLK_TARGET_FREQ (2000000ul) // todo: move to clock config
/* static array of function pointer to hold user callback function */
static asdk_i2c_callback_fun_t user_i2c_callback_fun_list[MAX_I2C_MOD];

static cy_stc_scb_i2c_master_xfer_config_t g_stc_i2c_master_config[MAX_I2C_MOD];
static cy_stc_scb_i2c_context_t g_stc_i2c_context[MAX_I2C_MOD];

/* Declaration of the LPI2C RX buffer */
uint8_t rxBuffer[TRANSFER_SIZE];
/* Declaration of the LPI2C TX buffer */
uint8_t txBuffer[TRANSFER_SIZE];

void I2C0_ISR_UserCallback(void);
void I2C1_ISR_UserCallback(void);

scb_user_cb_type I2C_User_callbacks[MAX_I2C_MOD] = {
    I2C0_ISR_UserCallback,
    I2C1_ISR_UserCallback,
};

extern volatile stc_SCB_t *scb_base_ptrs[];
extern uint8_t scb_i2c[];

/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/

void scb0_i2c_callback(uint32_t event);
/*==============================================================================

                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/

void I2C0_ISR_UserCallback(void)
{
        /* I2C interrupt handler for High-Level APIs */
        Cy_SCB_I2C_Interrupt(scb_base_ptrs[scb_i2c[0]], &g_stc_i2c_context[0]);
}

void I2C1_ISR_UserCallback(void)
{
        /* I2C interrupt handler for High-Level APIs */
        Cy_SCB_I2C_Interrupt(scb_base_ptrs[scb_i2c[1]], &g_stc_i2c_context[1]);
}

void i2c0_event_callback_handler(uint32_t i2c_event)
{
        uint8_t i2c_no = 0;
        uint8_t transferSize = (uint8_t)g_stc_i2c_context[i2c_no].masterNumBytes;

        /*execute callback_function */
        // if ( event == I2C_MASTER_EVENT_END_TRANSFER )
        if ((i2c_event == CY_SCB_I2C_MASTER_WR_CMPLT_EVENT) || (i2c_event == CY_SCB_I2C_MASTER_RD_CMPLT_EVENT))
                user_i2c_callback_fun_list[i2c_no](i2c_no, NULL, &transferSize, ASDK_I2C_COMPLETE_EVENT, ASDK_I2C_MASTER);
}

void i2c1_event_callback_handler(uint32_t i2c_event)
{
        uint8_t i2c_no = 1;
        uint8_t transferSize = (uint8_t)g_stc_i2c_context[i2c_no].masterNumBytes;

        /*execute callback_function */
        // if ( event == I2C_MASTER_EVENT_END_TRANSFER )
        if ((i2c_event == CY_SCB_I2C_MASTER_WR_CMPLT_EVENT) || (i2c_event == CY_SCB_I2C_MASTER_RD_CMPLT_EVENT))
                user_i2c_callback_fun_list[i2c_no](i2c_no, NULL, &transferSize, ASDK_I2C_COMPLETE_EVENT, ASDK_I2C_MASTER);
}

/*----------------------------------------------------------------------------*/
/* Function : i2c_master_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Initializes an I2C master operation instance

  @param i2c_master_config_t i2c_config_data

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                        ASDK_I2C_STATUS_SUCCESS if successful uart init;
*/
asdk_status_t i2c_master_init(asdk_i2c_master_config_t *i2c_config)
{
        /*local status variables*/
        asdk_i2c_ec_t error_code = ASDK_I2C_STATUS_SUCCESS;
        cy_en_scb_i2c_status_t cy_i2c_status = CY_SCB_I2C_SUCCESS;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;

        /* CYT2B7 structure configuration */
        static cy_stc_scb_i2c_config_t g_stc_i2c_config = {
            .i2cMode = CY_SCB_I2C_MASTER,
            .useRxFifo = true,
            .useTxFifo = true,
            .slaveAddress = 1,
            .slaveAddressMask = 1,
            .acceptAddrInFifo = false,
            .ackGeneralAddr = false,
            .enableWakeFromSleep = false};

        /* check for max i2c module */
        if (i2c_config->i2c_no >= MAX_I2C_MOD)
        {
                error_code = ASDK_I2C_RANGE_EXCEEDED;
                return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
        }

                /* Initialize CYT2B7 instance */
        Cy_SCB_I2C_DeInit(scb);

        scb_index = scb_i2c[i2c_config->i2c_no];
        scb = scb_base_ptrs[scb_index];



        /* Enable i2c interrupt */
        SCB_Set_DAL_Callback(scb_index, I2C_User_callbacks[i2c_config->i2c_no]);


        cy_i2c_status = Cy_SCB_I2C_Init(scb, &g_stc_i2c_config, &g_stc_i2c_context[i2c_config->i2c_no]);
        // todo: get E_I2C_INCLK_TARGET_FREQ from API?
        if (cy_i2c_status == CY_SCB_I2C_SUCCESS)
        {
                Cy_SCB_I2C_SetDataRate(scb, i2c_config->baud_rate, E_I2C_INCLK_TARGET_FREQ);
                Cy_SCB_I2C_Enable(scb);
        }
        else
        {
                error_code = ASDK_I2C_INIT_FAIL;
        }

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);

} /* i2c_master_init */

/*----------------------------------------------------------------------------*/
/* Function : i2c_master_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-Initializes an I2C master operation instance

  @param uint8_t i2c_no

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                        ASDK_I2C_STATUS_SUCCESS on successful

*/
asdk_status_t i2c_master_deinit(uint8_t i2c_no)
{
        /* Local Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_STATUS_SUCCESS;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;

        /* check for max i2c module */
        if (i2c_no >= MAX_I2C_MOD)
        {
                error_code = ASDK_I2C_RANGE_EXCEEDED;
                return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
        }

        scb_index = scb_i2c[i2c_no];
        scb = scb_base_ptrs[scb_index];

        /* Algorithm */
        Cy_SCB_I2C_DeInit(scb);
        SCB_Clear_DAL_Callback(scb_index);

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);

} /* i2c_master_deinit */

/*----------------------------------------------------------------------------*/
/* Function : i2c_master_write_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the i2c master module using blocking method

  @param uint8_t i2c_no

  @param asdk_i2c_data_transfer_t *i2c_data_send

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                        ASDK_I2C_TRANSFER_FAIL if transfer fails

*/
asdk_status_t i2c_master_write_blocking(uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_send)
{
        /* Local Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_NOT_IMPLEMENTED;

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
} /* i2c_master_write_blocking */

/*----------------------------------------------------------------------------*/
/* Function : i2c_master_read_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function reads data through the i2c master module using blocking method

  @param uint8_t i2c_no

  @param asdk_i2c_data_transfer_t *i2c_data_rcv

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                        ASDK_I2C_TRANSFER_FAIL if transfer fails

*/
asdk_status_t i2c_master_read_blocking(uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_rcv)
{
        /* Local Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_NOT_IMPLEMENTED;

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
} /* i2c_master_read_blocking */

/*----------------------------------------------------------------------------*/
/* Function : i2c_master_write_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the I2C master module using non-blocking method

  @param uint8_t i2c_no

  @param  asdk_i2c_data_transfer_t *i2c_data_send

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                         ASDK_I2C_TRANSFER_FAIL if transfer fails

*/
asdk_status_t i2c_master_write_non_blocking(uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_send)
{
        /* Local Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_STATUS_SUCCESS;
        cy_en_scb_i2c_status_t cy_i2c_status = CY_SCB_I2C_SUCCESS;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;

        /* check for max i2c module */
        if (i2c_no >= MAX_I2C_MOD)
        {
                error_code = ASDK_I2C_RANGE_EXCEEDED;
                return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
        }

        /* Specifying the slave address */
        g_stc_i2c_master_config[i2c_no].slaveAddress = i2c_data_send->slave_addr;

        scb_index = scb_i2c[i2c_no];
        scb = scb_base_ptrs[scb_index];

        /* send sub address to slave */
        if (i2c_data_send->sub_address_size > ASDK_NULL)
        {
                g_stc_i2c_master_config[i2c_no].buffer = (uint8_t *)&i2c_data_send->sub_address;
                g_stc_i2c_master_config[i2c_no].bufferSize = i2c_data_send->sub_address_size;

                cy_i2c_status = Cy_SCB_I2C_MasterWrite(scb, &g_stc_i2c_master_config[i2c_no], &g_stc_i2c_context[i2c_no]);
        }

        /* send data to slave */
        if (i2c_data_send->length > ASDK_NULL)
        {
                g_stc_i2c_master_config[i2c_no].buffer = i2c_data_send->data_buf;
                g_stc_i2c_master_config[i2c_no].bufferSize = i2c_data_send->length;

                cy_i2c_status = Cy_SCB_I2C_MasterWrite(scb, &g_stc_i2c_master_config[i2c_no], &g_stc_i2c_context[i2c_no]);
        }

        if (cy_i2c_status != CY_SCB_I2C_SUCCESS)
        {
                error_code = ASDK_I2C_TRANSFER_FAIL;
        }

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
} /* i2c_master_write_non_blocking */

/*----------------------------------------------------------------------------*/
/* Function : i2c_master_read_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function reads data through the I2C master module using non-blocking method

  @param uint8_t i2c_no

  @param  asdk_i2c_data_transfer_t *i2c_data_rcv

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                             ASDK_I2C_TRANSFER_FAIL if transfer fails

*/
asdk_status_t i2c_master_read_non_blocking(uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_rcv)
{
        asdk_i2c_ec_t error_code = ASDK_I2C_STATUS_SUCCESS;
        cy_en_scb_i2c_status_t cy_i2c_status = CY_SCB_I2C_SUCCESS;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;

        /* check for max i2c module */
        if (i2c_no >= MAX_I2C_MOD)
        {
                error_code = ASDK_I2C_RANGE_EXCEEDED;
                return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
        }

        scb_index = scb_i2c[i2c_no];
        scb = scb_base_ptrs[scb_index];

        /* Specifying the slave address */
        g_stc_i2c_master_config[i2c_no].slaveAddress = i2c_data_rcv->slave_addr;

        /* send sub address to slave */
        if (i2c_data_rcv->sub_address_size > ASDK_NULL)
        {
                g_stc_i2c_master_config[i2c_no].buffer = (uint8_t *)&i2c_data_rcv->sub_address;
                g_stc_i2c_master_config[i2c_no].bufferSize = i2c_data_rcv->sub_address_size;

                cy_i2c_status = Cy_SCB_I2C_MasterRead(scb, &g_stc_i2c_master_config[i2c_no], &g_stc_i2c_context[i2c_no]);
        }

        /* send data to slave */
        if (i2c_data_rcv->length > ASDK_NULL)
        {
                g_stc_i2c_master_config[i2c_no].buffer = i2c_data_rcv->data_buf;
                g_stc_i2c_master_config[i2c_no].bufferSize = i2c_data_rcv->length;

                cy_i2c_status = Cy_SCB_I2C_MasterRead(scb, &g_stc_i2c_master_config[i2c_no], &g_stc_i2c_context[i2c_no]);
        }

        if (cy_i2c_status != CY_SCB_I2C_SUCCESS)
        {
                error_code = ASDK_I2C_TRANSFER_FAIL;
        }

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
} /* i2c_master_read_non_blocking */

/*----------------------------------------------------------------------------*/
/* Function : i2c_master_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback for i2c master data transfer.

  @param i2c_callback_config_t *callback_data

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                        ASDK_I2C_STATUS_SUCCESS if successful callback installation

*/
asdk_status_t i2c_master_install_callback(uint8_t i2c_no, asdk_i2c_callback_fun_t callback_fun)
{
        asdk_i2c_ec_t error_code = ASDK_I2C_STATUS_SUCCESS;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;

        if (i2c_no >= MAX_I2C_MOD)
        {
                error_code = ASDK_I2C_RANGE_EXCEEDED;
                return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
        }

        scb_index = scb_i2c[i2c_no];
        scb = scb_base_ptrs[scb_index];

        /* Register callback */
        user_i2c_callback_fun_list[i2c_no] = callback_fun;

        /* Register I2C event callback_handler */
        switch (i2c_no)
        {
        case 0:
                Cy_SCB_I2C_RegisterEventCallback(scb, i2c0_event_callback_handler, &g_stc_i2c_context[i2c_no]);
                break;
        case 1:
                Cy_SCB_I2C_RegisterEventCallback(scb, i2c1_event_callback_handler, &g_stc_i2c_context[i2c_no]);
                break;
        default:
                break;
        }

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
} /* i2c_master_install_callback */

/*----------------------------------------------------------------------------*/
/* Function : i2c_slave_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Initializes an I2C slave operation instance

  @param i2c_slave_config_t i2c_config_data

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                             ASDK_I2C_STATUS_SUCCESS if init pass

*/
asdk_status_t i2c_slave_init(asdk_i2c_slave_config_t *i2c_config_data)
{
        /* Local status Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_NOT_IMPLEMENTED;

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);

} /* i2c_slave_init */

/*----------------------------------------------------------------------------*/
/* Function : i2c_slave_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-Initializes an I2C slave operation instance

  @param uint8_t i2c_no

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                             ASDK_I2C_DEINIT_FAIL if deinit fails

*/
asdk_status_t i2c_slave_deinit(uint8_t i2c_no)
{
        /* Local Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_NOT_IMPLEMENTED;

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);

} /* i2c_slave_deinit */

/*----------------------------------------------------------------------------*/
/* Function : i2c_slave_transfer_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the I2C slave module using non-blocking method

 @param uint8_t i2c_no

  @param uint8_t length

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                             ASDK_I2C_TRANSFER_FAIL if transfer fails

*/
asdk_status_t i2c_slave_transfer_non_blocking(uint8_t i2c_no)
{
        /* Local Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_NOT_IMPLEMENTED;

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
} /* i2c_slave_transfer_non_blocking */

/*----------------------------------------------------------------------------*/
/* Function : i2c_slave_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback for i2c slave data transfer.

  @param i2c_callback_config_t *callback_data

  @return asdk_status_t  ASDK_I2C_RANGE_EXCEEDED if i2c range exceeded
                                             ASDK_I2C_STATUS_SUCCESS if callback installed

*/
asdk_status_t i2c_slave_install_callback(uint8_t i2c_no, asdk_i2c_callback_fun_t callback_fun)
{
        /* Local Variables */
        asdk_i2c_ec_t error_code = ASDK_I2C_NOT_IMPLEMENTED;

        return ASDK_I2C_RETURN(ASDK_LC_HARDWARE, error_code);
} /* i2c_master_install_callback */
