/*
  @file
  hw_uart.c

  @path
  /platform/asdk/cyt2b7/drivers/hw_uart.c

  @Created on
  Jan 23, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

/*==============================================================================

                           INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hw_uart.h"
#include "errordef.h"
#include "scb/cy_scb_uart.h"
#include  "cy_device_headers.h"
#include "cy_project.h"
#include "scb_config.h"
#include "hw_scb_int.h"
#include "dma/cy_pdma.h"
#include "dma/cy_mdma.h"

/*==============================================================================

                       	LOCAL AND EXTERNAL DEFINITIONS

==============================================================================*/

/*----------------------------------------------------------------------------*/
/*!@brief variable to define the file name */
//static const char filename[] = "hw_uart.c";
/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define TIMEOUT_MS	      1000U
#define UART_DMA_MAX_CH   2
#define UART_RECEIVE_SIZE 1
/*==============================================================================

                      LOCAL DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                    LOCAL DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/* static array of function pointer to hold user callback function */
static asdk_uart_callback_fun_t user_callback_fun_list[MAX_UART_MOD];
/*==============================================================================

                            LOCAL FUNCTION PROTOTYPES

==============================================================================*/

void UART0_ISR_UserCallback(void);
void UART1_ISR_UserCallback(void);

scb_user_cb_type UART_User_callbacks[MAX_UART_MOD] = {
        UART0_ISR_UserCallback,
        UART1_ISR_UserCallback,
};


void scb0_uart_callback_handler(uint32_t event_t);
void scb1_uart_callback_handler(uint32_t event_t);
extern volatile stc_SCB_t *scb_base_ptrs[];
extern uint8_t scb_uart[MAX_UART_MOD];
/***************DMA Transfer related variables and functions*****************/
void DW1_IntHandler(void);
void DW1_CH15_TransferComplete_IntrISR(void);
volatile stc_DW_t* DMA_Base_Ptrs[] = {DW0 ,DW1};
typedef  struct
{
	asdk_uart_transfer_type_t uart_rx_mode;
	asdk_uart_transfer_type_t uart_tx_mode;
	uint8_t uart_tx_dma_ch;
	uint8_t uart_rx_dma_ch;
	bool is_tx_busy;
}asdk_uart_transfer_mode_t;

static asdk_uart_transfer_mode_t uart_transfer_mode[MAX_UART_MOD] = { 0};
#define DMA_INVALID_CH  255 //To be checked later

/*==============================================================================

                            LOCAL FUNCTION DEFINITIONS

==============================================================================*/
/*----------------------------------------------------------------------------*/
/* Function : uart_init */
/*----------------------------------------------------------------------------*/
/*The pointer to the context structure \ref cy_stc_scb_uart_context_t allocated by the user*/
    cy_stc_scb_uart_context_t   g_stc_uart_context[MAX_UART_MOD];
    cy_stc_scb_uart_config_t    g_stc_uart_config = {
                                                   .uartMode                   = CY_SCB_UART_STANDARD,
                                                   .oversample                 = 8,
                                                   .dataWidth                  = 8,
                                                   .enableMsbFirst             = false,
                                                   .stopBits                   = CY_SCB_UART_STOP_BITS_1,
                                                   .parity                     = CY_SCB_UART_PARITY_NONE,
                                                   .enableInputFilter          = false,
                                                   .dropOnParityError          = false,
                                                   .dropOnFrameError           = false,
                                                   .enableMutliProcessorMode   = false,
                                                   .receiverAddress            = 0,
                                                   .receiverAddressMask        = 0,
                                                   .acceptAddrInFifo           = false,
                                                   .irdaInvertRx               = false,
                                                   .irdaEnableLowPowerReceiver = false,
                                                   .smartCardRetryOnNack       = false,
                                                   .enableCts                  = false,
                                                   .ctsPolarity                = CY_SCB_UART_ACTIVE_LOW,
                                                   .rtsRxFifoLevel             = 0,
                                                   .rtsPolarity                = CY_SCB_UART_ACTIVE_LOW,
                                                   .breakWidth                 = 0,
                                                   .rxFifoTriggerLevel         = 0,
                                                   .rxFifoIntEnableMask        = E_UART_RX_INTR_FACTER,
                                                   .txFifoTriggerLevel         = 0,
                                                   .txFifoIntEnableMask        = E_UART_TX_INTR_FACTER
                                                    };
 

/*DMA related confgiurations*/
/*Pripheral DMA contoller #0 (P-DMA0) with 89 channels
  Pripheral DMA contoller #1 (P-DMA1) with 33 channels
  Memory DMA contoller    #0 (M-DMA0) with 4 channels*/
#define BUFFER_SIZE     20// 36
#define DW1_CHANNEL_7   7
#define DW_Channel_noDW_CHANNEL      9// 15
static uint8_t                     au8SrcBuffer[BUFFER_SIZE];
static uint8_t rx_databuff[20];
uint8_t DW1_Software_Trigger_CH_IDX;
en_trig_output_pdma1_tr_t trig_output_en;

static  cy_stc_pdma_descr_t         stcDescr;
static  cy_stc_pdma_descr_t         rx_stcDescr;
const   cy_stc_pdma_chnl_config_t   chnl7Config = {
        /* CURR_PTR                          */    .PDMA_Descriptor =  &stcDescr,
        /* CH_CTL          PREEMPTABLE       */    .preemptable    =   0u,
        /* CH_CTL          PRIO              */    .priority       =   0u,
        /* CH_CTL          ENABLED           */    .enable         =   1u,  /* enabled after initialization */
                                                };
const   cy_stc_pdma_chnl_config_t   rx_chnl10Config = {
        /* CURR_PTR                          */    .PDMA_Descriptor =  &rx_stcDescr,
        /* CH_CTL          PREEMPTABLE       */    .preemptable    =   0u,
        /* CH_CTL          PRIO              */    .priority       =   0u,
        /* CH_CTL          ENABLED           */    .enable         =   1u,  /* enabled after initialization */
                                                };

static  cy_stc_pdma_descr_config_t  stcDw1DescrConfig = {
        /* DESCR_CTL       WAIT_FOR_DEACT    */    .deact          =   0u,
        /* DESCR_CTL       INTR_TYPE         */    .intrType       =   CY_PDMA_INTR_1ELEMENT_CMPLT,
        /* DESCR_CTL       TR_OUT_TYPE       */    .trigoutType    =   CY_PDMA_TRIGOUT_1ELEMENT_CMPLT,
        /* DESCR_CTL       CH_DISABLE        */    .chStateAtCmplt =   CY_PDMA_CH_ENABLED, // CY_PDMA_CH_DISABLED,
        /* DESCR_CTL       TR_IN_TYPE        */    .triginType     =   CY_PDMA_TRIGIN_DESCR,
        /* DESCR_CTL       DATA_SIZE         */    .dataSize       =   CY_PDMA_BYTE,
        /* DESCR_CTL       SRC_TRANSFER_SIZE */    .srcTxfrSize    =   0u,
        /* DESCR_CTL       DST_TRANSFER_SIZE */    .destTxfrSize   =   1u,
        /* DESCR_CTL       DESCR_TYPE        */    .descrType      =   CY_PDMA_1D_TRANSFER,
        /* DESCR_SRC                         */    .srcAddr        =   &au8SrcBuffer[0],
        // /* DESCR_DST                         */    .destAddr       =   (uint32_t *)&CY_USB_SCB_UART_TYPE->unTX_FIFO_WR.u32Register,
        /* DESCR_X_CTL     SRC_X_INCR        */    .srcXincr       =   1u,
        /* DESCR_X_CTL     DST_X_INCR        */    .destXincr      =   0u,
        /* DESCR_X_CTL     X_COUNT           */    .xCount         =   BUFFER_SIZE,
        /* DESCR_Y_CTL     SRC_Y_INCR        */    .srcYincr       =   0u,
        /* DESCR_Y_CTL     DST_Y_INCR        */    .destYincr      =   0u,
        /* DESCR_Y_CTL     Y_COUNT           */    .yCount         =   0u,
        /* DESCR_NEXT_PTR                    */    .descrNext      =   &stcDescr//0u
                                                };

static  cy_stc_pdma_descr_config_t  rx_stcDw1DescrConfig = {
        /* DESCR_CTL       WAIT_FOR_DEACT    */    .deact          =   0u,
        /* DESCR_CTL       INTR_TYPE         */    .intrType       =   CY_PDMA_INTR_1ELEMENT_CMPLT,
        /* DESCR_CTL       TR_OUT_TYPE       */    .trigoutType    =   CY_PDMA_TRIGOUT_1ELEMENT_CMPLT,
        /* DESCR_CTL       CH_DISABLE        */    .chStateAtCmplt =   CY_PDMA_CH_ENABLED, // CY_PDMA_CH_DISABLED,
        /* DESCR_CTL       TR_IN_TYPE        */    .triginType     =   CY_PDMA_TRIGIN_DESCR,
        /* DESCR_CTL       DATA_SIZE         */    .dataSize       =   CY_PDMA_BYTE,
        /* DESCR_CTL       SRC_TRANSFER_SIZE */    .srcTxfrSize    =   1u,
        /* DESCR_CTL       DST_TRANSFER_SIZE */    .destTxfrSize   =   0u,
        /* DESCR_CTL       DESCR_TYPE        */    .descrType      =   CY_PDMA_1D_TRANSFER,
        /* DESCR_SRC                         */    .srcAddr        =   (uint32_t *)&CY_USB_SCB_UART_TYPE->unRX_FIFO_RD.u32Register,
        /* DESCR_DST                         */    .destAddr       =   &rx_databuff[0],// (uint32_t *)&CY_USB_SCB_UART_TYPE->unTX_FIFO_WR.u32Register,
        /* DESCR_X_CTL     SRC_X_INCR        */    .srcXincr       =   1u,
        /* DESCR_X_CTL     DST_X_INCR        */    .destXincr      =   0u,
        /* DESCR_X_CTL     X_COUNT           */    .xCount         =   BUFFER_SIZE,
        /* DESCR_Y_CTL     SRC_Y_INCR        */    .srcYincr       =   0u,
        /* DESCR_Y_CTL     DST_Y_INCR        */    .destYincr      =   0u,
        /* DESCR_Y_CTL     Y_COUNT           */    .yCount         =   0u,
        /* DESCR_NEXT_PTR                    */    .descrNext      =   &stcDescr//0u
                                                };
/*!

  @brief
  This function Initializes an LPUART operation instance.

  @param asdk_uart_config_t *config

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 3
                    ASDK_UART_STATUS_SUCCESS if successful uart init;
                    ASDK_UART_INIT_FAIL if an error occurred
*/uint8_t temp_var  = 0;

asdk_status_t uart_init ( asdk_uart_config_t *config )
{

	/* Local status Variables */
	asdk_uart_ec_t error_code;
        volatile stc_SCB_t *scb = NULL;
        volatile stc_DW_t *DMA_BPTR = NULL;
        uint8_t scb_index;

       /* * Oversample factor for UART.
       * * The UART baud rate is the SCB Clock frequency / oversample---> oversample = SCB Clock frequency/ UART baud rate*/
       /* SCB - UART Configuration */
	/* check for max uart module */
	if(MAX_UART_MOD <= config->uart_no )
	{
		error_code  = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */
        //No DMA is used for the UART for now
	
        scb_index = scb_uart[config->uart_no];
        scb = scb_base_ptrs[scb_index];
        
        /* Enable uart interrupt */
        if(ASDK_UART_USING_DMA == config->transfer_type)
        {
                /*Deriving the DMA module base address*/
                DMA_BPTR = DMA_Base_Ptrs[1];
                Cy_PDMA_Disable(DMA_BPTR);

                if(DMA_INVALID_CH != config->uart_dma_config.uart_dma_tx_channel_no )
                {       
                        stcDw1DescrConfig.destAddr = (uint32_t *)&scb->unTX_FIFO_WR.u32Register;
                        stcDw1DescrConfig.xCount = config->uart_dma_config.tx_data_len_bytes;
                        stcDw1DescrConfig.srcAddr = config->uart_dma_config.tx_data_buffer;
                        DW1_Software_Trigger_CH_IDX = (config->uart_dma_config.uart_dma_tx_channel_no);

                        Cy_PDMA_Descr_Init(&stcDescr, &stcDw1DescrConfig);
                        Cy_PDMA_Chnl_Init(DMA_BPTR, (config->uart_dma_config.uart_dma_tx_channel_no), (const cy_stc_pdma_chnl_config_t*) &chnl7Config);
                        Cy_PDMA_Chnl_SetInterruptMask(DMA_BPTR, (config->uart_dma_config.uart_dma_tx_channel_no));
                        Cy_PDMA_Enable(DMA_BPTR);

                        /*Interrupt configurations for the DMA in UART Transfer*/
                        cy_stc_sysint_irq_t stc_sysint_irq_cfg;
                        /* Int1 -> DW1-ch.7 */
                        stc_sysint_irq_cfg.sysIntSrc = (cpuss_interrupts_dw1_0_IRQn + (config->uart_dma_config.uart_dma_tx_channel_no));// cpuss_interrupts_dw1_7_IRQn;
                        stc_sysint_irq_cfg.intIdx    = CPUIntIdx2_IRQn;
                        stc_sysint_irq_cfg.isEnabled = true;
                        
                        Cy_SysInt_InitIRQ(&stc_sysint_irq_cfg);
                        Cy_SysInt_SetSystemIrqVector(stc_sysint_irq_cfg.sysIntSrc, DW1_IntHandler);
                        NVIC_SetPriority(stc_sysint_irq_cfg.intIdx, 3ul);

                        /* Enable Interrrupt */
                        NVIC_EnableIRQ(CPUIntIdx2_IRQn);

                        /*UART based configuration*/
                       g_stc_uart_config.txFifoTriggerLevel = config->uart_dma_config.tx_data_len_bytes;

                        uart_transfer_mode[config->uart_no].uart_tx_mode = ASDK_UART_USING_DMA;
                }
                else
                {
                        uart_transfer_mode[config->uart_no].uart_tx_mode = ASDK_UART_USING_INTERRUPTS;
			// uart_tx_edma_handle_ptr = NULL;


                }

                if(DMA_INVALID_CH != config->uart_dma_config.uart_dma_rx_channel_no )
                {
                        rx_stcDw1DescrConfig.srcAddr = (uint32_t *)&scb->unRX_FIFO_RD.u32Register;
                        rx_stcDw1DescrConfig.descrNext = &rx_stcDescr;
                        rx_stcDw1DescrConfig.srcXincr = 0;
                        rx_stcDw1DescrConfig.destXincr = 1;
                        rx_stcDw1DescrConfig.destAddr = config->uart_dma_config.rx_data_buffer;
                        rx_stcDw1DescrConfig.xCount = config->uart_dma_config.rx_data_len_bytes;

                        temp_var = (config->uart_dma_config.uart_dma_rx_channel_no);
                        Cy_PDMA_Descr_Init(&rx_stcDescr, &rx_stcDw1DescrConfig);
                        Cy_PDMA_Chnl_Init(DMA_BPTR, (config->uart_dma_config.uart_dma_rx_channel_no), (const cy_stc_pdma_chnl_config_t*) &rx_chnl10Config);
                        Cy_PDMA_Chnl_SetInterruptMask(DMA_BPTR, (config->uart_dma_config.uart_dma_rx_channel_no));
                        Cy_PDMA_Enable(DMA_BPTR);

                        /*Interrupt configurations for the DMA in UART Transfer*/
                        cy_stc_sysint_irq_t stc_sysint_irq_cfg;
                        /* Int1 -> DW1-ch.7 */
                        stc_sysint_irq_cfg.sysIntSrc = (cpuss_interrupts_dw1_0_IRQn + (config->uart_dma_config.uart_dma_rx_channel_no));// cpuss_interrupts_dw1_7_IRQn;
                        stc_sysint_irq_cfg.intIdx    = CPUIntIdx2_IRQn;
                        stc_sysint_irq_cfg.isEnabled = true;
                        
                        Cy_SysInt_InitIRQ(&stc_sysint_irq_cfg);
                        Cy_SysInt_SetSystemIrqVector( stc_sysint_irq_cfg.sysIntSrc, DW1_CH15_TransferComplete_IntrISR);
                        NVIC_SetPriority(stc_sysint_irq_cfg.intIdx, 3ul);

                        /* Enable Interrrupt */
                        NVIC_EnableIRQ(CPUIntIdx2_IRQn);

                        /*UART based configuration*/
                        g_stc_uart_config.rxFifoTriggerLevel = config->uart_dma_config.rx_data_len_bytes;
                        uart_transfer_mode[config->uart_no].uart_rx_mode = ASDK_UART_USING_DMA;
                }
                else
                {
                        uart_transfer_mode[config->uart_no].uart_tx_mode = ASDK_UART_USING_INTERRUPTS;
			// uart_tx_edma_handle_ptr = NULL;


                }

                /*store dma ch no. */
		uart_transfer_mode[config->uart_no].uart_tx_dma_ch = config->uart_dma_config.uart_dma_tx_channel_no;
		uart_transfer_mode[config->uart_no].uart_rx_dma_ch = config->uart_dma_config.uart_dma_rx_channel_no;



        }
        else if(ASDK_UART_USING_INTERRUPTS == config->transfer_type)
        {       		/* set for interrupt flag */
		uart_transfer_mode[config->uart_no].uart_rx_mode = ASDK_UART_USING_INTERRUPTS;
		uart_transfer_mode[config->uart_no].uart_tx_mode = ASDK_UART_USING_INTERRUPTS;
		uart_transfer_mode[config->uart_no].uart_tx_dma_ch = DMA_INVALID_CH;
		uart_transfer_mode[config->uart_no].uart_rx_dma_ch = DMA_INVALID_CH;

                SCB_Set_DAL_Callback(scb_index, UART_User_callbacks[config->uart_no]);
        }
	/* Initialize SCB_UART instance */
	/*SCB_Port_For_Uart needs to be defined properly as to which one will work for UART, SPI and I2C*/
	error_code = Cy_SCB_UART_Init(scb, &g_stc_uart_config, &g_stc_uart_context[config->uart_no]); 
        Cy_SCB_UART_Enable(scb);

        
	if (error_code)
          error_code = ASDK_UART_INIT_FAIL;

    return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_init */

/*----------------------------------------------------------------------------*/
/* Function : uart_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Shuts down the uart by disabling interrupts and transmitter/receiver

  @param lpuart_type *base

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 3
                    ASDK_UART_STATUS_SUCCESS if successful uart deinit;
                    ASDK_UART_DEINIT_FAIL if an error occurred

*/
asdk_status_t uart_deinit ( uint8_t uart_no )
{

	/* Local Variables */
	asdk_uart_ec_t error_code = ASDK_UART_STATUS_SUCCESS;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;

	/* check for max uart module */
	if(MAX_UART_MOD <= uart_no)
	{
		error_code = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */
        
        
        scb_index = scb_uart[uart_no];
        scb = scb_base_ptrs[scb_index];
	/* Algorithm */
        
	//error_code = 
        Cy_SCB_UART_DeInit( scb);
        
        //Clear the callback fucntionm
        SCB_Clear_DAL_Callback(scb_index);

        	/* disable DMA channel for uart */
	if ( uart_transfer_mode[uart_no].uart_tx_mode == ASDK_UART_USING_DMA )
        {
		Cy_PDMA_Chnl_Disable(DW1, uart_transfer_mode[uart_no].uart_tx_dma_ch);
        }

	if ( uart_transfer_mode[uart_no].uart_rx_mode == ASDK_UART_USING_DMA )
        {
		Cy_PDMA_Chnl_Disable(DW1, uart_transfer_mode[uart_no].uart_rx_dma_ch);
        }


	uart_transfer_mode[uart_no].uart_rx_mode = ASDK_UART_USING_INTERRUPTS;
	uart_transfer_mode[uart_no].uart_tx_mode = ASDK_UART_USING_INTERRUPTS;


	if (error_code)
		error_code = ASDK_UART_DEINIT_FAIL;

	/* return status */
	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);


}/* uart_deinit */

/*----------------------------------------------------------------------------*/
/* Function : uart_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
   This function Installs callback function for the UART module

  @param uint8_t uart_no

  @param asdk_uart_callback_fun_t *callback_fun

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 3
                    ASDK_UART_STATUS_SUCCESS if successful callback installation;

*/

asdk_status_t uart_install_callback ( uint8_t uart_no, asdk_uart_callback_fun_t callback_fun  )
{

	/* Local Variables */
	asdk_uart_ec_t error_code;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;


	/* check for max uart module */
	if(MAX_UART_MOD <= uart_no )
	{
		error_code = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */
        
        scb_index = scb_uart[uart_no];
        scb = scb_base_ptrs[scb_index];
	
		/* Algorithm */
	switch(uart_no)
	{
            case 0:
                    Cy_SCB_UART_RegisterCallback(scb, (scb_uart_handle_events_t)scb0_uart_callback_handler, &g_stc_uart_context[uart_no]);
            break;
            case 1:
                    Cy_SCB_UART_RegisterCallback(scb, (scb_uart_handle_events_t)scb1_uart_callback_handler, &g_stc_uart_context[uart_no]);
            break;
            default:
            break;
	}
	/* store function into array of function pointer */
	user_callback_fun_list[uart_no] = callback_fun;

	error_code = ASDK_UART_STATUS_SUCCESS;
	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_install_callback */



/*----------------------------------------------------------------------------*/
/* Function : uart_send_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the UART module using a blocking method

  @param uint8_t uart_no

  @param const uint8_t * txBuff

  @param uint32_t txSize

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 3
                    ASDK_UART_STATUS_SUCCESS on successful transmission
                    ASDK_UART_STATUS_ERROR if an error occurred

*/
asdk_status_t  uart_send_blocking ( uint8_t uart_no, uint8_t * txBuff,  uint32_t txSize )
{

	void* tx_buff = (void*) txBuff;

	/* Local Variables */
	asdk_uart_ec_t error_code;

	/* check for max uart module */
	if(MAX_UART_MOD <= uart_no )
	{
		error_code = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */

	/* Algorithm */
	/* Places an array of data in the UART TX FIFO.
	* This function blocks until the number of data elements specified by the size
	* is placed in the TX FIFO.*/
	//Cy_SCB_UART_PutArrayBlocking(SCB_Port_For_Uart[uart_no], tx_buff, txSize);

	//error_code = Cy_SCB_UART_GetTransmitStatus(SCB_Port_For_Uart[uart_no], &g_stc_uart_context[uart_no]);
        
        error_code = ASDK_UART_NOT_IMPLEMENTED;

	if ( error_code != ASDK_UART_STATUS_SUCCESS)
	{
		error_code = ASDK_UART_STATUS_ERROR;
	}

	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_send_blocking */

/*----------------------------------------------------------------------------*/
/* Function : uart_receive_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data through the UART module using a blocking method

  @param uint8_t uart_no

  @param uint8_t * rxBuff

  @param uint32_t rxSize

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 3
                    ASDK_UART_STATUS_SUCCESS on successful transmission
                    ASDK_UART_STATUS_ERROR if an error occurred

*/
asdk_status_t  uart_receive_blocking ( uint8_t uart_no, uint8_t * rxBuff, uint32_t rxSize )
{

	/* Declare a buffer used to store the received data */
	uint32_t bytesRemaining;


	/* Local Variables */
	asdk_uart_ec_t error_code;

	/* check for max uart module */
	if(MAX_UART_MOD <= uart_no )
	{
		error_code = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */

	/* Algorithm */
    	//Cy_SCB_UART_GetArrayBlocking(SCB_Port_For_Uart[uart_no], rxBuff, rxSize);

    	//error_code = Cy_SCB_UART_GetReceiveStatus(SCB_Port_For_Uart[uart_no], &g_stc_uart_context[uart_no]) ;
        error_code = ASDK_UART_NOT_IMPLEMENTED;
	if(error_code != ASDK_UART_STATUS_SUCCESS)
	{
		error_code = ASDK_UART_STATUS_ERROR;
	}

	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_receive_blocking */

/*----------------------------------------------------------------------------*/
/* Function : uart_set_ring_buffer */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function sets ring buffer for uart module

  @param uint8_t uart_no

  @param  uint8_t * ring_buf_base

  @param uint32_t ring_buf_size

  @return asdk_status_t ASDK_UART_STATUS_ERROR feature not implemented

*/
asdk_status_t  uart_set_ring_buffer ( uint8_t uart_no, uint8_t *ring_buf_base, uint32_t ring_buf_size )
{
	/* Local Variables */
	asdk_uart_ec_t error_code = ASDK_UART_STATUS_ERROR;

	(void)uart_no;
	(void)ring_buf_base;
	(void)ring_buf_size;

	/* feature not implemented for cyt2b7 */

	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_set_ring_buffer */

/*----------------------------------------------------------------------------*/
/* Function : uart_send_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function Sends data out through the UART module using a non-blocking method

  @param uint8_t uart_no

  @param const uint8_t * txBuff

  @param uint32_t txSize

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 3
                    ASDK_UART_STATUS_SUCCESS on successful transmission
                    ASDK_UART_SEND_FAIL if an error occurred

*/


asdk_status_t  uart_send_non_blocking ( uint8_t uart_no, uint8_t * txBuff,  uint32_t txSize )
{

	/* Local Variables */
	asdk_uart_ec_t error_code;
	void* tx_buff = (void*)txBuff;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;
        uint32_t            i;
        uint8_t             *p_src;

	/* check for max uart module */
	if(MAX_UART_MOD <= uart_no )
	{
		error_code = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */

	// uart_transfer_mode[uart_no].is_tx_busy = true ;
        scb_index = scb_uart[uart_no];
        scb = scb_base_ptrs[scb_index];
        // DW1_Software_Trigger_CH_IDX = 
        if(0u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN0;
        }
        else if(1u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN1; 
        }
        else if(2u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN2; 
        }
        else if(3u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN3; 
        }
        else if(4u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN4; 
        }
        else if(5u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN5; 
        }
        else if(6u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN6; 
        }
        else if(7u == DW1_Software_Trigger_CH_IDX)
        {
               trig_output_en =  TRIG_OUT_MUX_1_PDMA1_TR_IN7; 
        }

        // trig_output_en = 
        if(uart_transfer_mode[uart_no].uart_tx_mode == ASDK_UART_USING_DMA)
        {           /* for test */
                // p_src = &stcDw1DescrConfig.srcAddr[0];
                // for (i=0; i < 20; i++) {
                //         // *p_src++ = txBuff[i];//0x30 + i;
                //         // (uint8_t*)(&stcDw1DescrConfig.srcAddr[i]) = txBuff[i];
                //         // memcpy(stcDw1DescrConfig.srcAddr,(void *) txBuff, 20);


                // }

                // stcDw1DescrConfig.srcAddr = (void*)txBuff;

                error_code = Cy_TrigMux_SwTrigger( trig_output_en, TRIGGER_TYPE_CPUSS_DW1_TR_IN__EDGE, 1u);
        }
        else
        {
	/* Algorithm */
	        error_code = Cy_SCB_UART_Transmit(scb, tx_buff, txSize, &g_stc_uart_context[uart_no]);
        }

	if (error_code)
		error_code = ASDK_UART_SEND_FAIL;

	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_send_non_blocking */

/*----------------------------------------------------------------------------*/
/* Function : uart_receive_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data through the UART module using a non-blocking method

  @param uint8_t uart_no

  @param uint8_t * rxBuff

  @param uint32_t rxSize

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 3
                    ASDK_UART_STATUS_SUCCESS on successful transmission
                    ASDK_UART_RECEIVE_FAIL if an error occurred

*/
asdk_status_t  uart_receive_non_blocking ( uint8_t uart_no, uint8_t * rxBuff, uint32_t rxSize )
{

	/* Local Variables */
	asdk_uart_ec_t error_code;
        volatile stc_SCB_t *scb = NULL; 
        uint8_t scb_index;


	/* check for max uart module */
	if(MAX_UART_MOD <= uart_no )
	{
		error_code = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */

        scb_index = scb_uart[uart_no];
        scb = scb_base_ptrs[scb_index];

          /* Algorithm */
	

	//UART_RECEIVE_SIZE
        if(uart_transfer_mode[uart_no].uart_tx_mode == ASDK_UART_USING_DMA)
        {

                /***************/
                /* Trigger MUX */
                /***************/
                if(0 == uart_no)
                {       //Find the corresponding channel from the TRIG OUT MUX 1TO1 TRIG_OUT_1TO1_8_SCB_RX_TO_PDMA10->9//
                        //TRIG_OUT_1TO1_8_SCB_RX_TO_PDMA11->11
                        Cy_TrigMux_Connect1To1( TRIG_OUT_1TO1_8_SCB_RX_TO_PDMA10/*TRIG_OUT_1TO1_8_SCB_RX_TO_PDMA13*/, 0u, TRIGGER_TYPE_CPUSS_DW1_TR_IN__EDGE, 0u);
                }
                else if(1u == uart_no)
                {
                        Cy_TrigMux_Connect1To1( TRIG_OUT_1TO1_8_SCB_RX_TO_PDMA11/*TRIG_OUT_1TO1_8_SCB_RX_TO_PDMA13*/, 0u, TRIGGER_TYPE_CPUSS_DW1_TR_IN__EDGE, 0u);
                }
                else
                {
                        error_code = ASDK_UART_INVALID_UART_NO;
                }



        }
        else
        {
	        /* Algorithm */
	        error_code = Cy_SCB_UART_Receive(scb, rxBuff, rxSize, &g_stc_uart_context[uart_no] );
        }

	if (error_code)
		error_code = ASDK_UART_RECEIVE_FAIL;

	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_receive_blocking */

/*----------------------------------------------------------------------------*/
/* Function : uart_is_tx_busy */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function returns uart tx busy status.

  @param uint8_t uart_no

  @return asdk_status_t  ASDK_UART_RANGE_EXCEEDED if uart range is more than 2
                         ASDK_UART_STATUS_SUCCESS if success;

*/
asdk_status_t uart_is_tx_busy ( uint8_t uart_no , bool* tx_busy_status )
{

	/* Local Variables */
	asdk_uart_ec_t error_code = ASDK_UART_STATUS_SUCCESS;
        volatile stc_SCB_t *scb = NULL; 
        uint8_t scb_index;

	/* check for max uart module */
	if(MAX_UART_MOD <= uart_no  )
	{
		error_code = ASDK_UART_RANGE_EXCEEDED;
		return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);
	} /* if(uart_no >= MAX_UART_MOD) */
        scb_index = scb_uart[uart_no];
        scb = scb_base_ptrs[scb_index];
                        //   (g_stc_uart_context[uart_no].txStatus) & 0x01;
	*tx_busy_status = (Cy_SCB_UART_GetTransmitStatus(scb,  &g_stc_uart_context[uart_no])) & (0x01);

	return ASDK_UART_RETURN(ASDK_LC_HARDWARE, error_code);

}/* uart_is_tx_busy */



/*----------------------------------------------------------------------------*/
/* Function : uart_callback_handler */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data through the UART module using a blocking method

  @param void *driverState

  @param uart_event_t event

  @param void *userData

  @return void - NIL

*/

void scb0_uart_callback_handler(uint32_t event)
{
	uint8_t uart_no = 0;
	uint32_t size = 0;
	uint8_t *buff_base = ASDK_NULL;
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;
  
        
        scb_index = scb_uart[0];
        scb = scb_base_ptrs[scb_index];
        
	asdk_uart_transfer_t uart_evnt = ASDK_UART_ERROR;
 	switch(event)
	    {
		case CY_SCB_UART_TRANSMIT_DONE_EVENT:
                    uart_evnt = ASDK_UART_TRANSMIT;
                    buff_base = g_stc_uart_context[uart_no].txBuf;
                    Cy_SCB_ClearTxInterrupt(scb, Cy_SCB_GetTxInterruptMask(scb));
                    //size = g_stc_uart_context[uart_no].txBufIdx;
		    /* Re-Enable Transmit Interrupt */
                    size = Cy_SCB_UART_GetNumInTxFifo(scb);
		    // Cy_SCB_SetTxInterruptMask(CY_USB_SCB_TYPE, g_stc_uart_config.rxFifoIntEnableMask);
		    break;

		case CY_SCB_UART_RECEIVE_DONE_EVENT:
		    /* Re-Enable Rx Interrupt */
                    uart_evnt = ASDK_UART_RECEIVE;
                    buff_base = g_stc_uart_context[uart_no].rxBuf;
                    size = g_stc_uart_context[uart_no].rxBufIdx;
                    Cy_SCB_ClearRxInterrupt(scb, Cy_SCB_GetRxInterruptMask(scb));
		    Cy_SCB_SetRxInterruptMask(scb, g_stc_uart_config.rxFifoIntEnableMask);
		    break;

		case CY_SCB_UART_RB_FULL_EVENT:
                    uart_evnt = ASDK_UART_OVERRUN;
		    break;

		case CY_SCB_UART_RECEIVE_ERR_EVENT:
		case CY_SCB_UART_TRANSMIT_ERR_EVENT:
                    uart_evnt = ASDK_UART_ERROR;
		    break;

		default:
                  //For unhandled events
                  uart_evnt = 0xFF;
		    break;
	    }
        
           if ( (uart_evnt != 0xFF) && (user_callback_fun_list[uart_no] != NULL) )
	    {
		    user_callback_fun_list[uart_no](uart_no, buff_base, size, uart_evnt);
	    }


}

void scb1_uart_callback_handler(uint32_t event)
{
	uint8_t uart_no = 1;
	uint8_t data;
	uint32_t size = 0;
	uint8_t *buff_base = ASDK_NULL;
        
        volatile stc_SCB_t *scb = NULL;
        uint8_t scb_index;
  
        
        scb_index = scb_uart[1];
        scb = scb_base_ptrs[scb_index];

	asdk_uart_transfer_t uart_evnt = ASDK_UART_ERROR;
 	switch(event)
	    {

		case CY_SCB_UART_TRANSMIT_DONE_EVENT:
                  uart_evnt = ASDK_UART_TRANSMIT;
                  buff_base = g_stc_uart_context[uart_no].txBuf;
                  Cy_SCB_ClearTxInterrupt(scb, Cy_SCB_GetTxInterruptMask(scb));
                    //size = g_stc_uart_context[uart_no].txBufIdx;
		    /* Re-Enable Transmit Interrupt */
                  size = Cy_SCB_UART_GetNumInTxFifo(scb);
		    /* Re-Enable Transmit Interrupt */
		    //Cy_SCB_SetTxInterruptMask(CY_USB_SCB_TYPE, g_stc_uart_config.rxFifoIntEnableMask);
		    break;

		case CY_SCB_UART_RECEIVE_DONE_EVENT:
                    uart_evnt = ASDK_UART_RECEIVE;
                    buff_base = g_stc_uart_context[uart_no].rxBuf;
                    size = g_stc_uart_context[uart_no].rxBufIdx;
                    Cy_SCB_ClearRxInterrupt(scb, Cy_SCB_GetRxInterruptMask(scb));
		    /* Re-Enable Rx Interrupt */
		    Cy_SCB_SetRxInterruptMask(scb, g_stc_uart_config.rxFifoIntEnableMask);
		    break;

		case CY_SCB_UART_RB_FULL_EVENT:
                    uart_evnt = ASDK_UART_OVERRUN;
		    break;

                case CY_SCB_UART_RECEIVE_ERR_EVENT:
                case CY_SCB_UART_TRANSMIT_ERR_EVENT:
                     uart_evnt = ASDK_UART_ERROR;
		    break;

		default:
                    uart_evnt = 0xFF;
		    break;
	    }

            if ( (uart_evnt != 0xFF) && (user_callback_fun_list[uart_no] != NULL) )
	    {
		    user_callback_fun_list[uart_no](uart_no, buff_base, size, uart_evnt);
	    }


}

//Functions exclusively to be defined for Infineon cyt2b7 which weren't required for NXP
/*----------------------------------------------------------------------------*/
/* Function : Scb_UART_IntrISR */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function is called whenever UART interrupt occurs

  @param none
  @return none
*/

void UART0_ISR_UserCallback(void)
{

	/* UART interrupt handler */
	/*This is the call to the Interrupt of the UART where in the respective Interrupt event is assigned*/
        Cy_SCB_UART_Interrupt(scb_base_ptrs[scb_uart[0]], &g_stc_uart_context[0]);
}

void UART1_ISR_UserCallback(void)
{

	/* UART interrupt handler */
	/*This is the call to the Interrupt of the UART where in the respective Interrupt event is assigned*/
        Cy_SCB_UART_Interrupt(scb_base_ptrs[scb_uart[1]], &g_stc_uart_context[1]);
}

/* [] END OF FILE */
void DW1_IntHandler(void)
{
    uint32_t    masked;
    uint8_t DW_Channel_no = 0;
    DW_Channel_no = Cy_PDMA_GetActiveChnl(DW1);
    masked = Cy_PDMA_Chnl_GetInterruptStatusMasked(DW1, DW_Channel_no);
    
    if ((masked & CY_PDMA_INTRCAUSE_COMPLETION) != 0u)
    {
        /* Complete DMA */
        Cy_PDMA_Chnl_ClearInterrupt(DW1, DW_Channel_no);

        // /* for test */

        // /* Swtich destination address */
        // if (au8DestActSby == 0u) { 
        //     Cy_PDMA_Descr_SetDestAddr(&stcDescr, (void *)au8DestBuffer1);
        // }
        // else {
        //     Cy_PDMA_Descr_SetDestAddr(&stcDescr, (void *)au8DestBuffer0);
        // }
        // au8DestActSby ^= 1u;

        // Needs to be checked
        // Cy_SysTick_DelayInUs(50000);

        /* Set trigger again */

        /* note:                                                                           */
        /*   if descriptor changed, the channel needs to be changed from DISABLE to ENABLE */
        Cy_PDMA_Chnl_Enable(DW1, DW_Channel_no);
        // Cy_TrigMux_SwTrigger( TRIG_OUT_MUX_1_PDMA1_TR_IN7,
        //                       TRIGGER_TYPE_CPUSS_DW1_TR_IN__EDGE,
        //                       1u);
    }
}


void DW1_CH15_TransferComplete_IntrISR(void)
{
    /* Dump DW Dest Buffer for test */
        uint32_t    masked;
        uint8_t DW_Channel_no = 0;
        DW_Channel_no = Cy_PDMA_GetActiveChnl(DW1);
        masked = Cy_PDMA_Chnl_GetInterruptStatusMasked(DW1, DW_Channel_no);
        if ((masked & CY_PDMA_INTRCAUSE_COMPLETION) != 0u)
        {
           Cy_PDMA_Chnl_ClearInterrupt( DW1, DW_Channel_no);
        }
        Cy_PDMA_Chnl_Enable(DW1, 0);
        Cy_TrigMux_SwTrigger( TRIG_OUT_MUX_1_PDMA1_TR_IN0,
                        TRIGGER_TYPE_CPUSS_DW1_TR_IN__EDGE,
                        1u);
}
