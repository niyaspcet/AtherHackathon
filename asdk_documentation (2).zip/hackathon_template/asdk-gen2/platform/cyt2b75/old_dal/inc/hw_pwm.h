/*
  @file
  hw_timer.h

  @path
  hw_timer.h

  @Created on
  Jul 01, 2020

  @Author
  anshuman.tripathi

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
  This function prototypes the s32k144 timer module hardware dependent component.


*/

#ifndef HW_PWM_H_
#define HW_PWM_H_

#ifdef __cplusplus
extern "C"
{
#endif
/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include "pwm.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define ASDK_PWM_RETURN(lc, ec) ASDK_STATUS(lc, ASDK_MC_PWM, ec)

/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/

/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/

asdk_status_t pwm_init(asdk_pwm_config_t *pwm_config);
asdk_status_t pwm_deinit(uint8_t pwm_module, uint8_t pwm_sub_module);
asdk_status_t pwm_start_timer(uint8_t pwm_module, uint8_t pwm_sub_module);
asdk_status_t pwm_stop_timer(uint8_t pwm_module, uint8_t pwm_sub_module);

asdk_status_t pwm_start_combined(uint8_t *pwm_sub_mod_array, uint8_t pwm_sub_mod_array_size);
asdk_status_t pwm_stop_combined(uint8_t *pwm_sub_mod_array, uint8_t pwm_sub_mod_array_size);

asdk_status_t pwm_update_duty_cycle(uint8_t pwm_module, uint8_t pwm_sub_module,
                                    asdk_pwm_channel_config_t *pwm_channel_params);
asdk_status_t pwm_enable_interrupt(uint8_t pwm_module, uint16_t pwm_sub_module, uint32_t mask);
asdk_status_t pwm_disable_interrupt(uint8_t pwm_module, uint16_t pwm_sub_module, uint32_t mask);
asdk_status_t pwm_install_callback(uint8_t pwm_module, uint8_t pwm_sub_module, 
                                   asdk_pwm_callback_fun_t pwm_callback_func);

/* Advance APIs */
asdk_status_t pwm_output_trigger_enable(uint8_t pwm_module, uint8_t pwm_sub_module,
                                        asdk_pwm_val_register_t val_register, bool enable);
asdk_status_t pwm_on_off(uint8_t pwm_module, uint8_t pwm_sub_module, bool operation);
asdk_status_t pwm_update_deadtime(uint8_t pwm_module, uint8_t pwm_sub_module, uint16_t dead_time_ns);
asdk_status_t pwm_getvalueregister(uint8_t pwm_module, uint8_t pwm_sub_module,
                                   asdk_pwm_val_register_t valueregister, uint16_t *result);
asdk_status_t pwm_updatevalueregister(uint8_t pwm_module, uint8_t pwm_sub_module,
                                      asdk_pwm_val_register_t valueregister, uint16_t value);
asdk_status_t pwm_set_loadOk(uint8_t *pwm_sub_mod_array, uint8_t pwm_sub_mod_array_size);

#ifdef __cplusplus
} // extern "C"
#endif
#endif /* HW_PWM_H_ */