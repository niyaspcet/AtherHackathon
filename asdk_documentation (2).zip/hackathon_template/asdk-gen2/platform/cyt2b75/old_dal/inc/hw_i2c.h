/*
  @file
  hw_i2c.h

  @path
  /frdmkw36_demo_apps_power_manager/source/hw_i2c.h

  @Created on
  Jan 18, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef ASDK_CYT2B7_ASDK_DRIVERS_HW_I2C_H_
#define ASDK_CYT2B7_ASDK_DRIVERS_HW_I2C_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "i2c.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/


/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t i2c_master_init ( asdk_i2c_master_config_t *i2c_config_data );
asdk_status_t i2c_master_deinit ( uint8_t i2c_no );
asdk_status_t i2c_master_write_blocking ( uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_send );
asdk_status_t i2c_master_read_blocking ( uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_rcv );
asdk_status_t i2c_master_write_non_blocking ( uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_send );
asdk_status_t i2c_master_read_non_blocking ( uint8_t i2c_no, asdk_i2c_data_transfer_t *i2c_data_rcv );
asdk_status_t i2c_master_install_callback ( uint8_t i2c_no, asdk_i2c_callback_fun_t callback_fun  );

asdk_status_t i2c_slave_init ( asdk_i2c_slave_config_t *i2c_config_data );
asdk_status_t i2c_slave_deinit ( uint8_t i2c_no );
asdk_status_t i2c_slave_transfer_non_blocking ( uint8_t i2c_no);
asdk_status_t i2c_slave_install_callback ( uint8_t i2c_no, asdk_i2c_callback_fun_t callback_fun  );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* ASDK_CYT2B7_ASDK_DRIVERS_HW_I2C_H_ */
