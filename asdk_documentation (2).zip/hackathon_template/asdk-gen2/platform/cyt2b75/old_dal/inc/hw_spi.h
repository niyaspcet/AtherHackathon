/*
  @file
  hw_spi.h

  @path
  /asdk/inc/hw_spi.h

  @Created on
  Apr 04, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef SOURCES_HW_SPI_H_
#define SOURCES_HW_SPI_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "spi.h"
/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define MAX_SPI_MOD   2
#define MAX_SLAVE_SELECTS 4
#define SPI_TRANSFER_PIN  2
#define SCB_SPI_OVERSAMPLING 16u
/*----------------------------------------------------------------------------*/

/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t spi_master_init ( asdk_spi_master_config_t *spi_config_data );
asdk_status_t spi_master_deinit ( uint8_t spi_no );
asdk_status_t spi_master_transfer_blocking ( uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length );
asdk_status_t spi_master_transfer_non_blocking ( uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length );
asdk_status_t spi_master_transfer_status( uint8_t spi_no );
asdk_status_t spi_master_install_callback ( uint8_t spi_no, asdk_spi_callback_fun_t callback_fun);

asdk_status_t spi_slave_init ( asdk_spi_slave_config_t *spi_config_data );
asdk_status_t spi_slave_deinit ( uint8_t spi_no );
asdk_status_t spi_slave_transfer_blocking ( uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length );
asdk_status_t spi_slave_transfer_non_blocking ( uint8_t spi_no, uint8_t *send_buf, uint8_t *recv_buf, uint16_t length );
asdk_status_t spi_slave_install_callback ( uint8_t spi_no, asdk_spi_callback_fun_t callback_fun );


#ifdef __cplusplus
} // extern "C"
#endif

#endif /* SOURCES_HW_SPI_H_ */
