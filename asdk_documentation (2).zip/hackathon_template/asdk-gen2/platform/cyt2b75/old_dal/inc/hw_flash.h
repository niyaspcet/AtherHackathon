/*
  @file
  hw_flash.h

  @path
  /platform/platform/cyt2b7/dal/inc/hw_flash.h

  @Created on
  Feb 27, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef PLATFORM_CYT2B7_DAL_INC_HW_FLASH_H_
#define PLATFORM_CYT2B7_DAL_INC_HW_FLASH_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include "flash.h"


/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/


/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t flash_init ( void );
asdk_status_t flash_deinit ( void );
asdk_status_t flash_install_callback ( asdk_flash_callback_fun_t callback_fun );
asdk_status_t flash_read ( uint32_t dest, uint32_t size, uint8_t *data );
asdk_status_t flash_write ( uint32_t dest, uint32_t size, uint8_t *data );
asdk_status_t flash_erase_all_block ( void );
asdk_status_t flash_erase_sector ( uint32_t dest, uint32_t size );
asdk_status_t flash_get_sector_size ( uint32_t* size );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* PLATFORM_S32K144_DAL_INC_HW_FLASH_H_ */
