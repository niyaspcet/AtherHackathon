/*
  @file
  hw_uart.h

  @path
  /platform/asdk/CYT2B7/drivers/hw_uart.h

  @Created on
  Jan 23, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef ASDK_CYT2B7_ASDK_DRIVERS_HW_UART_H_
#define ASDK_CYT2B7_ASDK_DRIVERS_HW_UART_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "uart.h"
/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define MAX_UART_MOD     2U

/* Select Baud Rate */
#define E_UART_BAUD_115200  115200
#define E_UART_BAUD_57600   57600
#define E_UART_BAUD_38400   38400
#define E_UART_BAUD_19200   19200
#define E_UART_BAUD_9600    9600
#define E_UART_BAUD_2400    2400
#define E_UART_BAUD_1200    1200
#define E_UART_BAUD         E_UART_BAUD_115200

/* Local Definision */
#define E_UART_RECV_THRESHOLD    8
#define E_UART_RING_BUF_SIZE     512
#define E_UART_USER_BUF_SIZE     512
#define E_UART_RX_INTR_FACTER     (                              \
                                 CY_SCB_UART_RX_TRIGGER      |   \
                               /*CY_SCB_UART_RX_NOT_EMPTY    | */\
                               /*CY_SCB_UART_RX_FULL         | */\
                                 CY_SCB_UART_RX_OVERFLOW     |   \
                                 CY_SCB_UART_RX_UNDERFLOW    |   \
                                 CY_SCB_UART_RX_ERR_FRAME    |   \
                                 CY_SCB_UART_RX_ERR_PARITY   |   \
                                 CY_SCB_UART_RX_BREAK_DETECT |   \
                                 0                               \
                                )
#define E_UART_TX_INTR_FACTER     (                              \
                                 CY_SCB_UART_TX_TRIGGER      |   \
                               /*CY_SCB_UART_TX_NOT_FULL     | */\
                               /*CY_SCB_UART_TX_EMPTY        | */\
                                 CY_SCB_UART_TX_OVERFLOW     |   \
                               /*CY_SCB_UART_TX_UNDERFLOW    | */\
                                 CY_SCB_UART_TX_DONE         |   \
                               /*CY_SCB_UART_TX_NACK         | */\
                               /*CY_SCB_UART_TX_ARB_LOST     | */\
                                 0                               \
                                )

/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/
/*!@brief enum to define uart module */


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t uart_init ( asdk_uart_config_t *config );
asdk_status_t uart_deinit ( uint8_t uart_no );
asdk_status_t uart_install_callback ( uint8_t uart_no, asdk_uart_callback_fun_t callback_fun );
asdk_status_t uart_send_blocking ( uint8_t uart_no, uint8_t * txBuff, uint32_t txSize );
asdk_status_t uart_receive_blocking ( uint8_t uart_no, uint8_t * rxBuff, uint32_t rxSize );
asdk_status_t  uart_set_ring_buffer ( uint8_t uart_no, uint8_t *ring_buf_base, uint32_t ring_buf_size );
asdk_status_t uart_send_non_blocking ( uint8_t uart_no, uint8_t * txBuff, uint32_t txSize );
asdk_status_t uart_receive_non_blocking ( uint8_t uart_no, uint8_t * rxBuff, uint32_t rxSize );
asdk_status_t uart_is_tx_busy ( uint8_t uart_no , bool* tx_busy_status );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* ASDK_S32K144_ASDK_DRIVERS_HW_UART_H_ */
