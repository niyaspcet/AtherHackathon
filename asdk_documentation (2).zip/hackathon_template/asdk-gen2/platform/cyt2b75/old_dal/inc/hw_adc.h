/*
  @file
  hw_adc.h

  @path
  hw_adc.h

  @Created on
  Feb 15, 2023

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef SOURCES_HW_ADC_H_
#define SOURCES_HW_ADC_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE  FILES

==============================================================================*/
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "adc.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define DIV_ROUND_UP(a,b) (((a) + (b)/2) / (b))
#define ANALOG_IN_SAMPLING_TIME_MIN_IN_NS 412ull
#define ADC_CH_SAMPLE_TIME                      120u

/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t adc_init ( asdk_adc_config_t* adc_config );
asdk_status_t adc_deinit ( uint8_t adc_no );
asdk_status_t adc_install_callback ( uint8_t adc_no, uint8_t adc_channel_no, asdk_adc_callback_fun_t callback_fun );
asdk_status_t adc_get_blocking_conv_value ( uint8_t adc_no, uint8_t adc_channel_no, uint32_t* adc_channel_value );
asdk_status_t adc_get_non_blocking_conv_value ( uint8_t adc_no, uint8_t adc_channel_no );
asdk_status_t adc_get_batch_non_blocking_conv_value ( asdk_adc_batch_data_t *adc_batch_data, uint8_t batch_size);
asdk_status_t adc_add_sample(asdk_adc_channel_data_t *adc_channel_data, uint8_t sample_no);

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* SOURCES_HW_ADC_H_ */
