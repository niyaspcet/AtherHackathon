/*
  @file
  hw_timer.h

  @path
  hw_timer.h

  @Created on
  March 02, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
  This function prototypes the cyt2b75 timer module hardware dependent component.


*/

#ifndef HW_TIMER_H_
#define HW_TIMER_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include "timer.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/

/* CYT2B75 timers */
#define CYT2B7_TCPWM0_GROUP_0     0
#define CYT2B7_TCPWM0_GROUP_1     1
#define CYT2B7_TCPWM0_GROUP_2     2
#define CYT2B7_TCPWM0_GROUP_MAX   3

#if 0
/* CYT2B75 group-0 timers */
#define CYT2B7_TCPWM0_GRP_0_CH_0       0
#define CYT2B7_TCPWM0_GRP_0_CH_1       1
#define CYT2B7_TCPWM0_GRP_0_CH_2       2
#define CYT2B7_TCPWM0_GRP_0_CH_3       3
#define CYT2B7_TCPWM0_GRP_0_CH_4       4
#define CYT2B7_TCPWM0_GRP_0_CH_5       5
#define CYT2B7_TCPWM0_GRP_0_CH_6       6
#define CYT2B7_TCPWM0_GRP_0_CH_7       7
#define CYT2B7_TCPWM0_GRP_0_CH_8       8
#define CYT2B7_TCPWM0_GRP_0_CH_9       9
#define CYT2B7_TCPWM0_GRP_0_CH_10     10
#define CYT2B7_TCPWM0_GRP_0_CH_11     11
#define CYT2B7_TCPWM0_GRP_0_CH_12     12
#define CYT2B7_TCPWM0_GRP_0_CH_13     13
#define CYT2B7_TCPWM0_GRP_0_CH_14     14
#define CYT2B7_TCPWM0_GRP_0_CH_15     15
#define CYT2B7_TCPWM0_GRP_0_CH_16     16
#define CYT2B7_TCPWM0_GRP_0_CH_17     17
#define CYT2B7_TCPWM0_GRP_0_CH_18     18
#define CYT2B7_TCPWM0_GRP_0_CH_19     19
#define CYT2B7_TCPWM0_GRP_0_CH_20     20
#define CYT2B7_TCPWM0_GRP_0_CH_21     21
#define CYT2B7_TCPWM0_GRP_0_CH_22     22
#define CYT2B7_TCPWM0_GRP_0_CH_23     23
#define CYT2B7_TCPWM0_GRP_0_CH_24     24
#define CYT2B7_TCPWM0_GRP_0_CH_25     25
#define CYT2B7_TCPWM0_GRP_0_CH_26     26
#define CYT2B7_TCPWM0_GRP_0_CH_27     27
#define CYT2B7_TCPWM0_GRP_0_CH_28     28
#define CYT2B7_TCPWM0_GRP_0_CH_29     29
#define CYT2B7_TCPWM0_GRP_0_CH_30     30
#define CYT2B7_TCPWM0_GRP_0_CH_31     31
#define CYT2B7_TCPWM0_GRP_0_CH_32     32
#define CYT2B7_TCPWM0_GRP_0_CH_33     33
#define CYT2B7_TCPWM0_GRP_0_CH_34     34
#define CYT2B7_TCPWM0_GRP_0_CH_35     35
#define CYT2B7_TCPWM0_GRP_0_CH_36     36
#define CYT2B7_TCPWM0_GRP_0_CH_37     37
#define CYT2B7_TCPWM0_GRP_0_CH_38     38
#define CYT2B7_TCPWM0_GRP_0_CH_39     39
#define CYT2B7_TCPWM0_GRP_0_CH_40     40
#define CYT2B7_TCPWM0_GRP_0_CH_41     41
#define CYT2B7_TCPWM0_GRP_0_CH_42     42
#define CYT2B7_TCPWM0_GRP_0_CH_43     43
#define CYT2B7_TCPWM0_GRP_0_CH_44     44
#define CYT2B7_TCPWM0_GRP_0_CH_45     45
#define CYT2B7_TCPWM0_GRP_0_CH_46     46
#define CYT2B7_TCPWM0_GRP_0_CH_47     47
#define CYT2B7_TCPWM0_GRP_0_CH_48     48
#define CYT2B7_TCPWM0_GRP_0_CH_49     49
#define CYT2B7_TCPWM0_GRP_0_CH_50     50
#define CYT2B7_TCPWM0_GRP_0_CH_51     51
#define CYT2B7_TCPWM0_GRP_0_CH_52     52
#define CYT2B7_TCPWM0_GRP_0_CH_53     53
#define CYT2B7_TCPWM0_GRP_0_CH_54     54
#define CYT2B7_TCPWM0_GRP_0_CH_55     55
#define CYT2B7_TCPWM0_GRP_0_CH_56     56
#define CYT2B7_TCPWM0_GRP_0_CH_57     57
#define CYT2B7_TCPWM0_GRP_0_CH_58     58
#define CYT2B7_TCPWM0_GRP_0_CH_59     59
#define CYT2B7_TCPWM0_GRP_0_CH_60     60
#define CYT2B7_TCPWM0_GRP_0_CH_61     61
#define CYT2B7_TCPWM0_GRP_0_CH_62     62
#define CYT2B7_TCPWM0_GRP_0_CH_MAX    63

/* CYT2B75 group-1 timers */
#define CYT2B7_TCPWM0_GRP_1_CH_0       0
#define CYT2B7_TCPWM0_GRP_1_CH_1       1
#define CYT2B7_TCPWM0_GRP_1_CH_2       2
#define CYT2B7_TCPWM0_GRP_1_CH_3       3
#define CYT2B7_TCPWM0_GRP_1_CH_4       4
#define CYT2B7_TCPWM0_GRP_1_CH_5       5
#define CYT2B7_TCPWM0_GRP_1_CH_6       6
#define CYT2B7_TCPWM0_GRP_1_CH_7       7
#define CYT2B7_TCPWM0_GRP_1_CH_8       8
#define CYT2B7_TCPWM0_GRP_1_CH_9       9
#define CYT2B7_TCPWM0_GRP_1_CH_10     10
#define CYT2B7_TCPWM0_GRP_1_CH_11     11
#define CYT2B7_TCPWM0_GRP_1_CH_MAX    12

/* CYT2B75 group-2 timers */
#define CYT2B7_TCPWM0_GRP_2_CH_0       0
#define CYT2B7_TCPWM0_GRP_2_CH_1       1
#define CYT2B7_TCPWM0_GRP_2_CH_2       2
#define CYT2B7_TCPWM0_GRP_2_CH_3       3
#define CYT2B7_TCPWM0_GRP_2_CH_MAX     4
#endif

/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

typedef enum {
  CYT2B7_TCPWM0_GRP_0_CH_0 = 0,
  CYT2B7_TCPWM0_GRP_0_CH_1,   CYT2B7_TCPWM0_GRP_0_CH_2,  CYT2B7_TCPWM0_GRP_0_CH_3,  CYT2B7_TCPWM0_GRP_0_CH_4,
  CYT2B7_TCPWM0_GRP_0_CH_5,   CYT2B7_TCPWM0_GRP_0_CH_6,  CYT2B7_TCPWM0_GRP_0_CH_7,  CYT2B7_TCPWM0_GRP_0_CH_8,
  CYT2B7_TCPWM0_GRP_0_CH_9,  CYT2B7_TCPWM0_GRP_0_CH_10, CYT2B7_TCPWM0_GRP_0_CH_11, CYT2B7_TCPWM0_GRP_0_CH_12,
  CYT2B7_TCPWM0_GRP_0_CH_13, CYT2B7_TCPWM0_GRP_0_CH_14, CYT2B7_TCPWM0_GRP_0_CH_15, CYT2B7_TCPWM0_GRP_0_CH_16,
  CYT2B7_TCPWM0_GRP_0_CH_17, CYT2B7_TCPWM0_GRP_0_CH_18, CYT2B7_TCPWM0_GRP_0_CH_19, CYT2B7_TCPWM0_GRP_0_CH_20,
  CYT2B7_TCPWM0_GRP_0_CH_21, CYT2B7_TCPWM0_GRP_0_CH_22, CYT2B7_TCPWM0_GRP_0_CH_23, CYT2B7_TCPWM0_GRP_0_CH_24,
  CYT2B7_TCPWM0_GRP_0_CH_25, CYT2B7_TCPWM0_GRP_0_CH_26, CYT2B7_TCPWM0_GRP_0_CH_27, CYT2B7_TCPWM0_GRP_0_CH_28,
  CYT2B7_TCPWM0_GRP_0_CH_29, CYT2B7_TCPWM0_GRP_0_CH_30, CYT2B7_TCPWM0_GRP_0_CH_31, CYT2B7_TCPWM0_GRP_0_CH_32,
  CYT2B7_TCPWM0_GRP_0_CH_33, CYT2B7_TCPWM0_GRP_0_CH_34, CYT2B7_TCPWM0_GRP_0_CH_35, CYT2B7_TCPWM0_GRP_0_CH_36,
  CYT2B7_TCPWM0_GRP_0_CH_37, CYT2B7_TCPWM0_GRP_0_CH_38, CYT2B7_TCPWM0_GRP_0_CH_39, CYT2B7_TCPWM0_GRP_0_CH_40,
  CYT2B7_TCPWM0_GRP_0_CH_41, CYT2B7_TCPWM0_GRP_0_CH_42, CYT2B7_TCPWM0_GRP_0_CH_43, CYT2B7_TCPWM0_GRP_0_CH_44,
  CYT2B7_TCPWM0_GRP_0_CH_45, CYT2B7_TCPWM0_GRP_0_CH_46, CYT2B7_TCPWM0_GRP_0_CH_47, CYT2B7_TCPWM0_GRP_0_CH_48,
  CYT2B7_TCPWM0_GRP_0_CH_49, CYT2B7_TCPWM0_GRP_0_CH_50, CYT2B7_TCPWM0_GRP_0_CH_51, CYT2B7_TCPWM0_GRP_0_CH_52,
  CYT2B7_TCPWM0_GRP_0_CH_53, CYT2B7_TCPWM0_GRP_0_CH_54, CYT2B7_TCPWM0_GRP_0_CH_55, CYT2B7_TCPWM0_GRP_0_CH_56,
  CYT2B7_TCPWM0_GRP_0_CH_57, CYT2B7_TCPWM0_GRP_0_CH_58, CYT2B7_TCPWM0_GRP_0_CH_59, CYT2B7_TCPWM0_GRP_0_CH_60,
  CYT2B7_TCPWM0_GRP_0_CH_61, CYT2B7_TCPWM0_GRP_0_CH_62, CYT2B7_TCPWM0_GRP_0_CH_MAX
} cyt2b7_tcpwm0_grp0_ch_t;

/* CYT2B75 group-1 timers */
typedef enum {
  CYT2B7_TCPWM0_GRP_1_CH_0 = 0,
  CYT2B7_TCPWM0_GRP_1_CH_1,   CYT2B7_TCPWM0_GRP_1_CH_2,  CYT2B7_TCPWM0_GRP_1_CH_3,  CYT2B7_TCPWM0_GRP_1_CH_4,
  CYT2B7_TCPWM0_GRP_1_CH_5,   CYT2B7_TCPWM0_GRP_1_CH_6,  CYT2B7_TCPWM0_GRP_1_CH_7,  CYT2B7_TCPWM0_GRP_1_CH_8,
  CYT2B7_TCPWM0_GRP_1_CH_9,  CYT2B7_TCPWM0_GRP_1_CH_10, CYT2B7_TCPWM0_GRP_1_CH_11, CYT2B7_TCPWM0_GRP_1_CH_MAX
} cyt2b7_tcpwm0_grp1_ch_t;

/* CYT2B75 group-2 timers */
typedef enum {
  CYT2B7_TCPWM0_GRP_2_CH_0 = 0,
  CYT2B7_TCPWM0_GRP_2_CH_1, 
  CYT2B7_TCPWM0_GRP_2_CH_2,
  CYT2B7_TCPWM0_GRP_2_CH_3,
  CYT2B7_TCPWM0_GRP_2_CH_MAX
} cyt2b7_tcpwm0_grp2_ch_t;

/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t timer_init( asdk_timer_config_t *timer_config);
asdk_status_t timer_start ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t ch_no );
asdk_status_t timer_stop ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t ch_no);
asdk_status_t timer_deinit(uint8_t timer_no, asdk_timer_type_t timer_type);
asdk_status_t timer_set_timer_period(uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t time_us);
asdk_status_t timer_set_timer_duty(uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t time_us);
asdk_status_t timer_get_current_time_ms ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t *current_time_ms );
asdk_status_t timer_get_current_time_us ( uint8_t timer_no, asdk_timer_type_t timer_type, uint8_t channel, uint64_t *current_time_us  );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* HW_TIMER_H_ */