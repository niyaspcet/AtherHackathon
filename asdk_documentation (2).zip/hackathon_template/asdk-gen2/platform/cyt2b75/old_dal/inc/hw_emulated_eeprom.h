/*
  @file
  hw_emulated_eeprom.h

  @path
  /platform/platform/apis/hw_emulated_eeprom.h

  @Created on
  Dec 16, 2019

  @Author
  anupam.kumar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef PLATFORM_APIS_HW_EMULATED_EEPROM_H_
#define PLATFORM_APIS_HW_EMULATED_EEPROM_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include "emulated_eeprom.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/


/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t emulated_eeprom_init ( asdk_emulated_eeprom_config_t  *emulated_eeprom_config );
asdk_status_t emulated_eeprom_deinit ( void );
asdk_status_t emulated_eeprom_update ( void );
asdk_status_t emulated_eeprom_write ( uint8_t *source, uint8_t *target, uint32_t size );
asdk_status_t emulated_eeprom_read ( uint8_t *source, uint8_t *target, uint32_t size );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* PLATFORM_APIS_HW_EMULATED_EEPROM_H_ */
