/*
  @file
  hw_can.h

  @path
  hw_can.h

  @Created on
  Feb 15, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
  This files prototypes the CAN module implementation of s32k144.


*/

#ifndef HW_CAN_H_
#define HW_CAN_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "can.h"
#include "errordef.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/


/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t can_init ( asdk_can_config_t *can_config_data );
asdk_status_t can_deinit ( uint8_t can_no );
asdk_status_t can_send_blocking ( uint8_t can_no, uint32_t can_id, const uint8_t * txBuff, uint8_t txSize );
asdk_status_t can_send_non_blocking ( uint8_t can_no, uint32_t can_id, const uint8_t * txBuff, uint8_t txSize );
asdk_status_t can_receive_blocking ( uint8_t can_no, uint32_t * can_id, uint8_t rxBuff[], uint32_t *rxSize );
asdk_status_t can_receive_non_blocking ( uint8_t can_no, uint8_t rxSize);
asdk_status_t can_set_transceiver_mode ( uint8_t can_no, asdk_can_transceiver_mode_t mode );
asdk_status_t can_get_transceiver_mode ( uint8_t can_no, asdk_can_transceiver_mode_t * mode );
asdk_status_t can_is_tx_busy(uint8_t can_no, bool* status );
asdk_status_t can_install_callback (uint8_t can_no, asdk_can_callback_fun_t callback_fun );

asdk_status_t can_mailbox_batch_config( uint8_t can_no, asdk_can_message_config_t *config, uint8_t size);
asdk_status_t can_mailbox_config( uint8_t can_no, asdk_can_message_config_t config );
asdk_status_t can_get_mailbox_id( uint8_t can_no, uint32_t can_id, uint8_t * mb_id, bool transfer );
asdk_status_t can_free_mailbox_id( uint8_t can_no, asdk_can_message_config_t config);
asdk_status_t can_send_non_blocking_mailbox ( uint8_t can_no, uint32_t can_id, const uint8_t * txBuff, uint8_t txSize );
asdk_status_t can_receive_non_blocking_mailbox ( uint8_t can_no, uint32_t can_id, uint8_t rxSize );
asdk_status_t can_receive_non_blocking_increased_fifo ( uint8_t can_no, uint8_t rxSize );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* HW_CAN_H_ */
