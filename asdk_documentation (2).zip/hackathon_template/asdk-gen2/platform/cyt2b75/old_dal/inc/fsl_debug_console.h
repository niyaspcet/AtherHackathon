/*
  @file
  fsl_debug_console.h

  @path
  /power_mode_switch_s32k144/Sources/fsl_debug_console.h

  @Created on
  Oct 28, 2019

  @Author
  anupam.kumar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef ASDK_S32K144_ASDK_DRIVERS_FSL_DEBUG_CONSOLE_H_
#define ASDK_S32K144_ASDK_DRIVERS_FSL_DEBUG_CONSOLE_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#define PRINTF //
#define __NOP()  //

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/


/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/


#ifdef __cplusplus
} // extern "C"
#endif

#endif /* ASDK_S32K144_ASDK_DRIVERS_FSL_DEBUG_CONSOLE_H_ */
