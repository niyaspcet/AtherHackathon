/*
  @file
  hw_gpio.h

  @path
  hw_gpio.h

  @Created on
  Jan 18, 2022

  @Author
  gautam.sagar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef SOURCES_CYT2B7_GPIO_H_
#define SOURCES_CYT2B7_GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include <stdio.h>
#include <stdbool.h>
#include "gpio.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/

/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/







/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/
/*! @brief Interrupt handler type */
typedef void (*gpio_irq_handler_t)(void);

/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t gpio_init ( asdk_gpio_config_t *gpio_config );
asdk_status_t gpio_deinit ( asdk_gpio_port_t port, uint8_t pin, bool interrupt_status );
asdk_status_t gpio_pin_set ( asdk_gpio_port_t port, uint8_t pin );
asdk_status_t gpio_pin_clear ( asdk_gpio_port_t port, uint8_t pin );
asdk_status_t gpio_pin_toggle (asdk_gpio_port_t port, uint8_t pin );
asdk_status_t gpio_install_callback ( asdk_gpio_port_t port, uint8_t pin,
asdk_gpio_interrupt_config_t interrupt_config,  asdk_gpio_callback_fun_t callback_fun );
asdk_status_t gpio_clear_interrupt ( asdk_gpio_port_t port, uint8_t pin );
asdk_status_t gpio_get_pins_input (  asdk_gpio_port_t port, uint8_t pin, bool *data  );
asdk_status_t gpio_get_pins_output (  asdk_gpio_port_t port, uint8_t pin, bool *data  );
void fast_fun(asdk_fast_fun_config_t *gpio_fast_fun_config) ;


#ifdef __cplusplus
} // extern "C"
#endif

#endif /* SOURCES_S32K144_GPIO_H_ */


