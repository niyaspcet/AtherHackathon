/*
 *@file
 *hw_xbar.h

 *@path
 *dal/inc/hw_xbar.h

 *@Created on
 *24-03-2020

 *@Author
 *anup.gandra

 *@Copyright
 *Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

 *@brief
 *This file implements the xbar dal layer for MKV46F128 micro-controller.


*/

#ifndef SOURCES_HW_XBAR_H_
#define SOURCES_HW_XBAR_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================
 *						INCLUDE FILES
 *==============================================================================
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "xbar.h"

/*==============================================================================
 *				LOCAL DEFINITIONS AND TYPES : MACROS
 *==============================================================================
 */

/*==============================================================================
 *					DEFINITIONS AND TYPES : MACROS
 *==============================================================================
 */


/*==============================================================================
 *					DEFINITIONS AND TYPES : ENUMS
 *==============================================================================
 */


/*==============================================================================
 *				DEFINITIONS AND TYPES : STRUCTURES
 *==============================================================================
 */


/*==============================================================================
 *					EXTERNAL DECLARATIONS
 *==============================================================================
 */


/*==============================================================================
 *					FUNCTION PROTOTYPES
 *==============================================================================
 */

asdk_status_t xbar_init(uint8_t xbar_no);
asdk_status_t xbar_deinit(uint8_t xbar_no);
asdk_status_t xbar_setsignalconnection(asdk_xbar_user_config_t *dal_xbar_config);


#ifdef __cplusplus
} // extern "C"
#endif

#endif /* SOURCES_HW_XBAR_H_ */
