/*
 *@file
 *hw_pdb.h

 *@path
 *dal/inc/hw_pdb.h

 *@Created on
 *23-03-2020

 *@Author
 *anup.gandra

 *@Copyright
 *Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

 *@brief
 *This file implements the dal layer PDB for MKV46F128 micro-controller.


*/

#ifndef SOURCES_HW_PDB_H_
#define SOURCES_HW_PDB_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================
 *						INCLUDE FILES
 *==============================================================================
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "pdb.h"

/*==============================================================================
 *				LOCAL DEFINITIONS AND TYPES : MACROS
 *==============================================================================
 */


/*==============================================================================
 *					DEFINITIONS AND TYPES : MACROS
 *==============================================================================
 */


/*==============================================================================
 *					DEFINITIONS AND TYPES : ENUMS
 *==============================================================================
 */


/*==============================================================================
 *				DEFINITIONS AND TYPES : STRUCTURES
 *==============================================================================
 */


/*==============================================================================
 *					EXTERNAL DECLARATIONS
 *==============================================================================
 */


/*==============================================================================
 *					FUNCTION PROTOTYPES
 *==============================================================================
 */

asdk_status_t pdb_init(asdk_pdb_user_config_t *dal_pdb_config);
asdk_status_t pdb_deinit(uint8_t pdb_no);
asdk_status_t pdb_install_callback(uint8_t pdb_no, asdk_pdb_callback_fun_t callback_fun);
asdk_status_t pdb_config_delay(uint8_t pdb_no, uint32_t delay);
asdk_status_t pdb_loadvalues(uint8_t pdb_no);
asdk_status_t pdb_setmodulusvalue(uint8_t pdb_no, uint32_t delay);


#ifdef __cplusplus
} // extern "C"
#endif

#endif /* SOURCES_HW_PDB_H_ */
