/*
  @file
  hw_system.h

  @path
  /frdmkw36_demo_apps_power_manager/source/hw_system.h

  @Created on
  Mar 31, 2023

  @Author
  ajmeri.j

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief
   Header file for supporting system level APIs.
*/

#ifndef ASDK_CYT2B75_ASDK_DRIVERS_HW_SYSTEM_H_
#define ASDK_CYT2B75_ASDK_DRIVERS_HW_SYSTEM_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "errordef.h"
#include "system.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/


/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/
typedef void ( *func_ptr )( void ); // pointer to function type

/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/

/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t sys_init_default (void );
asdk_status_t sys_init (const asdk_sys_cfg_t *config );
asdk_status_t sys_get_state ( asdk_sys_st_t *state );
asdk_status_t sys_sw_reset ( void );
asdk_status_t sys_halt ( void );
asdk_status_t sys_enable_interrupts ( void );
asdk_status_t sys_disable_interrupts ( void );
asdk_status_t set_nvic_priority ( asdk_module_code_t module_name, uint8_t module_no, uint32_t priority  );
asdk_status_t relocate_vector_table ( const uint32_t app_start_address, const uint32_t startup_address );
asdk_status_t sys_get_unique_id ( uint32_t *id );
asdk_status_t sys_get_reset_reason (asdk_sys_reset_t *reason );
asdk_status_t sys_mux_configure ( asdk_clk_cfg_t *config );
asdk_status_t sys_clk_configure ( asdk_mux_cfg_t *config );
asdk_status_t sys_pm_configure ( asdk_pm_cfg_t *config );
asdk_status_t get_clock_frequency( asdk_clk_cfg_t *config, uint32_t *frequency );
asdk_status_t sys_get_multiple_reset_reasons (uint8_t *reason );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* ASDK_CYT2B75_ASDK_DRIVERS_HW_SYSTEM_H_ */
