/*
  @file
  hw_wdt.h

  @path
  /platform/asdk/kw36/asdk_drivers/hw_wdt.h

  @Created on
  Nov 21, 2019

  @Author
  anupam.kumar

  @Copyright
  Copyright (c) Ather Energy Pvt Ltd.  All rights reserved.

  @brief



*/

#ifndef ASDK_KW36_ASDK_DRIVERS_HW_WDT_H_
#define ASDK_KW36_ASDK_DRIVERS_HW_WDT_H_

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/
#include "wdt.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/


/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/


/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/


/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/


/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/
asdk_status_t watchdog_init ( asdk_wdt_config_t *wdt_config_data );
asdk_status_t watchdog_deinit ( uint8_t wdt_no);
asdk_status_t watchdog_refresh ( uint8_t wdt_no );
asdk_status_t watchdog_install_callback (uint8_t wdt_no, asdk_wdt_callback_fun_t callback_fun );

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* ASDK_KW36_ASDK_DRIVERS_HW_WDT_H_ */
