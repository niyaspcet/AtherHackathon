/*
    @file
    asdk_wdt.h

    @path
    asdk-gen2/platform/cyt2b75/inc/asdk_wdt.h

    @Created on
    Aug 21, 2023

    @Author
    gautam.sagar

    @Copyright
    Copyright (c) Ather Energy Pvt Ltd. All rights reserved.

    @brief
    This file prototypes the WDT Module for Ather SDK(asdk).

*/

#ifndef ASDK_WDT_H_
#define ASDK_WDT_H_

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/

#include <stdint.h>
#include <stdbool.h>
#include "asdk_error.h"

/*==============================================================================

                        DEFINITIONS AND TYPES : MACROS

==============================================================================*/
#define ASDK_WDT_MAX 3
/*==============================================================================

DEFINITIONS AND TYPES : ENUMS

==============================================================================*/
/*!
 * @brief WDT type whether it is IWDT or WWDT
 */
typedef enum
{
    ASDK_WDT_TYPE_INDEPENDENT = 0,
    ASDK_WDT_TYPE_WINDOW,
    ASDK_WDT_TYPE_MAX,
    ASDK_WDT_TYPE_UNDEFINED = ASDK_WDT_TYPE_MAX,
} asdk_wdt_type_t;

/*!
 * @brief WDT timeout action
 */

typedef enum
{
    ASDK_WDT_TIMEOUT_ACTION_NONE = 0,
    ASDK_WDT_TIMEOUT_ACTION_RESET,
    ASDK_WDT_TIMEOUT_ACTION_MAX,
    ASDK_WDT_TIMEOUT_ACTION_UNDEFINED = ASDK_WDT_TIMEOUT_ACTION_MAX,
} asdk_wdt_timeout_action_t;

/*!
 * @brief WDT WARN timeout action
 */

typedef enum
{

    ASDK_WDT_WARN_TIMEOUT_ACTION_NONE = 0,
    ASDK_WDT_WARN_TIMEOUT_ACTION_INTERRUPT,
    ASDK_WDT_WARN_TIMEOUT_ACTION_MAX,
    ASDK_WDT_WARN_TIMEOUT_ACTION_UNDEFINED = ASDK_WDT_WARN_TIMEOUT_ACTION_MAX,
} asdk_wdt_warn_timeout_action_t;

typedef void (*asdk_wdt_callback_fun_t)(uint8_t wdt_no);
/*==============================================================================

DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/
/*!
 * @brief WWDT config parameters incase of WDT type is WWDT
 */
typedef struct
{
    uint32_t lower_window_timeout_value_in_ms;
    uint32_t upper_window_timeout_value_in_ms;
} asdk_wdt_type_wwdt_config_t;

/*!
 * @brief WDT Configuration structure
 */

typedef struct
{
    uint8_t wdt_no;                                         /*!< WDT number(WDT module) */
    asdk_wdt_type_t wdt_type;                               /*!< WDT type: IWDT or WWDT */
    uint32_t wdt_timeout_value_in_ms;                       /*!< WDT timeout value in ms */
    asdk_wdt_type_wwdt_config_t wdt_wwdt_config;            /*!< WWDT configuration parameters */
    asdk_wdt_timeout_action_t wdt_timeout_action;           /*!< WDT timeout action to be taken */
    uint32_t wdt_warn_timeout_value_in_ms;                  /*!< WDT warning timeout value */
    asdk_wdt_warn_timeout_action_t wdt_warn_timeout_action; /*!< WDT warn action to taken */
    /*To do callback for warning interrupt*/
    bool enable_wdt_in_debug; /*!< Enable or disable WDT in DEBUG mode */
    bool enable_wdt;          /*!< WDT enable/disable */
} asdk_wdt_config_t;
/*==============================================================================

    EXTERNAL DECLARATIONS

==============================================================================*/

/*==============================================================================

    FUNCTION PROTOTYPES

==============================================================================*/

/*----------------------------------------------------------------------------*/
/* Function : asdk_watchdog_init */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initializes the WDT Module based on the config structure passed as parameter.

  @param [in] wdt_config_data ASDK WDT configuration parameter.

  @return
    - @ref ASDK_WDT_STATUS_SUCCESS
    - @ref ASDK_WDT_STATUS_ERROR
    - @ref ASDK_WDT_ERROR_NOT_INITIALIZED
    - @ref ASDK_WDT_ERROR_INVALID_HANDLER
    - @ref ASDK_WDT_ERROR_INVALID_WDT_NO

  @note Please use the wdt_no as 0 for the syswdt to be enabled.
        Other wdt_no is not supported for this cyt version

*/
asdk_errorcode_t asdk_watchdog_init(asdk_wdt_config_t *wdt_config_data);

/*----------------------------------------------------------------------------*/
/* Function : asdk_wdt_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-initializes the WDT Module based on the config structure passed as parameter.

  @param [in] wdt_no ASDK WDT no to be initialized.

  @return
    - @ref ASDK_WDT_STATUS_SUCCESS
    - @ref ASDK_WDT_ERROR_MAX_WDT_NO_EXCEEDED
*/
asdk_errorcode_t asdk_watchdog_deinit(uint8_t wdt_no);

/*----------------------------------------------------------------------------*/
/* Function : asdk_watchdog_refresh */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function clears ("feeds") the watchdog, to prevent a reset.

  @param [in] wdt_no ASDK WDT no to be initialized.

  @return
    - @ref ASDK_WDT_STATUS_SUCCESS
    - @ref ASDK_WDT_ERROR_MAX_WDT_NO_EXCEEDED
*/
asdk_errorcode_t asdk_watchdog_refresh(uint8_t wdt_no);

/*----------------------------------------------------------------------------*/
/* Function : asdk_watchdog_get_time_in_ms */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function returns the current watchdog time value in ms.

  @param [in] wdt_no ASDK WDT no.
  @param [out] wdt_time_value_in_ms watchdog current time value in ms to be returned to the user.

  @return
    - @ref ASDK_WDT_STATUS_SUCCESS
    - @ref ASDK_WDT_ERROR_MAX_WDT_NO_EXCEEDED
*/
asdk_errorcode_t asdk_watchdog_get_time_in_ms(uint8_t wdt_no, uint32_t *wdt_time_value_in_ms);

/*----------------------------------------------------------------------------*/
/* Function : asdk_watchdog_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function installs/registers the callback function for the user callback.

  @param [in] wdt_no ASDK WDT no to be initialized.
  @param [in] callback_fun Callback function to the user.

  @return
    - @ref ASDK_WDT_STATUS_SUCCESS
    - @ref ASDK_WDT_ERROR_MAX_WDT_NO_EXCEEDED
*/
asdk_errorcode_t asdk_watchdog_install_callback(uint8_t wdt_no, asdk_wdt_callback_fun_t callback_fun);

#endif /* ASDK_WDT_H_ */
