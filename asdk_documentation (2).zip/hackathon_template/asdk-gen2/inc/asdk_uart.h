/*
    @file
    asdk_uart.h

    @path
    asdk-gen2/inc/asdk_uart.h

    @Created on
    Oct 26, 2023

    @Author
    siddharth.das

    @Copyright
    Copyright (c) Ather Energy Pvt Ltd. All rights reserved.

    @brief
    This file prototypes the UART Module for Ather SDK(asdk).
*/

#ifndef ASDK_UART_H
#define ASDK_UART_H

/*==============================================================================

                               INCLUDE FILES

==============================================================================*/

#include <stdint.h>
#include <stdbool.h>
#include "asdk_mcu_pins.h"
#include "asdk_clock.h"
#include "asdk_error.h"
#include "asdk_platform.h"

/*==============================================================================

                      DEFINITIONS AND TYPES : MACROS

==============================================================================*/

/*==============================================================================

                      DEFINITIONS AND TYPES : ENUMS

==============================================================================*/

/*!
 * @brief UART event
 */
typedef enum
{
  ASDK_UART_STATUS_TRANSMIT_COMPLETE = 0,
  ASDK_UART_STATUS_TRANSMIT_ERROR,
  ASDK_UART_STATUS_RECEIVE_COMPLETE,
  ASDK_UART_STATUS_RECEIVE_OVERFLOW,
  ASDK_UART_STATUS_RECEIVE_ERR_FRAME,
  ASDK_UART_STATUS_RECEIVE_ERR_PARITY,
  ASDK_UART_STATUS_RECEIVE_BREAK_DETECT,
  ASDK_UART_STATUS_MAX,
  ASDK_UART_STATUS_UNDEFINED = ASDK_UART_STATUS_MAX,
}asdk_uart_status_t;

/*!
 * @brief UART Baud Rate
 */
typedef enum
{
    ASDK_UART_BAUD_RATE_300 = 300,
    ASDK_UART_BAUD_RATE_1200 = 1200,
    ASDK_UART_BAUD_RATE_2400 = 2400,
    ASDK_UART_BAUD_RATE_4800 = 4800,
    ASDK_UART_BAUD_RATE_9600 = 9600,
    ASDK_UART_BAUD_RATE_19200 = 19200,
    ASDK_UART_BAUD_RATE_38400 = 38400,
    ASDK_UART_BAUD_RATE_57600 = 57600,
    ASDK_UART_BAUD_RATE_115200 = 115200,
    ASDK_UART_BAUD_RATE_230400 = 230400,
    ASDK_UART_BAUD_RATE_460800 = 460800,
    ASDK_UART_BAUD_RATE_500000 = 500000,
    ASDK_UART_BAUD_RATE_576000 = 576000,
    ASDK_UART_BAUD_RATE_921600 = 921600,
    ASDK_UART_BAUD_RATE_1000000 = 1000000,
    ASDK_UART_BAUD_RATE_1152000 = 1152000,
    ASDK_UART_BAUD_RATE_1500000 = 1500000,
    ASDK_UART_BAUD_RATE_2000000 = 2000000,
    ASDK_UART_BAUD_RATE_2500000 = 2500000,
    ASDK_UART_BAUD_RATE_3000000 = 3000000,
    ASDK_UART_BAUD_RATE_3500000 = 3500000,
    ASDK_UART_BAUD_RATE_4000000 = 4000000,
    ASDK_UART_BAUD_RATE_MAX,
    ASDK_UART_BAUD_RATE_UNDEFINED = ASDK_UART_BAUD_RATE_MAX,
} asdk_uart_baud_rate_t;

/*!
 * @brief UART Mode of operation
 */

typedef enum
{
    ASDK_UART_MODE_STANDARD = 0,
    ASDK_UART_MODE_SMARTCARD,
    ASDK_UART_MODE_IRDA,
    ASDK_UART_MODE_MAX,
    ASDK_UART_MODE_UNDEFINED = ASDK_UART_MODE_MAX,
}asdk_uart_op_mode_t;

/*!
 * @brief UART Parity Mode
 *
 * Implements : asdk_uart_parity_mode_t
 */
typedef enum
{
    ASDK_UART_PARITY_NONE = 0,
    ASDK_UART_PARITY_EVEN = 2,
    ASDK_UART_PARITY_ODD = 3,
    ASDK_UART_PARITY_MAX,
    ASDK_UART_PARITY_UNDEFINED = ASDK_UART_PARITY_MAX,
} asdk_uart_parity_mode_t;

/*!
 * @brief UART Stop bits count
 *
 * Implements : asdk_uart_stop_bits_t
 */
typedef enum
{
    ASDK_UART_STOP_BITS_1 = 0,
    ASDK_UART_STOP_BITS_2,
    ASDK_UART_STOP_BITS_MAX,
} asdk_uart_stop_bits_t;

/*!
 * @brief UART Data bits count
 */
typedef enum
{
    ASDK_UART_DATA_BITS_5 = 5,
    ASDK_UART_DATA_BITS_6,
    ASDK_UART_DATA_BITS_7,
    ASDK_UART_DATA_BITS_8,
    ASDK_UART_DATA_BITS_9,
    ASDK_UART_DATA_BITS_MAX,
    ASDK_UART_DATA_BITS_UNDEFINED = ASDK_UART_DATA_BITS_MAX,
} asdk_uart_data_bits_t;

/*!
 * @brief An data structure to represent UART interrupt
 * settings.
 */
typedef struct
{
    bool use_interrupt; /*!< Enable or disable interrupts. */
    uint8_t priority;   /*!< Priority of the interrupt. */
} asdk_uart_interrupt_cfg_t;

/*==============================================================================

                   DEFINITIONS AND TYPES : STRUCTURES

==============================================================================*/

/*!
 * @brief UART transfer via DMA related config
 *
 * @note:The DMA should be configured for Byte transfer
 */
typedef struct
{
    uint8_t uart_dma_rx_channel_no;
    uint8_t uart_dma_tx_channel_no;

    uint8_t *uart_tx_data_buffer;
    uint32_t uart_tx_data_len_bytes;

    uint8_t *uart_rx_data_buffer;
    uint32_t uart_rx_data_len_bytes;
} asdk_uart_dma_config_t;

/*!
 * @brief UART Configuration structure
 *
 * @note: For tranfer via DMA ensure dataframe size to be Byte
 */
typedef struct
{
    asdk_uart_num_t uart_no; /* UART no. indicates the UART module no. of the ECU */
    uint8_t uart_tx_mcu_pin_no; /* UART TX mcu pin no */
    uint8_t uart_rx_mcu_pin_no; /* UART RX mcu pin no */
    uint8_t uart_cts_mcu_pin_no; /* UART CTS mcu pin no, currently not supported */
    uint8_t uart_rts_mcu_pin_no; /* UART RTS mcu pin no, currently not supported */

    asdk_uart_op_mode_t op_mode; /* UART Operation Mode */
    asdk_uart_baud_rate_t baud_rate; /* UART Baud Rate */
    asdk_uart_data_bits_t data_bits; /* UART Data bits count */
    asdk_uart_parity_mode_t parity_mode; /* UART Parity Mode */
    asdk_uart_stop_bits_t stop_bits; /* UART Stop bits count, currently 1 or 2 stop bits supported */

    asdk_uart_interrupt_cfg_t interrupt_config; /* UART interrupt config */
    asdk_uart_dma_config_t uart_dma_config; /* UART DMA config */

    bool enable_msb_first;  /* Enables to shift MSB first, otherwise, LSB first */
    bool enable_cts;    /* Enalbes the usage of CTS input signal */
    bool enable_rts;    /* Enables the usage of RTS output signal */
} asdk_uart_config_t;

/*==============================================================================

                           EXTERNAL DECLARATIONS

==============================================================================*/

/*==============================================================================

                           FUNCTION PROTOTYPES

==============================================================================*/

/**
*
* @todo Use uint8_t instead of asdk_uart_num_t for UART number.
*/
typedef void (*asdk_uart_callback_fun_t)(asdk_uart_num_t uart_no, uint8_t *data, uint32_t data_len, asdk_uart_status_t event);

/*----------------------------------------------------------------------------*/
/* Function : asdk_uart_init                                                 */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function initializes the UART Module based on the config structure passed as parameter.

  @param [in] uart_config_data ASDK UART configuration parameter.

  @return
    - @ref ASDK_UART_STATUS_SUCCESS
    - @ref ASDK_UART_ERROR_INITIALIZED
    - @ref ASDK_UART_ERROR_NULL_PTR
    - @ref ASDK_UART_ERROR_RANGE_EXCEEDED
    - @ref ASDK_UART_ERROR_INVALID_BAUD_RATE
    - @ref ASDK_UART_ERROR_MODULE_UNAVAILABLE
    - @ref ASDK_UART_ERROR_INIT_FAIL
*/
asdk_errorcode_t asdk_uart_init(asdk_uart_config_t *uart_config);

/*----------------------------------------------------------------------------*/
/* Function : asdk_uart_deinit */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function de-initializes the UART Module based on the UART number passed as parameter.

  @param [in] uart_no ASDK UART no. to be de-initialized.

  @return
    - @ref ASDK_UART_STATUS_SUCCESS
    - @ref ASDK_UART_ERROR_RANGE_EXCEEDED
*/
asdk_errorcode_t asdk_uart_deinit(asdk_uart_num_t uart_no);

/*----------------------------------------------------------------------------*/
/* Function : asdk_uart_install_callback */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function install callback for UART.

  @param [in] uart_no ASDK UART number
  @param [in] callback_fun Callback function pointer

  @return
    - @ref ASDK_UART_STATUS_SUCCESS
    - @ref ASDK_UART_ERROR_RANGE_EXCEEDED
*/
asdk_errorcode_t asdk_uart_install_callback(asdk_uart_num_t uart_no, asdk_uart_callback_fun_t callback_fun);

asdk_errorcode_t asdk_uart_write_blocking(asdk_uart_num_t uart_no, uint8_t *data, uint32_t data_len);
asdk_errorcode_t asdk_uart_read_blocking(asdk_uart_num_t uart_no, uint8_t *data, uint32_t data_len);

/*----------------------------------------------------------------------------*/
/* Function : asdk_uart_write_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function sends data out through UART module using non-blocking method.

  @param [in] uart_no ASDK UART number
  @param [in] data Pointer to buffer containing data to be sent.
  @param [in] data_len Length of data to be sent.

  @return
    - @ref ASDK_UART_STATUS_SUCCESS
    - @ref ASDK_UART_ERROR_RANGE_EXCEEDED
    - @ref ASDK_UART_ERROR_WRITE_FAIL
*/
asdk_errorcode_t asdk_uart_write_non_blocking(asdk_uart_num_t uart_no, uint8_t *data, uint32_t data_len);

/*----------------------------------------------------------------------------*/
/* Function : asdk_uart_read_non_blocking */
/*----------------------------------------------------------------------------*/
/*!
  @brief
  This function receives data from UART module using non-blocking method.

  @param [in] uart_no ASDK UART number
  @param [out] data Pointer to buffer containing data received.
  @param [in] data_len Length of data to be received.

  @return
    - @ref ASDK_UART_STATUS_SUCCESS
    - @ref ASDK_UART_ERROR_RANGE_EXCEEDED
    - @ref ASDK_UART_ERROR_READ_FAIL
*/
asdk_errorcode_t asdk_uart_read_non_blocking(asdk_uart_num_t uart_no, uint8_t *data, uint32_t data_len);

#endif /* ASDK_UART_H */