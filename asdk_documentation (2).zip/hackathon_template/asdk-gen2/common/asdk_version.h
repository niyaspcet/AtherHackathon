/* ###################################################################
**
**     This file was created by CMAKE BUILD
**     for the CYT2B75_M0PLUS series of microcontrollers.
**
** ################################################################### */ 

#define ASDK_MAJOR_VERSION 1 
#define ASDK_MINOR_VERSION 0 
#define ASDK_PATCH_VERSION 0 
#define ASDK_GIT_BRANCH ""
#define ASDK_GIT_COMMIT ""
#define ASDK_BUILD_DATE "2024-03-30"
#define ASDK_BUILD_TIME "10:52:59"
#define ASDK_EXE_NAME ""
#define APP_MAJOR_VERSION  
#define APP_MINOR_VERSION  
#define APP_PATCH_VERSION  
#define APP_GIT_BRANCH ""
#define APP_GIT_COMMIT ""
#define BUILD_MACHINE "@AE-LP-513"
#define BUILD_TYPE 0 // 0-release, 1-debug
