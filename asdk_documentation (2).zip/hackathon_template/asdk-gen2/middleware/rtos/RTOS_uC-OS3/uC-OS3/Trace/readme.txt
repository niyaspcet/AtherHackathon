The following trace tools are supported:

#####################################################################################
SEGGER SystemView for uC/OS-III

Download the embedded target code to support Segger's SystemView for uC/OS-III 
from the following website https://www.segger.com/downloads/free_tools#SystemView 
and place the files in this folder.
#####################################################################################
Percepio Tracealyzer for uC/OS-III

Download the embedded target code to support Percepio's Tracealyzer for µC/OS-III (Snapshot)
from the following website http://percepio.com/download and place the files in this folder.
#####################################################################################