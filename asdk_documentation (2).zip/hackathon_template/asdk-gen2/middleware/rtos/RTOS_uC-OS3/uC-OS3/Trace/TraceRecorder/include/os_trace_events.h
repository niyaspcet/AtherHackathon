/*
 * Trace Recorder for Tracealyzer v4.5.3
 * Copyright 2021 Percepio AB
 * www.percepio.com
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Tracealyzer recorder integration
 */

#include <trcRecorder.h>
