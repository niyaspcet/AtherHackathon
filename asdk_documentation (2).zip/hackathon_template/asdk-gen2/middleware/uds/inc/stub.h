/***************************************************************************************************
** Copyright (c) 2018 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Stub.h
** Module name  : 
** -------------------------------------------------------------------------------------------------
** Description : Include file of component Stub.h
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 
** - Baseline Created
**
***************************************************************************************************/
/* To avoid multiple inclusions */
#ifndef STUB_H
#define STUB_H
/**************************************** Inclusion files *****************************************/
#include "Fcm_cfg.h"
#include "Fcm.h"
/**************************************** Functions *****************************************/

extern uint8_t appFcmInitStatus(void);
extern void APP_FCM_ReadDTCInfo (FCM_DTC_InfoType * FCM_DTCInfo, uint16_t Size);
extern void APP_FCM_ReadDTCSnapShotAddInfo (FCM_DTCSnpShot_Info * FCM_DTCSnapShotInfo, uint16_t Size);
extern void APP_FCM_ReadDTCExtSnapShotAddInfo (FCM_DTCExtndSnpsht_Info * FCM_DTCExtSnapShotInfo, uint16_t Size);
extern void App_FCM_OpCyclChngUpdt(eFCM_GroupType DTC_GroupIndex, eFCM_OperationCycleType CycleStatus);
extern uint8_t App_FCMClearReqDTCUpdate(uint32_t DTC_index_number, uint8_t	DTC_count);
extern uint8_t App_FCM_DTC_StatusChange(uint8_t FCM_DTC_Idx);
extern uint8_t App_FCMClearAllDTC(void);

#endif /* STUB_H */
