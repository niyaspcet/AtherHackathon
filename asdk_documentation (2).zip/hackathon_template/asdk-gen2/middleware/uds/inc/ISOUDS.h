/***************************************************************************************************
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOUDS.h
**
** Description  : Include file of component ISOUDS.c
**
** -------------------------------------------------------------------------------------------------
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef ISOUDS__FUN_H
#define ISOUDS__FUN_H

/************************************* Inclusion files ********************************************/
#include "CanTp.h"
#include "UDS_Cfg.h"
/************************** Declaration of global symbol and constants ****************************/
#define     ISOUDS_TRUE            (0x01U)      /* ISOUDS_TRUE state */
#define     ISOUDS_FALSE           (0x00U)      /* ISOUDS_FALSE state */

#define     ISOUDS_ZERO            (0x00U)
#define     ISOUDS_ONE             (0x01U)
#define     ISOUDS_TWO             (0x02U)

#define     ISOUDS_DS              (0x01U)      /* Default Session */
#define     ISOUDS_PRGS            (0x02U)      /* Programming Session */
#define     ISOUDS_EXTDS           (0x03U)      /* Extended diagnostic Session */
#define     ISOUDS_SAFETYDIAGSESS  (0x04U)      /* Safety System Diagnostic 
											      Session */

/*----------------------------------------------------------------------------*/
/*          E P D R                    EXTDS    = Extended Disgnostic Session */
/*          X R S E                    PRGS     = Programming Session */
/*          T G   S                    DS       = Default Session */
/*          D S   V                    RESV     = Reserved */
/*          S                          */
/*----------------------------------------------------------------------------*/
#define  ISOUDS_SS_T_T_T_F     (0x0EU)          /* T -> TRUE , F -> FALSE */
#define  ISOUDS_SS_T_F_T_F     (0x0AU)          /* T -> TRUE , F -> FALSE */
#define  ISOUDS_SS_T_F_F_F     (0x08U)          /* T -> TRUE , F -> FALSE */
#define  ISOUDS_SS_T_T_T_T_F   (0x1EU)          /* T -> TRUE , F -> FALSE */
#define  ISOUDS_SS_T_T_F_F     (0x0CU)          /* T -> TRUE , F -> FALSE */
#define  ISOUDS_SS_F_T_F_F     (0x04U)          /* T -> TRUE , F -> FALSE */

#define     ISOUDS_NEGRESPSID      (0x7FU)      /* SID for Negative response */

#define     ISOUDS_POSRES           (0x00U)
#define     ISOUDS_SUPPRES_POS_RESP (0x80U)
#define     ISOUDS_BOOTMODE        (0xFF)      /* SID for boot mode */
#define     ISOUDS_NORMALMODE      (0x00)      /* SID for normal mode */

/* Negative response codes (ISO 14229) */
#define     ISOUDS_SNSIAS			(0x7FU)/* Service Not Supported In Active Session */
#define     ISOUDS_SNS				(0x11U)/* Service Not Supported */
#define     ISOUDS_SFNS				(0x12U)/* Sub Function Not Supported */
#define     ISOUDS_IMLOIF			(0x13U)/*Incorrect Message Length Or Invalid Format*/
#define     ISOUDS_RCRRP			(0x78U)/*Request Correctly ReceivedResponse Pending*/
#define     ISOUDS_ROOR				(0x31U)/* Request Out of Range */
#define     ISOUDS_CNC				(0x22U)/* Conditions Not Correct */
#define     ISOUDS_GPF				(0x72U)/* General Programming Failure */
#define     ISOUDS_SAD     			(0x33U)/* Security Access Denied */
#define     ISOUDS_UDNA    			(0x70U)/* Upload/Download not accepted */
#define     ISOUDS_RSE     			(0x24U)/* Request Sequence Error */
#define     ISOUDS_WBSC    			(0x73U)/* Wrong Block Sequence Counter*/
#define     ISOUDS_TDS     			(0x71U)/* Transfer Data Suspended */
#define     ISOUDS_IK      			(0x35U)/* Invalid Key */
#define     ISOUDS_ENOA    			(0x36U)/* Exceeded Number of Attempts */
#define     ISOUDS_RTDNE   			(0x37U)/* Required Time Delay Not Expired */
#define     ISOUDS_SFNSACTSESS		(0x7EU)/* Security Access Denied */

/* State machine values */
#define     ISOUDS_IDLE            (0x00U)      /* Idle */
#define     ISOUDS_RXPEND          (0x01U)      /* Receive Pending */
#define     ISOUDS_RXMSG           (0x02U)      /* Message received */
#define     ISOUDS_RESP            (0x03U)      /* Positive response */
#define     ISOUDS_RESPNEG         (0x04U)      /* Negative response */
#define     ISOUDS_RESPPEND        (0x05U)      /* Response pending */
#define     ISOUDS_TXRESPPEND      (0x06U)      /* Transmit response pending */
#define     ISOUDS_TXPEND          (0x07U)      /* Transmission confirmation 
												  Pending */

/********************************* Declaration of global macros ***********************************/
#define     M_ISOUDS_RXPEND			(ISOUDS_Conf.srvSt == (uint8)ISOUDS_RXPEND)
#define     M_ISOUDS_TXPEND			(ISOUDS_Conf.srvSt == (uint8)ISOUDS_TXPEND)

/********************************* Declaration of global types ****************/
typedef enum
{
	ISOUDS_FUCTIONAL_REQ = 1,
	ISOUDS_PHYSICAL_REQ = 2
}ISOUDS_ReqType;

/********************************* Declaration of global types ************************************/
typedef struct
{
    uint8  srvSt;          /* UDS service state */
    uint8  srvId;          /* UDS service id */
    uint8  srvNegResp;     /* Negative response code of the service */
    uint8  srvFrame;       /* Service request received in single or multiple frame */
    uint16 srvLen;         /* length */
    ISOUDS_ReqType ReqType; /* Request Addressing type */
}ISOUDS_ConfType;

/****************************** External links of global variables ************/
/* ECU Reset Request */
extern uint8 ISOUDS_EcuRstReq;

/* UDS Buffer for data */
extern uint8 ISOUDS_Buff[ISOUDS_BUFFSIZE];

/* UDS current session */
extern uint8 ISOUDS_Sess;

/* Timer for Ecu Reset */
extern uint32 ISOUDS_TmrECURst;

/* UDS configuration */
extern ISOUDS_ConfType ISOUDS_Conf;
extern uint8 BootFlag_ECUSt;


extern uint8 ISOUDS_BootFlag;
/****************************** External CANks of global constants ********************************/
/* wdt reset callfunction type */
 typedef void (*ISO_wdt_reset_cbk_t) (void);
/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/********************************** Function definitions ******************************************/
extern void ISOUDS_Init(ISO_wdt_reset_cbk_t wdt_immidiate_reset);
extern void ISOUDS_Main (void);
extern void ISOUDS_MsgIndi (const ISOTP_CfgType *isoTpConfPtr);
extern void ISOUDS_FFIndi (const ISOTP_CfgType *isoTpConfPtr);
extern void ISOUDS_TxCnfCbk (const ISOTP_CfgType *isoTpConfPtr);
extern void ISOUDS_Rst (void);
extern void ISOUDS_Mon (void);
extern void ISOUDS_ReqECUReset (void);
extern void ISOUDS_MsgIndiIm (const ISOTP_CfgType *isoTpConfPtr);

#endif  /* ISOUDS_H */
