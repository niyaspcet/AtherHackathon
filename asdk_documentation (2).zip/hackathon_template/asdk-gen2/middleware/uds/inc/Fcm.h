/***************************************************************************************************
** Copyright (c) 2018 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Fcm.h
** Module name  : Fault Code Management
** -------------------------------------------------------------------------------------------------
** Description : Include file of component Fcm.h
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 
** - Baseline Created
**
***************************************************************************************************/
/* To avoid multiple inclusions */
#ifndef FCM_H
#define FCM_H

/**************************************** Inclusion files *****************************************/
#include "Platform_Types.h"
#include "Compiler.h"
#include "Fcm_cfg.h"
// #include "errordef.h"
/********************************* Declaration of macros ************************************/

/****************************** Declaration of Global Symbols *************************************/
typedef enum{
	FCM_OPERATION_CYCLE_START,
	FCM_OPERATION_CYCLE_STOP
}eFCM_OperationCycleType;

typedef enum{
	FCM_TESTFAIL,
	FCM_TESTPASS
}eFCM_TestResultType;

typedef enum{
	FCM_DTC_SETTING_ON = 0x01U,
	FCM_DTC_SETTING_OFF
}eFCM_ControDTCType;

typedef enum{
	FCM_DTC_INFO = 0x00U,
	FCM_DTC_SNAP_INFO = 0x01U,
	FCM_DTC_EXT_SNAP_INFO = 0x02U,
}eFCM_NVM_DTCType;

/* fcm clear dtc callback fun type */
typedef uint8_t (*asdk_fcm_clear_dtc_t)(uint8_t dtc_index, uint32_t size, eFCM_NVM_DTCType nvm_dtc_type);

/* fcm write dtc fun callback type */
typedef uint8_t (*asdk_fcm_update_dtc_t)(void *src, uint32_t size, uint8_t dest_dtc_index, eFCM_NVM_DTCType nvm_dtc_type);

/* fcm read dtc fun callback type */
typedef uint8_t (*asdk_fcm_read_dtc_t)(void *dest, uint32_t size, eFCM_NVM_DTCType nvm_dtc_type);

/* strucute of Fcm erase,read and write cbk function */
typedef struct {
	asdk_fcm_clear_dtc_t asdk_fcm_clear_dtc_cbk_fun;
	asdk_fcm_update_dtc_t asdk_fcm_update_dtc_cbk_fun;
	asdk_fcm_read_dtc_t asdk_fcm_read_dtc_cbk_fun;
}asdk_fcm_dtc_cbk_t;

extern asdk_fcm_dtc_cbk_t asdk_fcm_dtc_cbk;

/****************************** Declaration of Global Types ***************************************/

/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/

/**************************** External functions declarations *************************************/
extern void FCM_Init(asdk_fcm_dtc_cbk_t *asdk_fcm_dtc_cbk_fun);
extern uint8_t FCM_GetDTCStatusByDTCNmbr (uint32_t DTC_Num);
extern uint8_t FCM_FindDTCIndex(uint32_t FCM_DTC_Number);
extern uint16_t FCM_FindNmDTCIndex(uint32_t FCM_DTC_Number);
extern uint8_t FCM_GetDTCStatusByDTCIndex (uint8_t DTC_Index);
extern uint8_t FCM_GetHealedDTCStatusByDTCNumber (uint16_t DTC_Index);
extern void FCM_CopyDTCStatusByDTCNumber (uint32_t DTC_Number, uint8_t* data_ptr);
extern void FCM_NotifyTestResult (uint8_t FCM_DTC_Idx, eFCM_TestResultType FCM_FaultSt);
extern void FCM_UpdateOperationCycle(eFCM_GroupType DTC_GroupIndex, eFCM_OperationCycleType CycleStatus);
extern uint8_t FCM_ClearAllDTCInfo (void);
extern uint8_t FCM_ClearRequestdDTCInfo (uint32_t DTC_Group_number);
extern uint16_t FCM_ReportNoOfDTCByStatusMask (uint8_t FCM_DTC_StatusMask);
extern uint16_t FCM_ReportDTCByStatusMask (uint8_t FCM_DTC_StatusMask, uint8_t* data_ptr);
extern uint16_t FCM_ReportSupportedDTCs (uint8_t* data_ptr);
extern uint8_t FCM_ReportFirstFailedDTC (uint8_t* data_ptr);
extern uint8_t FCM_ReportFirstCnfmdDTC (uint8_t* data_ptr);
extern uint8_t FCM_ReportMostRecentCnfmdDTC (uint8_t* data_ptr);
extern uint8_t FCM_ReportMostRecentTestFailed (uint8_t* data_ptr);
extern void FCM_UpdateCntrolDTCSetting (uint8_t DTCControlStat);
extern uint8_t FCM_GetCnfrmdDTCStatusByDTCNumber (uint32_t DTC_Number);
extern uint16_t FCM_ReportCnfmDTCForJ1939DM1 (uint8_t* data_ptr);
extern uint8_t FCM_ReportDTCSnapshotIdentification (uint8_t* data_ptr, uint16_t *length);
extern uint16_t FCM_AppReportDTCByStatusMask (uint8_t FCM_DTC_StatusMask, uint8_t* data_ptr, uint16_t* Index_prt);
extern void FCM_PassDTCtableInfo(FCM_DTC_InfoType * FcmDTCInfoPtr, uint16_t *FcmInfoSize);
extern uint8_t FCM_ReportDTCFaultDetectionCounter (uint8_t *DataBuff);
#endif /* FCM_H */
