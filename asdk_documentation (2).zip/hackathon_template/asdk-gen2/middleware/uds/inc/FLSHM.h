/*****************************************************************************************************
** Copyright (c) 2019 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : FLSHM.h
** Module name  : FLSHM driver
** -------------------------------------------------------------------------------------------------
**
** Description : Include file of component FLSHM.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 05/10/2018
** - Baseline Created
***************************************************************************************************/
/*To avoid multi-inclusions */
#ifndef _FLSHM_H_
#define _FLSHM_H_

#include "ISOUDS.h"

#define FLSHM_ZERO		0U
#define FLSHM_ONE		1U
#define FLSHM_EIGHT		8U

#define FLSHM_FALSE		0U
#define FLSHM_TRUE		1U

typedef struct
{
	uint32					BlockStartAddress;
	uint32					BlockEndAddress;
	uint32					BlockValiFlgAdd;
}FLSHM_BlockInfo_t;

typedef struct
{
	uint32 Crc;
	uint32 ImageSize;
}FLSHM_Valid_Header_t;

typedef enum
{
	 FLSHM_IDLE,
     FLSHM_ERASEFAILED,
	 FLSHM_VERFIYFAILED,
     FLSHM_PROGFAILED,
     FLSHM_SUCCESS,
     FLSHM_WRONGADDRESS,
     FLSHM_INPROGRESS
}FLSHM_ProgStat_t;

typedef enum
{
	FLASHMGR_IDLE		= 0,
	FLASHMGR_ERASE_REQ,
	FLASHMGR_ERASE,
	FLASHMGR_ERASE_DONE,
	FLASHMGR_PROGRAM,
	FLASHMGR_PROGRAM_DONE,
	FLASHMGR_VERIFY
}FLSHM_FlshMngrState_t;

typedef enum
{
	FLSHM_APPVALDN_IDLE,
	FLSHM_APPVALDN_REQ,
	FLSHM_APPVALDN_REQ_ACCEPT,
	FLSHM_APPVALDN_RUNNING,
	FLSHM_APPVLDN_FAIL,
	FLSHM_APPVLDN_PASS,
	FLSHM_DWNLD_VLDN_REQ,
	FLSHM_DWNLD_VLDN_RUNNING,
	FLSHM_DWNLD_VLDN_FAIL,
	FLSHM_DWNLD_VLDN_PASS
}FLSHM_AppVldnStat_t;

typedef enum
{
	PROG_FALSE,
	PROG_TRUE
}FLSHM_Prog_Stat_t;

typedef enum
{
	START_VALID,
	WAIT_VALID
}STATE_Valid;

/* flash erase callback fun type */
typedef bool (*asdk_flashm_erase_t)(uint32_t dest, uint32_t size);
/* flash write fun callback type */
typedef bool (*asdk_flashm_write_t)(uint32_t dest, uint32_t size, uint8_t *data );
/* flash read fun callback type */
typedef bool (*asdk_flashm_read_t)(uint32_t dest, uint32_t size, uint8_t *data );

/* strucute of flash flash erase and write function */
typedef struct {
	asdk_flashm_erase_t asdk_flashm_erase_cbk_fun;
	asdk_flashm_write_t asdk_flashm_write_cbk_fun;
	asdk_flashm_read_t asdk_flashm_read_cbk_fun;
}asdk_flashm_cbk_t;

extern asdk_flashm_cbk_t asdk_flashm_cbk;

#define TRANSFERDATA_BLOCKSIZE      256U

#define FLSHM_ZERO					0U

/***************************************************************************************************
** Function         : FLSHM_Init

** Description      : Initializes the Flash manager

** Parameter        : handle to flash driver

** Return value     : None

** Remarks          : None
***************************************************************************************************/
EXTERN FUNC(void, FLSHM_CODE) FLSHM_Init(asdk_flashm_cbk_t * asdk_flashm_cbk_fun );

/***************************************************************************************************
** Function         : FLSHM_FblTask

** Description      : Runs the Flash manger

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_FblTask(void);

/***************************************************************************************************
** Function         : FLSHM_ValidteReqAddress

** Description      : Validates the requested address

** Parameter        : Address	: Address to be validated from
					: Size		: Size from the requested address

** Return value     : None

** Remarks          : None
***************************************************************************************************/
EXTERN FUNC(uint8, FLSHM_CODE) FLSHM_ValidteReqAddress(VAR(uint32, AUTOMATIC) Address, VAR(uint32, AUTOMATIC) Size);

/***************************************************************************************************
** Function         : FLSHM_FindBlockIndx

** Description      : Validates the requested address

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
EXTERN FUNC(uint8, FLSHM_CODE) FLSHM_FindBlockIndx(VAR(uint32, AUTOMATIC) Address, VAR(uint32, AUTOMATIC) Size);

/***************************************************************************************************
** Function         : FLSHM_EraseAppReq

** Description      : Requests flash manager to erase application

** Parameter        : FlashEraseAddress : Flash start address to be erased
** 					  FlashEraseSize	: Flash Size to be erased
** Return value     : FLSHM_ProgStat_t : Flash manager erase request state

** Remarks          : None
***************************************************************************************************/
EXTERN FUNC(FLSHM_ProgStat_t, FLASHM_CODE) FLSHM_EraseAppReq(VAR(uint32, FLASHM_DATA) FlashEraseAddress, VAR(uint32, FLSHM_DATA) FlashEraseEndAddr);

/***************************************************************************************************
** Function         : FLSHM_ProgramReq

** Description      : Requests flash manager to enter Programming state

** Parameter        : Address			: Flash address to be programmed
** 					  Size				: Flash Size to be programmed
** Return value     : FLSHM_ProgStat_t	: Flash manager erase request state

** Remarks          : None
***************************************************************************************************/
EXTERN FLSHM_ProgStat_t FLSHM_ProgramReq(VAR(uint32, AUTOMATIC) Address, VAR(uint32, AUTOMATIC) Size);

/***************************************************************************************************
** Function         : FLSHM_StateMachine

** Description      : Flash manager state machine

** Parameter        : None
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
EXTERN FUNC(void,FLSHT_CODE)	FLSHM_StateMachine(void);

/***************************************************************************************************
** Function         : FLSHM_WritePacketReq

** Description      : Receives the packet and stores it in local buffer

** Parameter        : DwnldSeqCntr : Download sequence counter
** 					: SrcBuff : Source buffer where the data to be copied
** 					: len: Length of the data to be copied
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
EXTERN FUNC(FLSHM_ProgStat_t,FLSHT_CODE) FLSHM_WritePacketReq(uint16 DwnldSeqCntr, uint8 *SrcBuff, uint16 len);

/***************************************************************************************************
** Function                 : FLSHM_AppValdnStateMnger

** Description              : Flash manager Application validation state manager

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_AppValdnStateMnger(void);

/***************************************************************************************************
** Function                 : FLSHM_GetAppValdnStat

** Description              : Flash manager Get the application validation status

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(FLSHM_AppVldnStat_t, FLSHM_CODE) FLSHM_GetAppValdnStat(void);

/***************************************************************************************************
** Function                 : FLSHM_StartAppValdn

** Description              : Flash manager Start Application validation

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(void, FLSHM_CODE) FLSHM_StartAppValdn(void);

/***************************************************************************************************
** Function                 : FLSHM_StartDwnlValdn

** Description              : Flash manager Start validating the downloaded Image

** Parameter                : None

** Return value             : FLSHM_ProgStat_t

** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(FLSHM_AppVldnStat_t, FLSHM_CODE) FLSHM_StartDwnlValdn(VAR(uint32, FLASHM_DATA) FlashStrtAddress, VAR(uint32, FLSHM_DATA) FlashEndAddress, VAR(uint32, FLSHM_VAR) CheckSum);

/***************************************************************************************************
** Function                 : FLSHM_ResetAppValdnStat

** Description              : Resets the CRC validation state to Idle

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(void, FLSHM_CODE) FLSHM_ResetAppValdnStat(void);

/***************************************************************************************************
** Function                 : FLSHM_EcuResetRequest

** Description              : Flash ECU reset request 

** Parameter                : ResetFlag

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(void, FLSHM_CODE) FLSHM_EcuResetRequest(uint8 ResetFlag);

/***************************************************************************************************
** Function                 : FLSHM_GetCMDStatus

** Description              : Get Flash command status

** Parameter                : None

** Return value             : FLSHM_SUCCESS
**                              FLSHM_ERASEFAILED
**                              FLSHM_WRONGADDRESS

** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(FLSHM_ProgStat_t, FLSHM_CODE) FLSHM_GetCMDStatus(void);

/***************************************************************************************************
** Function                 : FLSHM_GetFlashState

** Description              : Get flash current state 

** Parameter                : None

** Return value             : FlashMgr_State

** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(FLSHM_FlshMngrState_t, FLSHM_CODE) FLSHM_GetFlashState(void);

/***************************************************************************************************
** Function                 : FLSHM_GetFlashLibState

** Description              : Get flash library current state

** Parameter                : None

** Return value             : FlashMgr_State

** Remarks                  : None
***************************************************************************************************/
EXTERN uint8 FLSHM_GetFlashLibState(void);

/***************************************************************************************************
** Function                 : FLSHM_GetCheckSum

** Description              : Get CheckSumCalculated

** Parameter                : None

** Return value             : FlashMgr_State

** Remarks                  : None
***************************************************************************************************/
EXTERN uint16 FLSHM_GetCheckSum(void);

#endif	/* FLSHM_H */
