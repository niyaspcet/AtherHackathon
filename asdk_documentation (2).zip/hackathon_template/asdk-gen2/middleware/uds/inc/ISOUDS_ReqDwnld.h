/***************************************************************************************************
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOUDS_ReqDwnld.h
**
** Description  : Include file of component ISOUDS_ReqDwnld.c
**
** -------------------------------------------------------------------------------------------------
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef ISOUDS_REQDWNLD_H
#define ISOUDS_REQDWNLD_H

/************************************* Inclusion files ********************************************/

/************************** Declaration of global symbol and constants ****************************/

/********************************* Declaration of global macros ***********************************/

/********************************* Declaration of global types ************************************/
/* SID of Request download service */
#define     ISOUDS_SIDREQDWNLD			(0x34)

/* Address of Flash library memory blocks */
#define     FLASH_LIB_START_ADDR		0x40003000UL
#define     FLASH_LIB_END_ADDR			0x40004000UL

/* Application memory range */
#define     APP_START_ADDR				0x00008000UL
#define     APP_END_ADDR				0x00008000UL

/* Start address of Primary boot related memory blocks */
#define     BOOT_PBSEG1_START_ADD     (uint32)0x3F010
#define     BOOT_PBSEG2_START_ADD     (uint32)0x38000

/* Start address of Secondary boot related memory blocks */
#define     BOOT_SBSEG1_START_ADD     (uint32)0x3E410
#define     BOOT_SBSEG2_START_ADD     (uint32)0x3A000

/****************************** External CANks of global variables ********************************/

/****************************** External CANks of global constants ********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/********************************** Function definitions ******************************************/
extern void ISOUDS_ReqDwnld (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[]);

#endif  /* ISOUDS_REQDWNLD_H */
