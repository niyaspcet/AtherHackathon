/***************************************************************************************************
** Copyright (c) 2019 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : FLSHM_Comn.h
** Module name  : FLSH Manager common header file
** -------------------------------------------------------------------------------------------------
**
** Description : FLASHM_Comn.h  file should be common between application and bootloader
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 05/10/2018
** - Baseline Created
***************************************************************************************************/
#ifndef _FLSHM_COMN_H_
#define _FLSHM_COMN_H_
/************************************** Inclusion files *******************************************/
#include "Platform_Types.h"
#include "FLSHM_Cfg.h"
#define NULL   0

/********************************** Component configuration ***************************************/

/********************************* Declaration of local functions *********************************/

/************************** Declaration of local symbol and constants *****************************/

/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/

/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/***************************************************************************************************
** Function         : FLSHM_GetReprogStat

** Description      : returns the Flash reprog status

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern FUNC(uint8, FLSHM_CODE) FLSHM_GetReprogStat(void);

/***************************************************************************************************
** Function         : FLSHM_SetReprogStat

** Description      : Sets the Reprog Request status

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern FUNC(void, FLSHM_CODE) FLSHM_ClrReprogReq(void);

/***************************************************************************************************
** Function         : FLSHM_SetReprogStat

** Description      : Sets the Reprog Request status

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern FUNC(void, FLSHM_CODE) FLSHM_ReqReprog(void);

#endif /* FLSHM_COMN_H */
