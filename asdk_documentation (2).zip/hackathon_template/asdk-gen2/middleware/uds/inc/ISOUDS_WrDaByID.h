/***************************************************************************************************
** Copyright (c) 2019 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOUDS_WrDaByID.h
** Module name  : CANWRDBID
** -------------------------------------------------------------------------------------------------
** Description : Configuration file of component CanSrv_WrDaByID.c
** This file must exclusively contain informations needed to
** use this component.
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** 
** 
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef CANSRV_WRDABYID_H
#define CANSRV_WRDABYID_H

/************************************* Inclusion files ********************************************/
#include "Platform_Types.h"
#include "ISOUDS.h"
#include "Compiler.h"
#include "ISOUDS_wrcfg.h"

/************************** Declaration of global symbol and constants ****************************/
/* DID with READ/WRITE */
/*------------------------------------------------------------------------------------------------*/

/*2 digit to indicate Bootloader version number (Major, Minor) */               
#define    BOOTLOADER_VERSIONNO                                                 0xF180
/*2 digit to indicate SW version number (Major, Minor) */
#define    SOFTWARE_VERSIONNO                                                   0xF195
/*Ecu Diagnostic Version */
#define    ECU_DIAGVERSION                                                      0xF1A0

/* DID size FOR READ/WRITE once (in byte) */
/*------------------------------------------------------------------------------------------------*/

#define    CanSrv_BOOTLOADER_VERSIONNO_LEN                                      2u
#define    CanSrv_SOFTWARE_VERSIONNO_LEN                                        2u                    
#define    CanSrv_ECU_DIAGVERSION_LEN                                           1u

                                                      
/************************flag Once Write/Read anytime  ********************************************/

#define    NVMDAL_BOOTLOADER_VERSIONNO_FLAGINDEX                         		135u
#define    NVMDAL_SOFTWARE_VERSIONNO_FLAGINDEX                           		136u
#define    NVMDAL_ECU_DIAGVERSION_FLAGINDEX                              		137u


/********************************* Declaration of global macros ***********************************/

/********************************* Declaration of global types ************************************/
/* SID of Write Data By Identifier service */
#define CANSRV_SIDWRDABYID              (0x2E)

/****************************** EXTERNal links of global variaCanSrves ****************************/

/****************************** EXTERNal links of global constants ********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/********************************** Function definitions ******************************************/

/***************************************************************************************************
** Function                 : CanSrv_WrDaByID
** Description              : Sends response to Write Data by ID service request
** Parameter canSrvDConfPtr : Pointer to service configuration structure
** Parameter dataBuff       : Pointer to service data buffer
** Return value             : None
** Remarks                  : None
***************************************************************************************************/
EXTERN FUNC(void, CAN_CODE)CanSrv_WrDaByID(P2VAR(ISOUDS_ConfType,AUTOMATIC,CAN_APPL_DATA)canSrvDConfPtr,\
                                                                  VAR(uint8, AUTOMATIC) dataBuff[]);
								
#endif  /* CANSRV_WRDABYID_H */
