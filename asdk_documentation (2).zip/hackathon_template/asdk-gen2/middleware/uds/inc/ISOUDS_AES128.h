
/* To avoid multi-inclusions */
#ifndef ISOUDS_SEEDKEY_H
#define ISOUDS_SEEDKEY_H
/************************************* Inclusion files ********************************************/
#include "Platform_Types.h"

/************************** Declaration of global symbol and constants ****************************/

extern unsigned char generateKeyLevel1(unsigned long  seed, unsigned long  *p_key);
extern unsigned char generateKeyLevel3(unsigned long seed, unsigned long *p_key);
extern unsigned char generateKeyLevel7(unsigned long seed, unsigned long *p_key);
extern unsigned long GetSeedLevel1(void);
extern unsigned long GetSeedLevel3(void);
extern unsigned long GetSeedLevel41(void);
extern unsigned long GetSeedLevel7(void);
extern unsigned char generateKeyLevel41(unsigned long seed, unsigned long *p_key);

/**************** Declaration of global symbol and constants ******************/
//int sub_box[256];
//int Inv_sub_box[256];
//int round_const[255];

/*********************************************************************************************************/
/******************** Declaration of global macros ****************************/
#define MAX_LENGHTKEY			176U
#define no_of_round 			10U
#define key_length    			16U
#define no_of_words				4U
#define ZERO					0U
#define ONE						1U
#define TWO						2U
#define THREE					3U
#define FOUR					4U
#define FIVE					5U
#define SIX						6U
#define SEVEN					7U
#define EIGHT					8U
#define NINE					9U
#define TEN						10U
#define ELEVEN					11U
#define TWELVE					12U
#define THIRTEEN				13U
#define FOURTEEN				14U
#define FIFTEEN					15U

#define Two_Byte				16U
#define Four_Byte				32U

// #define TRUE					0x01

#define FixedMatrixData_1		0x01
#define FixedMatrixData_2		0x02
#define FixedMatrixData_3		0x03

#define InvFixedMatrixData_1	0x09
#define InvFixedMatrixData_2	0x0b
#define InvFixedMatrixData_3	0x0d
#define InvFixedMatrixData_4	0x0e

#define FixedValue				0x1bU

#define ZERO 			0U
#define ONE				1U
#define MAX_LENGTH		16U
#define MAX_LOOP		30U

#define getstackptr(x) {\
						__asm__ __volatile("mov %0,SP":"=r"(x));\
						}

/*#define NULL 			0L*/

/******************** External links of global variables **********************/

typedef unsigned char   uint8_t;
/******************** External links of global constant ***********************/

/*******************************************************************************/
/*******************************************************************************
** FUNCTIONS **
*******************************************************************************/

/************************** Function definitions ******************************/

/*******************************************************************************
** Function name: AES128_cipher_encrypt
** Description: AES128_cipher_encrypt() will perform rounds and calling subfunctions.
** Parameter index : message and pointer to roundkey.
** Return value: message.
** Remarks: No global variables used.
*******************************************************************************/
/* perform rounds of subfunction calling. */
//uint8_t* AES128_cipher_encrypt(uint8_t Initmsgword[16], uint8_t* ptrtokey);
uint8_t* AES128_cipher_encrypt(uint8_t Initmsgword[], const uint8_t* ptrtokey);

/*******************************************************************************
** Function name: AES128_Add_Round_key
** Description: AES128_Add_Round_key() will XORed the initial key with msg_state_word.
** Parameter index : Round count, pointer to message, pointer to roundkey.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/
/* perform XORed with round key and msg_state_word. */
void AES128_Add_Round_Key(uint8_t *ptrtomsgword, const uint8_t *ptrtokey, uint8_t round);

/*******************************************************************************
** Function name: AES128_Sub_Bytes
** Description: AES128_Sub_Bytes() will substitute each msg_state_word with element from Sub_Box.
** Parameter index : pointer to message
** Return value: None
** Remarks: Sub_Box lookup table is used.
*******************************************************************************/
/* substitute the msg_state_word byte from element of Substitute box. */
void AES128_Sub_Bytes(uint8_t* ptrtomsgword);

/*******************************************************************************
** Function name: AES128_Shift_Rows
** Description: AES128_Shift_Rows() will circular left shift the each row of msg_state_word.
				1st row will not shift, 2nd row left shifted by 1 byte
				3rd row left shifted by 2 bytes, 4th row left shifted by 3 bytes.
** Parameter index : pointer to message.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/
/* perform circular left shift on msg_state_word. */
void AES128_Shift_Rows(uint8_t* ptrtomsgword);

/*******************************************************************************
** Function name: AES128_Mix_Column
** Description: AES128_Mix_Column() will perform matrix multiplication and XORed with msg_state_word and fixed matrix.
** Parameter index : pointer to message.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/
/* perform matrix multiplication and XORoperation of fixed matrix with msg_state_word. */
void AES128_Mix_Column(uint8_t* ptrtomsgword);

/*******************************************************************************
** Function name: AES128_Multiply
** Description: AES128_Multiply() will perform matrix multiplication with msg_state_wordand fixed matrix as per galois field.
** Parameter index : msg_state_word and fixed matrix elemnet
** Return value: multiplication result.
** Remarks: No global variables used.
*******************************************************************************/
/* perform matrix multiplication of fixed matrix with msg_state_word. */
uint8_t AES128_Multiply(uint8_t msg_word,uint8_t element);

/*******************************************************************************
** Function name: AES128_Key_Expansion
** Description: AES128_Key_Expansion() will take initial key and generate different key for different round.
** Parameter index : pointer to Initialkey.
** Return value:  None.
** Remarks: Sub_Box lookup table and round const lookup table is used.
*******************************************************************************/
/* Geenrate 10 different key for 10 rounds. */
void AES128_Key_Expansion(uint8_t *ptrtokey);

/*******************************************************************************
** Function name: AES128_cipher_decrypt
** Description: AES128_cipher_decrypt() will perform rounds inverse of cipher and calling subfunctions.
** Parameter index : cipher message and round key.
** Return value: cipher message.
** Remarks: No global variables used.
*******************************************************************************/
/* perform round of subfunction calling. */
uint8_t* AES128_cipher_decrypt(uint8_t ciphermsgword[16], const uint8_t* ptrtokey);

/*******************************************************************************
** Function name: AES128_Inv_Shift_Rows
** Description: AES128_Inv_Shift_Rows() will circular Right shift the each row of msg_state_word.
				1st row will not shift, 2nd row right shifted by 1 byte
				3rd row right shifted by 2 bytes, 4th row right shifted by 3 bytes.
** Parameter index : Pointer to cipher message.
** Return value: None.
** Remarks:No global variables used.
*******************************************************************************/
/* perform circular left shift on msg_state_word. */
void AES128_Inv_Shift_Rows(uint8_t* ptrtociphermsgword);

/*******************************************************************************
** Function name: AES128_Inv_Sub_Bytes
** Description: AES128_Inv_Sub_Bytes() will substitute each msg_state_word with element from Inv_Sub_Box.
** Parameter index : Pointer to cipher message.
** Return value: None
** Remarks: Inv_Sub_Box lookup table is used.
*******************************************************************************/
/* substitute the msg_state_word byte from element of Inverse Substitute box. */
void AES128_Inv_Sub_Bytes(uint8_t* ptrtociphermsgword);

/*******************************************************************************
** Function name: AES128_Inv_Mix_Column
** Description: AES128_Inv_Mix_Column() will perform matrix multiplication and XORed with msg_state_word and fixed matrix.
** Parameter index : Pointer to cipher message.
** Return value: None
** Remarks:  No global variables used.
*******************************************************************************/
/* perform matrix multiplication and XORoperation of fixed matrix with msg_state_word. */
void AES128_Inv_Mix_Column(uint8_t* ptrtociphermsgword);


/*******************************************************************************
** Function name: Generatecipherkey
** Description: Generatecipherkey() will perform all operation and generate cipher message.
** Parameter index :  message,pointer to initial constantkey, pointer to hold the final cipher message.
** Return value: None
** Remarks:  No global variables used.
*******************************************************************************/
/*void Generatecipherkey(uint8_t msgword[], const uint8_t constantkey[],uint8_t *ptr);*/
/*void Generatecipherkey(uint8_t msgword[], const uint8_t *constantkey,uint8_t *ptr);*/
void Generatecipherkey(uint8_t *SEED,uint8_t *ptr);


/*******************************************************************************
** Function name: Genrerateoriginalmsg
** Description: Genrerateoriginalmsg() will perform all reverse operation and generate original message.
** Parameter index :  cipher message,pointer to initial constantkey, pointer to hold the original message.
** Return value: None
** Remarks:  No global variables used.
*******************************************************************************/
/*void Genrerateoriginalmsg(uint8_t finalword[], const uint8_t key[],uint8_t *ptrtooriginal);*/
void Genrerateoriginalmsg(uint8_t finalword[], const uint8_t *key,uint8_t *ptrtooriginal);

/*******************************************************************************
** Function name: GenerateRandomNum
** Description: GenerateRandomNum() will generate the random numbers.
** Parameter index :  Pointer to hold the generate Random Numbers.
** Return value: None
** Remarks:  No global variables used.
*******************************************************************************/

void GenerateRandomNum(uint8_t *ptrtoBuffer);


#endif /* ISOUDS_SEEDKEY_H */
