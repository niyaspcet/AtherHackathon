/***************************************************************************************************
** Copyright (c) 2018 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : CanIL.h
** Module name  : CAN Interaction-Presentation Layer
** -------------------------------------------------------------------------------------------------
** Description : Include file of component CanIf.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 22/07/2019
** - Baseline Created
** ------------------------------------------------------------------------------------------------
**
**
***************************************************************************************************/

/* To avoid multi-inclusions */
#ifndef CANIL_H
#define CANIL_H
#define ASDK_CAN_INTF 1
/************************************* Inclusion files *******************************************/
#include "CanTp_Cfg.h"
#include "CanIL_Cfg.h"
//#include "device_registers.h"
#include "Compiler.h"
#include <stdbool.h>
extern CANIL_UDSmsgVal CANT_UDStxVal;
extern CANIL_UDSmsgVal CANT_UDSRxVal;
/****************************** External links of global variables *******************************/
/************************** Declaration of global symbol and constants ***************************/
extern uint64 CANIL_DataBufComplmt[CANIL_NO_OF_TXRX_MESSAGES];
/***************************************** Macro Definition **************************************/

/*Initialization value */
#define		CANIL_INIT_VAL 								0u

/*Max possible value for uint8_t data type */
#define		CANIL_UINT8_MAX_VAL							0xFFu

/*Max possible value for uint16_t data type */
#define		CANIL_UINT16_MAX_VAL						0xFFFFu

/*Max possible value for uint32_t data type */
#define		CANIL_UINT32_MAX_VAL						0xFFFFFFFFu

/*Reset any flag */
#define		CANIL_FLAG_RESET		 					0u

/*Set any flag */
#define		CANIL_FLAG_SET		 						1u

/*Null pointer */
#define     CANIL_NULL_PTR								((void *)0)

/*status true*/
#define     CANIL_TRUE									1u

/*status false */
#define     CANIL_FALSE									0u

#define		ISOTP_CHA_CAN				   				0U
#define		ISOTP_CHA_VCAN				   				1U

/*Size of individual byte */
#define		CANIL_MAX_DATA_LENGTH 				8

/******************* Declaration of structure / union and Enums **************/

/*CAN msg validation enum */
typedef enum
{
    CANIL_INVALID_CAN_MSG = CANIL_INIT_VAL,
    CANIL_VALID_CAN_MSG
}CANIL_MsgValidation_enum;

/*CAN msg Tx and Rx data buffer structure */
typedef struct
{
    uint32_t MsgID;
    uint8_t  dlc;
    CANIL_IDFormat_e IDFormat;
    uint8_t  dataBuff[8];
}CANIL_Msg_st;

typedef struct
{
    uint8  DLC;
    uint8  dataBuff[8u];
}CANIL_DiagTxframe_st;

typedef struct {
	/*CAN msg Id*/
	uint32_t ServId;
	uint32_t ClientId;
}CanMod_DiagRxMsgId_st;


#define 	ISOTP_NO_OF_CHANNELS				3U


/* callback funcyion function for Tx channel */
typedef void (*ISOTPTXReq_CHTYPE) (uint32_t MsgId , CANIL_IDFormat_e Type,uint8_t dlc, uint8_t *buff);

typedef enum
{
	ISOTP_CH_CAN_0,
	ISOTP_CH_CAN_1,
	ISOTP_CH_UART
}ISOTP_CHType;

typedef struct {
	/* Max TX module */
	uint8_t max_tx_channel;

	/* array of CANil, CANTP  and vcan transmit callback function */
	ISOTPTXReq_CHTYPE TxReqConfTable [ISOTP_NO_OF_CHANNELS];
}asdk_canil_cbk_t;

/************************************** Function Declaration *************************************/
/**************************************************************************************************
** Function name    : CANIF_Init
**
** Description      : Initialized the CANIF parameters.
**
** Parameter        : None
**
** Return value     : None
**
** Remarks          : None
**************************************************************************************************/
extern void CANIL_Init (asdk_canil_cbk_t *asdk_canil_cfg );

/**************************************************************************************************
** Function name : CANT_RxMsgIdSet
** Description   : Configure the Rx message id
** Parameter     : RxMsgId				Specifies the CAN_ID
** 				   MsgFormat			Specifies the CAN types, Standard or Extended.
** 				   FitIdx				Index to write the ID
** Return value  : void
** Remarks       : global variables used, side effects
**************************************************************************************************/
extern void CANIL_RxMsgIdSet(uint32 CANIL_RxMsgId,uint8 CANIL_MsgFormat,uint8 CANIL_FitIdx);

/**************************************************************************************************
** Function name : CANIL_SetTx_Event_Msg
** Description   : set tx event message 
** Parameter     : MsgIndex
** Return value  : status
** Remarks       : None
**************************************************************************************************/
extern uint8_t CANIL_SetTx_Event_Msg (uint8_t MsgIndex );
/**************************************************************************************************
** Function name    : CANIF_ReceiveMsg
**
** Description      : Read Rx message from CAN driver and update the data buffer.
**
** Parameter        : MsgID - Messaged id of Rx CAN message
**					: dlc  -  Data length of collected RX message
**					: *Data - pointer to collected Rx data.

** Return value     : None

** Remarks          : None
**************************************************************************************************/
extern bool CANIL_ReceiveMsg(uint32_t MsgID, uint8_t dlc, uint8_t* Data, uint8 ISOTP_CH);
/**************************************************************************************************
** Function name    : CANIF_GetRxMsg
**
** Description      : Read requested signal data from the Rx data buffer.
**
** Parameter        : MsgId - Message Id
**					  *SignalData - pointer to collect requested signal data

** Return value     : ErrorCode - Error code as par collected data.

** Remarks          : None
**************************************************************************************************/
extern uint8_t CANIL_GetRxMsg (uint32_t MsgId, float * DataBuff, uint8_t *SignCount);
/**************************************************************************************************
** Function name    : CANIF_SetTxMsg
**
** Description      : Set requested signal data in Tx data buffer.
**
** Parameter        : SignalId - signal Id
**					  SignalData - signal data to transmit

** Return value     : ErrorCode - Error code as par signal data set for Tx message.

** Remarks          : None
**************************************************************************************************/
extern uint8_t CANIL_SetTxMsg (uint32_t MsgId, float * DataBuff, uint8_t SignCount);
/**************************************************************************************************
** Function name    : CANIF_TxConfCbk
**
** Description      : Send acknowledgment for data transmission completed.
**
** Parameter        : MailBoxIndex - mail box index of transmission complete message.

** Return value     : None

** Remarks          : None
**************************************************************************************************/
extern void CANIL_TxConfCbk(uint32_t MsgId);
/**************************************************************************************************
** Function                 : CANIf_Scheduler

** Description              : Schedule the CAN Interaction Layer

** Parameter                : None

** Return value             : None

** Remarks                  : None
**************************************************************************************************/
extern void CANIL_Scheduler(void);
extern void CANIL_Scheduler_CI(void);

/* send periodic message */
extern void CANIL_ProcessPeriodicTxn(uint8_t Index);

/**************************************************************************************************
** Function name    : CANIL_ProcessEventTxn
**
** Description      : Collect event base message and send write on CAN bus.
**
** Parameter        : Index - Message index of the Tx message

** Return value     : None

** Remarks          : None
***************************************************************************************************/
extern void CANIL_ProcessEventTxn(uint8_t Index);

/**************************************************************************************************
** Function                 : CANIL_DiagTransmitMsg

** Description              : Transmits the message to CAN driver.

** Parameter                : CANIL_Msg_st tx_frame- Message structure of Tx.

** Return value             : None

** Remarks                  : None
**************************************************************************************************/
extern void CANIL_DiagTransmitMsg(uint32_t MsgId, uint8_t IDFormat, uint8  DLC, uint8* dataBuff, uint8 ISOTP_CH);
/**************************************************************************************************
** Function name    	: CANIL_RxTxCtrl
** Description      	: Controls the Tx and Rx of CAN module.
** Parameter        	: CANIL_Dir->Tx or Rx, CANIL_Ctrl->Enable/Disable
** Return value     	: None
** Remarks          	: None
**************************************************************************************************/
void CANIL_RxTxCtrl(CANIL_UDSmsgMode CANIL_Ctrl,CANIL_UDSmsgVal CANIL_Val);
/**************************************************************************************************
** Function name : CANT_EnInterrupt
** Description   : Enable the CAN interrupt
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_EnInterrupt(void);
/**************************************************************************************************
** Function name : CANT_DisInterrupt
** Description   : Disable the CAN interrupt
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_DisInterrupt(void);
/**************************************************************************************************
** Function name : CANT_Enable
** Description   : Enable the CAN module
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_Enable(void);
/**************************************************************************************************
** Function name : CANIL_Disable
** Description   : Disable the CAN module
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_Disable(void);
#endif  /* CANIL_H */

/* get canid of system canid for event based message transmission */
uint8_t CANIL_get_system_canid_index_number(uint32_t can_id);

/* get canid of ci canid for event based message transmission */
uint8_t CANIL_get_ci_canid_index_number(uint32_t can_id);
