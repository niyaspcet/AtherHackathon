/***************************************************************************************************
** Copyright (c) 2019 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : FLSHM.c
** Module name  : FLSH Manager
** -------------------------------------------------------------------------------------------------
**
** Description : FLASHM Initialize, Read , Write and Erase functions
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 05/10/2018
** - Baseline Created
***************************************************************************************************/

/************************************** Inclusion files *******************************************/
#include "FLSHM.h"
// #include "WDT.h"
#include "FLSHM_Cfg.h"
#include "FLSHM_Comn.h"
/********************************** Component configuration ***************************************/

/********************************* Declaration of local functions *********************************/
STATIC FUNC(FLSHM_ProgStat_t,FLSHT_CODE)	FLSHM_ProgrammMain(void);
STATIC FUNC(FLSHM_ProgStat_t, FLSHM_CODE) Flash_ProgramApp(uint32  *Dst, uint8 *Src, uint16 Chunksize);
STATIC FUNC(void,FLSHT_CODE)	FLSHM_ClearBuff(uint8 *Buff, uint16 Buff_size);
STATIC FUNC(uint32, FLSHM_CODE) FLSHM_CalcCRC(uint32 Address, uint32 CRC_size);
STATIC FUNC(FLSHM_ProgStat_t, FLSHM_CODE) FLSHM_UpdateAppValdnHdr(uint8 Block, uint32 RxdCRC, uint32 Size);
// STATIC FUNC(void, FLSHM_CODE) FLSHM_JumpToApp(void);

/************************** Declaration of local symbol and constants *****************************/

/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/
/* Start and end address for Erase request */
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_EraseStartAddress;
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_EraseEndAddress;
/* Start and end address for Program request */
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_ProgStartAddress;
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_ProgCurrntAddress;
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_ProgEndAddress;
/* Validation request information */
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_VldnSize;
STATIC VAR(FLSHM_AppVldnStat_t, FLSHM_VAR)		FLSHM_ValdnState;
STATIC VAR(FLSHM_Valid_Header_t, FLSHM_VAR)		FLSHM_ValidHeadVal;
/* Assuming number of blocks could be less that 256 */
STATIC VAR(uint8, FLSHM_VAR)					FLSHM_ValidnBlk;

/* Stores the calculated CheckSum */
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_CalctdCRC ;
/* Validation memory pointer */
STATIC VAR(uint32, FLSHM_VAR)					FLSHM_ValdnCurrAddress;

/* Current flash Address to be erased */
VAR(uint32, FLSHM_VAR)							FLSHM_EraseCurrAddr;

/* Flash manager State */
STATIC VAR(FLSHM_FlshMngrState_t, FLSHM_VAR)	FLSHM_FlshMngrState;
/* Program buffer */
STATIC VAR(uint8, FLSHM_VAR) 				FLSHM_ProgramBuff[TRANSFERDATA_BLOCKSIZE];
/* Flash to indicate program buffer is full */
STATIC VAR(FLSHM_Prog_Stat_t, FLSHM_VAR) 	FLSHM_ProgramBuff_Full;
/* Download sequence counter */
STATIC VAR(uint16, FLSHM_VAR)				Flash_DwnldSeqCntr;
STATIC VAR(uint16, FLSHM_VAR)				FlshMWriteReqSize;

/* Flash command status */
STATIC	VAR(FLSHM_ProgStat_t, FLSHM_VAR)	FLSHM_CmdStat;

STATIC CONST(FLSHM_BlockInfo_t, FLSHM_VAR)	FLSHM_BlockInfo[FLSHM_NUM_OF_BLOCKS] = {FLSHM_LOGICAL_BLK_TAB, FLSHM_LOGICAL_BLK_TAB_SBL};

/* Stores the current block being downloaded */
STATIC VAR(uint8, FLSHM_VAR)				FLSHM_CurrentBlock;

asdk_flashm_cbk_t asdk_flashm_cbk = {0};
uint8 *Source;
uint16 size;
/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/***************************************************************************************************
** Function         : FLSHM_Init

** Description      : Initializes the Flash manager and set callback for flash erase and write

** Parameter        : asdk_flashm_cbk_t - flash erase/write callback structure

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_Init(asdk_flashm_cbk_t * asdk_flashm_cbk_fun  )
{
	VAR(uint16, AUTOMATIC) index;

	/* Initialize the state manger states */
	FLSHM_FlshMngrState 		= FLASHMGR_IDLE;

	/* Initialize the Erase address */
	FLSHM_EraseStartAddress		= FLSHM_BlockInfo[FLSHM_ZERO].BlockStartAddress;
	FLSHM_EraseEndAddress		= FLSHM_BlockInfo[FLSHM_ZERO].BlockEndAddress;

	/* Initialize the Program start address */
	FLSHM_ProgStartAddress		= FLSHM_BlockInfo[FLSHM_ZERO].BlockStartAddress;
	FLSHM_ProgEndAddress		= FLSHM_BlockInfo[FLSHM_ZERO].BlockEndAddress;

	/* Clear the program buffer */
	for (index = FLSHM_ZERO; index < TRANSFERDATA_BLOCKSIZE; index++)
	{
		FLSHM_ProgramBuff[index] = FLSHM_ZERO;
	}

	/* Clear the buffer full status */
	FLSHM_ProgramBuff_Full = PROG_FALSE;

	/* Reset download sequence counter */
	Flash_DwnldSeqCntr		= FLSHM_ZERO;

	/* Current flash block pointer */
	FLSHM_CurrentBlock = FLSHM_ZERO;

	/* Flash command status */
	FLSHM_CmdStat = FLSHM_IDLE;

	FLSHM_ValdnState = FLSHM_APPVALDN_IDLE;

	/* store flash cbk function */
	if(asdk_flashm_cbk_fun != NULL)
	{
		/* store flash cbk function */
		asdk_flashm_cbk.asdk_flashm_erase_cbk_fun = asdk_flashm_cbk_fun->asdk_flashm_erase_cbk_fun;
		asdk_flashm_cbk.asdk_flashm_write_cbk_fun = asdk_flashm_cbk_fun->asdk_flashm_write_cbk_fun;
	}
}

/***************************************************************************************************
** Function         : FLSHM_FblTask

** Description      : Runs the Flash manger

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_FblTask(void)
{
	/* Schedules the flash manager */
	FLSHM_StateMachine();
}

/***************************************************************************************************
** Function         : FLSHM_ValidteReqAddress

** Description      : Validates the requested address

** Parameter        : Address	: Address to be validated from
					: Size		: Size from the requested address

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint8, FLSHM_CODE) FLSHM_ValidteReqAddress(VAR(uint32, AUTOMATIC) Address, VAR(uint32, AUTOMATIC) Size)
{
	uint8 BlkValidty = FALSE;
	uint8 LoopIndx = FLSHM_ZERO;

	/* Till the last logical block */
	for (LoopIndx = FLSHM_ZERO; LoopIndx < FLSHM_NUM_OF_BLOCKS; LoopIndx++)
	{
		/* Check if the requested size if within the range */
		if ((FLSHM_BlockInfo[LoopIndx].BlockStartAddress == Address) &&
			((FLSHM_BlockInfo[LoopIndx].BlockEndAddress) >= (Size - FLSHM_ONE)))
		{
			/* VValidation success */
			BlkValidty = TRUE;
			break;
		}
	}

	return BlkValidty;
}

/***************************************************************************************************
** Function         : FLSHM_FindBlockIndx

** Description      : Validates the requested address

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint8, FLSHM_CODE) FLSHM_FindBlockIndx(VAR(uint32, AUTOMATIC) Address, VAR(uint32, AUTOMATIC) Size)
{
	uint8 BlkIndx = FLSHM_ZERO;
	uint8 LoopIndx = FLSHM_ZERO;

	/* Till the last logical block */
	for (LoopIndx = FLSHM_ZERO; LoopIndx < FLSHM_NUM_OF_BLOCKS; LoopIndx++)
	{
		/* Check if the requested address within the range */
		if ((FLSHM_BlockInfo[LoopIndx].BlockStartAddress <= Address) &&
			((FLSHM_BlockInfo[LoopIndx].BlockEndAddress) >= (Address + Size - FLSHM_ONE)))
		{
			/* Block index found */
			BlkIndx = LoopIndx;
			break;
		}
	}

	return BlkIndx;
}

/***************************************************************************************************
** Function         : FLSHM_EraseAppReq

** Description      : Requests flash manager to erase application

** Parameter        : FlashEraseAddress : Flash start address to be erased
** 					  FlashEraseSize	: Flash Size to be erased
** Return value     : FLSHM_ProgStat_t : Flash manager erase request state

** Remarks          : None
***************************************************************************************************/
FUNC(FLSHM_ProgStat_t, FLASHM_CODE) FLSHM_EraseAppReq(VAR(uint32, FLASHM_DATA) FlashEraseAddress, VAR(uint32, FLSHM_DATA) FlashEraseEndAddr)
{
	VAR(FLSHM_ProgStat_t, AUTOMATIC) retVal 	= FLSHM_INPROGRESS;

	/* Validate the address requested */
	if (FLSHM_ValidteReqAddress(FlashEraseAddress, FlashEraseEndAddr) == TRUE)
	{
		/* Copy the erase start address requested */
		FLSHM_EraseStartAddress	= FlashEraseAddress;

		/* Copy the erase end address requested */
		FLSHM_EraseEndAddress = FlashEraseEndAddr;

		/* Erase in progress */
		FLSHM_CmdStat	= FLSHM_INPROGRESS;

		/* Change to erase requested */
		FLSHM_FlshMngrState		= FLASHMGR_ERASE_REQ;
	}
	else
	{
		/* Erase address requested in invalid */
		retVal = FLSHM_VERFIYFAILED;
	}

	return retVal;
}
uint32 address;
/***************************************************************************************************
** Function         : FLSHM_ProgramReq

** Description      : Requests flash manager to enter Programming state

** Parameter        : Address			: Flash address to be programmed
** 					  Size				: Flash Size to be programmed
** Return value     : FLSHM_ProgStat_t	: Flash manager erase request state

** Remarks          : None
***************************************************************************************************/
FUNC(FLSHM_ProgStat_t, FLSHM_CODE) FLSHM_ProgramReq(VAR(uint32, AUTOMATIC) Address, VAR(uint32, AUTOMATIC) Size)
{
	VAR(FLSHM_ProgStat_t, AUTOMATIC) retVal 	= FLSHM_INPROGRESS;

	/* Validate the id the address requested  is application*/
	if (FLSHM_ValidteReqAddress(Address, Size) == TRUE)
	{
		/* Check if erase already done */
		if (FLASHMGR_ERASE_DONE == FLSHM_FlshMngrState)
		{
			FLSHM_CurrentBlock = FLSHM_FindBlockIndx(Address, Size);

			/* Copy the Program start address requested */
			FLSHM_ProgStartAddress	= Address;

			FLSHM_ProgCurrntAddress = Address;

			/* Copy the Program end address requested */
			FLSHM_ProgEndAddress	= (Address + Size);

                        /* Reset download sequence counter */
                        Flash_DwnldSeqCntr		= FLSHM_ZERO;

			/* Program in progress */
			FLSHM_CmdStat = FLSHM_INPROGRESS;
			/* Change to Program memory */
			FLSHM_FlshMngrState		= FLASHMGR_PROGRAM;
		}
		else
		{
			/* Erase is not performed */
			retVal = FLSHM_VERFIYFAILED;
		}
	}
	else
	{
		/* ?oInvalid address requested */
		retVal = FLSHM_VERFIYFAILED;
	}

	return retVal;
}

/***************************************************************************************************
** Function         : FLSHM_StateMachine

** Description      : Flash manager state machine

** Parameter        : None
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void,FLSHT_CODE)	FLSHM_StateMachine(void)
{
	bool status = false;
	// VAR(uint8, AUTOMATIC) Return_Val;

	/* Switch to Flash Manager state */
	switch (FLSHM_FlshMngrState)
	{
		/* Flash Manager Idle */
		case FLASHMGR_IDLE:
		{
			/* Do nothing */
			break;
		}
		/* Flash erase requested */
		case FLASHMGR_ERASE_REQ:
		{
			/* store the erase start block */
			FLSHM_EraseCurrAddr	= FLSHM_EraseStartAddress;

            FLSHM_FlshMngrState = FLASHMGR_ERASE;

			break;
		}
		/* Erase the Flash */
		case FLASHMGR_ERASE:
		{
			/* Till the erase request last block */
			if (FLSHM_EraseCurrAddr <= FLSHM_EraseEndAddress)
			{
				/* Erase the requested block */
				if(asdk_flashm_cbk.asdk_flashm_erase_cbk_fun != NULL)
				{
					status = asdk_flashm_cbk.asdk_flashm_erase_cbk_fun( FLSHM_EraseCurrAddr, PFLASH_SECTOR_SIZE);
				}
				/* Erase status */
				if (status)
				{
					/* Erase success, Point to next Erase Address */
					FLSHM_EraseCurrAddr += PFLASH_SECTOR_SIZE;
				}
				else
				{
					/* Erase failed */
					FLSHM_CmdStat = FLSHM_ERASEFAILED;
					FLSHM_FlshMngrState = FLASHMGR_IDLE;
				}
			}
			else
			{
				/* Erase is successful */
				FLSHM_CmdStat = FLSHM_SUCCESS;

				/* To Erase the validity requested block address */
				if(asdk_flashm_cbk.asdk_flashm_erase_cbk_fun != NULL)
				{
					if (FLSHM_EraseStartAddress == FLSHM_SBL_START_ADDRS)
						(void)asdk_flashm_cbk.asdk_flashm_erase_cbk_fun (FLSHM_SBL_VALID_ADDR, PFLASH_SECTOR_SIZE);
					else
						(void)asdk_flashm_cbk.asdk_flashm_erase_cbk_fun (FLSHM_DL_VALID_ADDR, PFLASH_SECTOR_SIZE);
				}
				FLSHM_FlshMngrState = FLASHMGR_ERASE_DONE;
			}
			break;
		}
		/* Erase is successful */
		case FLASHMGR_ERASE_DONE:
		{
			/* Do nothing, Expecting Request download */
			break;
		}
		/* Flash programming state */
		case FLASHMGR_PROGRAM:
		{
			/* Program main schedule */
			FLSHM_CmdStat = FLSHM_ProgrammMain();

			/* Program status */
			if ((FLSHM_SUCCESS == FLSHM_CmdStat) || (FLSHM_INPROGRESS == FLSHM_CmdStat))
			{
				/* Flash success */
				FLSHM_CmdStat = FLSHM_SUCCESS;
			}
			else
			{
				/* Program error */
				FLSHM_FlshMngrState = FLASHMGR_IDLE;
			}
			break;
		}
		case FLASHMGR_PROGRAM_DONE:
		{
			/* Programming done, Waiting for Validation */
			break;
		}
		case FLASHMGR_VERIFY:
		{
			/* Application downloaded image validation pass */
			if (FLSHM_DWNLD_VLDN_PASS == FLSHM_GetAppValdnStat())
			{
				FLSHM_CurrentBlock = FLSHM_FindBlockIndx(FLSHM_ProgStartAddress, (FLSHM_ProgEndAddress - FLSHM_ProgStartAddress));

				/* Update the Validation header */
				FLSHM_UpdateAppValdnHdr(FLSHM_CurrentBlock, FLSHM_CalctdCRC , FLSHM_ProgEndAddress - FLSHM_ProgStartAddress);

				/* Flash success */
				FLSHM_FlshMngrState = FLASHMGR_IDLE;
			}
			/* Application downloaded image validation pass */
			else if(FLSHM_DWNLD_VLDN_FAIL== FLSHM_GetAppValdnStat())
			{
				/* Flash failed */
				FLSHM_FlshMngrState = FLASHMGR_IDLE;
			}
			else if(FLSHM_DWNLD_VLDN_RUNNING != FLSHM_GetAppValdnStat())
			{
				/* Validation Not running */
				FLSHM_FlshMngrState = FLASHMGR_IDLE;
			}
			else
			{
			  /* Validation inprogress */
			}
			break;
		}
		default :
		{
                        /* Reset the flash manager */
			FLSHM_FlshMngrState = FLASHMGR_IDLE;
			break;
		}
	}
}

/***************************************************************************************************
** Function         : Flash_ProgramApp

** Description      : Programs the application code if packet is received

** Parameter        : Dst : Destination address to be programmed
** 					  Src : Source address of data to be programmed
** 					  Chunksize: Size of the Block to be programmed
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(FLSHM_ProgStat_t, FLSHM_CODE) Flash_ProgramApp(uint32  *Dst, uint8 *Src, uint16 Chunksize)
{
	FLSHM_ProgStat_t	ret = FLSHM_SUCCESS;
	// uint8 retval = 0;
	address = (uint32)Dst;
	Source = Src;
	size = Chunksize;
	bool status = false;

	/* Validate the Address */
    if((address >= (uint32)FLSHM_BlockInfo[FLSHM_CurrentBlock].BlockStartAddress) && (address <= (uint32)(FLSHM_BlockInfo[FLSHM_CurrentBlock].BlockEndAddress)))  /* Application Range */
    {
	/* Write the requested chunk of data */
		/* Write the requested chunk of data */
	if(asdk_flashm_cbk.asdk_flashm_write_cbk_fun  != NULL)
	{
		status = asdk_flashm_cbk.asdk_flashm_write_cbk_fun ( (uint32)address, Chunksize, (void *)Src);
	}

	/* Enable the global interrupts */

        /*Flash write status */
        if (status)
        {
                /* Flash write success */
                ret = FLSHM_SUCCESS;
        }
        else
        {
                /* Flash write failed */
                ret = FLSHM_PROGFAILED;
        }
	}
	else
	{
		/* Invalid address write request */
		ret = FLSHM_WRONGADDRESS;
	}

	return ret;
}

/***************************************************************************************************
** Function         : FLSHM_ProgrammMain

** Description      : Polls for the new packet arrival for Application programming

** Parameter        : None
**
** Return value     : FLSHM_ProgStat_t : Flash manager Status

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(FLSHM_ProgStat_t,FLSHM_CODE) FLSHM_ProgrammMain(void)
{
	FLSHM_ProgStat_t retVal;

    FLSHM_ProgStat_t ret = FLSHM_INPROGRESS;

	/* Check if the program buffer is filled */
	if (PROG_TRUE == FLSHM_ProgramBuff_Full)
	{
		/* Program the chunk of data */
		retVal = Flash_ProgramApp((uint32  *)FLSHM_ProgCurrntAddress, (uint8 *)FLSHM_ProgramBuff, FlshMWriteReqSize);

		/* Flash status */
                if(retVal != FLSHM_SUCCESS)
                {
                    /* Program failed */
                    ret = FLSHM_PROGFAILED;
                }
                else
                {
					/* Point the next flash chunk */
					FLSHM_ProgCurrntAddress += FlshMWriteReqSize;

					/* Program failed */
                    ret = FLSHM_SUCCESS;
                }

		/* Check if program request is completed  */
		if ((uint32)FLSHM_ProgCurrntAddress >= (uint32)FLSHM_ProgEndAddress)
		{
			FLSHM_FlshMngrState = FLASHMGR_PROGRAM_DONE;
		}

		/* Clear the program buffer */
		FLSHM_ClearBuff(FLSHM_ProgramBuff, TRANSFERDATA_BLOCKSIZE);

		/* Clear the buffer full flag */
		FLSHM_ProgramBuff_Full = PROG_FALSE;
	}
	else
	{
		/* Do nothing .. download in progress */
	}

	return ret;
}

/***************************************************************************************************
** Function         : FLSHM_WritePacketReq

** Description      : Receives the packet and stores it in local buffer

** Parameter        : DwnldSeqCntr : Download sequence counter
** 					: SrcBuff : Source buffer where the data to be copied
** 					: len: Length of the data to be copied
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(FLSHM_ProgStat_t,FLSHT_CODE) FLSHM_WritePacketReq(uint16 DwnldSeqCntr, uint8 *SrcBuff, uint16 len)
{
    uint8 *dstPtr = FLSHM_ProgramBuff;
    uint16 lent;
	(void)DwnldSeqCntr;

	if (len == FLSHM_ZERO)
		return FLSHM_PROGFAILED;

    /* Read the length */
    lent = len;
    /* Run till the length */
    while(lent != FLSHM_ZERO)
    {
    	/* Copy the data byte */
       *dstPtr++ = *SrcBuff++;
       lent--;
    }

    /* Save the download sequence counter */
    Flash_DwnldSeqCntr++;

    FlshMWriteReqSize = len;

    if (FLSHM_ZERO != (FlshMWriteReqSize % FLSHM_EIGHT))
    {
		FlshMWriteReqSize = (FLSHM_EIGHT - (FlshMWriteReqSize % FLSHM_EIGHT));
    }

    /* Indicate packet is received */
    FLSHM_ProgramBuff_Full = PROG_TRUE;

    /* REturn packet is received */
    return FLSHM_SUCCESS;
}


/***************************************************************************************************
** Function         : FLSHM_ClearBuff

** Description      : Clears the buffer

** Parameter        : Buff: Buffer to be cleared
** 					: size: Size of the buffer
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void,FLSHT_CODE) FLSHM_ClearBuff(uint8 *Buff, uint16 Buff_size)
{
    /* Run till the size */
    while(Buff_size > FLSHM_ZERO)
    {
		/* Clear the byte */
		*Buff++ = FLSHM_ZERO;
		Buff_size--;
    }
}

/***************************************************************************************************
** Function         : FLSHM_CalcCRC

** Description      : Calculates the CRC

** Parameter        : Address : From where the CRC to be calculated
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(uint32, FLSHM_CODE) FLSHM_CalcCRC(uint32 Address, uint32 CRC_size)
{
	uint32 byte;
	uint8 Index;
	uint32 Mask;

	/* Till the requested size */
	while (CRC_size > FLSHM_ZERO)
	{
		byte = (uint32)*((uint8 *)Address);

		FLSHM_CalctdCRC  ^= (uint32)byte;

		for(Index = FLSHM_EIGHT; Index > FLSHM_ZERO; Index--)
		{
			Mask = -(FLSHM_CalctdCRC  & FLSHM_ONE);

			FLSHM_CalctdCRC  = (FLSHM_CalctdCRC  >> FLSHM_ONE) ^ (FLSHM_CRC_POLYNML & Mask);
		}

		Address++;

		CRC_size--;
	}

	/* Result should be inverted at the end of calculation */
	//FLSHM_CalctdCRC = ~FLSHM_CalctdCRC;

	return FLSHM_CalctdCRC ;

}
#if 0

/***************************************************************************************************
** Function         : FLSHM_CalcCRC

** Description      : Calculates the CRC

** Parameter        : Address : From where the CRC to be calculated
**
** Return value     : None

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(void, FLSHM_CODE) FLSHM_CalcCheckSum(uint32 Address, uint32 size)
{
	uint8 byte;
	uint8 *AddressU8;

	AddressU8 = (uint8 *)Address;
	while(size > 0)
	{
		byte = *AddressU8;

		FLSHM_CalctdCRC  += byte;

		AddressU8++;
		size--;
	}
}
#endif
/***************************************************************************************************
** Function         : FLSHM_UpdateAppValdnHdr

** Description      : Updates the validation header

** Parameter        : None
**
** Return value     : FLSHM_ProgStat_t :  Flash status

** Remarks          : None
***************************************************************************************************/
STATIC FUNC(FLSHM_ProgStat_t, FLSHM_CODE) FLSHM_UpdateAppValdnHdr(uint8 Block, uint32 RxdCRC, uint32 Size)
{
	FLSHM_ProgStat_t ret = FLSHM_PROGFAILED;
	// uint8 retval = 0;
	FLSHM_Valid_Header_t	ValidInfo;
	bool status = false;

	/* Check if the requested block is valid */
	if (Block < FLSHM_NUM_OF_BLOCKS)
	{
		/* Store the calculated CRC */
		ValidInfo.Crc = RxdCRC;
		ValidInfo.ImageSize = Size;

		/* Flash the header */
		if(asdk_flashm_cbk.asdk_flashm_write_cbk_fun != NULL)
		{
			status = asdk_flashm_cbk.asdk_flashm_write_cbk_fun (FLSHM_BlockInfo[Block].BlockValiFlgAdd, sizeof(FLSHM_Valid_Header_t), (uint8 *)&ValidInfo);
		}

		/* Check if the flash success */
		if (status)
		{
			/* Flash success */
			ret = FLSHM_SUCCESS;
		}
		else
		{
			/* Flash fail */
			ret = FLSHM_VERFIYFAILED;
		}
	}
	else
	{
		/* Invalid image */
		ret = FLSHM_VERFIYFAILED;
	}

	return ret;
}

/***************************************************************************************************
** Function                 : FLSHM_AppValdnStateMnger

** Description              : Flash manager Application validation state manager

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_AppValdnStateMnger(void)
{
	switch(FLSHM_ValdnState)
	{
		case FLSHM_APPVALDN_IDLE:
		{
			/* Do nothing */
			break;
		}
		/* Request to start the validation of logical blocks */
		case FLSHM_APPVALDN_REQ:
		{
			/* Point to the first logical block */
			FLSHM_ValidnBlk = FLSHM_ZERO;

			/* Get the CRC hearder information */
			FLSHM_ValidHeadVal = *((FLSHM_Valid_Header_t  *)FLSHM_BlockInfo[FLSHM_ValidnBlk].BlockValiFlgAdd);

			/*Check if application has been erased before */
			if ((FLSHM_ValidHeadVal.ImageSize != 0xFFFFFFFF) && (FLSHM_ValidHeadVal.ImageSize != 0x00)
					&& (FLSHM_ValidHeadVal.ImageSize <= (FLSHM_APP_END_ADDRS - FLSHM_APP_START_ADDRS + 1U)) )

			{
				/*Get the validation start address */
				FLSHM_ValdnCurrAddress = FLSHM_BlockInfo[FLSHM_ValidnBlk].BlockStartAddress; // + sizeof(FLSHM_Valid_Header_t);

				/* Get the validation image size */
				FLSHM_VldnSize = FLSHM_ValidHeadVal.ImageSize ; //- sizeof(FLSHM_Valid_Header_t);

				/* initialize the CRC */
				FLSHM_CalctdCRC  = 0U;

				/* Change the state to start calculating CRC */
				FLSHM_ValdnState = FLSHM_APPVALDN_RUNNING;
			}
			else
			{
				/* No valid application present */
				FLSHM_ValdnState = FLSHM_APPVLDN_FAIL;
			}
			break;
		}
		/* Request to start the validation of downloaded image */
		case FLSHM_DWNLD_VLDN_REQ:
		{
			/* Validate only downloaded image */
			FLSHM_ValidnBlk = 0xFF;

			/* initialize the CRC */
			FLSHM_CalctdCRC  = 0x0U;

			/* Start validation the downloaded image */
			FLSHM_ValdnState = FLSHM_DWNLD_VLDN_RUNNING;
			break;
		}
		case FLSHM_DWNLD_VLDN_RUNNING:
		{
			/* Check id reached the end of the image */
			if (FLSHM_VldnSize > FLSHM_ZERO)
			{
				/* Validate the image in a slot basis */
				if (FLSHM_VldnSize >= FLSHM_CRC_CALSLOT_SIZE)
				{
					/* Calculate the CRC for the requested slot */
					FLSHM_CalcCRC(FLSHM_ValdnCurrAddress, FLSHM_CRC_CALSLOT_SIZE);

					/* point to the next slot of memory */
					FLSHM_ValdnCurrAddress += FLSHM_CRC_CALSLOT_SIZE;

					/* get the next size*/
					FLSHM_VldnSize -= FLSHM_CRC_CALSLOT_SIZE;
				}
				else
				{
					/* Calculate the CRC for the last slot */
					FLSHM_CalcCRC(FLSHM_ValdnCurrAddress, FLSHM_VldnSize);

					FLSHM_VldnSize = FLSHM_ZERO;
				}
			}
			else
			{
				/* Compare the stored/received CRC with calculated */
				if ((uint32)FLSHM_CalctdCRC == (uint32)FLSHM_ValidHeadVal.Crc)
				{
					FLSHM_ValdnState = FLSHM_DWNLD_VLDN_PASS;

					FLSHM_CurrentBlock = FLSHM_FindBlockIndx(FLSHM_ProgStartAddress, (FLSHM_ProgEndAddress - FLSHM_ProgStartAddress));
					/* Update the Validation header */
					FLSHM_UpdateAppValdnHdr(FLSHM_CurrentBlock, FLSHM_CalctdCRC , (FLSHM_ProgEndAddress - FLSHM_ProgStartAddress));
					/* Write Reprog request only while updating application */
					if (FLSHM_BlockInfo[FLSHM_CurrentBlock].BlockValiFlgAdd == FLSHM_DL_VALID_ADDR)
						FLSHM_ReqReprog();
				}
				else
				{
					FLSHM_ValdnState = FLSHM_DWNLD_VLDN_FAIL;
				}
			}
			break;
		}
		/* Validating the image */
		case FLSHM_APPVALDN_RUNNING:
		{
			/* Validate the blocks */
			if ((FLSHM_ValidnBlk < FLSHM_NUM_OF_BLOCKS) || (FLSHM_ValidnBlk == 0xFF))
			{
				/* Check id reached the end of the image */
				if (FLSHM_VldnSize > FLSHM_ZERO)
				{
					/* Validate the image in a slot basis */
					if (FLSHM_VldnSize >= FLSHM_CRC_CALSLOT_SIZE)
					{
						/* Calculate the CRC for the requested slot */
						FLSHM_CalcCRC(FLSHM_ValdnCurrAddress, FLSHM_CRC_CALSLOT_SIZE);

						/* point to the next slot of memory */
						FLSHM_ValdnCurrAddress += FLSHM_CRC_CALSLOT_SIZE;

						/* get the next size*/
						FLSHM_VldnSize -= FLSHM_CRC_CALSLOT_SIZE;

					}
					else
					{
						/* Calculate the CRC for the last slot */
						FLSHM_CalcCRC(FLSHM_ValdnCurrAddress, FLSHM_VldnSize);

						FLSHM_VldnSize = FLSHM_ZERO;
					}
				}
				else
				{

					/* Compare the stored/received CRC with calculated */
					if ((uint32)FLSHM_CalctdCRC  == (uint32)FLSHM_ValidHeadVal.Crc)
					{
						/* Check if the request is for downloaded image */
						if (FLSHM_ValidnBlk == 0xFF)
						{
							/* This lets the state change to Pass */
							FLSHM_ValidnBlk = FLSHM_NUM_OF_BLOCKS;
						}
						else
						{
							/* Start calculating the next block validity */
							FLSHM_ValidnBlk++;

							/* Check if all blocks are reached */
							if (FLSHM_ValidnBlk < FLSHM_NUM_OF_BLOCKS)
							{
								/* Get the validation header */
								FLSHM_ValidHeadVal = *((FLSHM_Valid_Header_t *)FLSHM_BlockInfo[FLSHM_ValidnBlk].BlockValiFlgAdd);

								if (FLSHM_ValidHeadVal.ImageSize != 0xFFFFFFFFU)
								{
									  /*Get the validation start address */
									  FLSHM_ValdnCurrAddress = FLSHM_BlockInfo[FLSHM_ValidnBlk].BlockStartAddress;// + sizeof(FLSHM_Valid_Header_t);

									  /* Get the validation image size */
									  FLSHM_VldnSize = FLSHM_ValidHeadVal.ImageSize;// - sizeof(FLSHM_Valid_Header_t);

									  /* initialize the CRC */
									  FLSHM_CalctdCRC  = 0u;
								}
								else
								{
									  /* No valid application available at next block */
									  FLSHM_ValdnState = FLSHM_APPVLDN_FAIL;
								}
							}
							else
							{
								/* Do nothing */
							}
                        }
					}
					else
					{
						/* CRC did not match and validation failed */
						FLSHM_ValdnState = FLSHM_APPVLDN_FAIL;
					}
				}
			}
			else
			{
				/* CRC validation successful */
				FLSHM_ValdnState = FLSHM_APPVLDN_PASS;
			}
			break;
		}
		case FLSHM_APPVLDN_FAIL:
		{
			/* Do nothing */
			break;
		}
		case FLSHM_APPVLDN_PASS:
		{
			/* Do nothing */
			break;
		}
		case FLSHM_DWNLD_VLDN_FAIL:
		{
			/* Do nothing */
			break;
		}
		case FLSHM_DWNLD_VLDN_PASS:
		{
			/* Do nothing */
			break;
		}
		default:
		{
			FLSHM_ValdnState = FLSHM_APPVALDN_IDLE;
			break;
		}
	}
}

/***************************************************************************************************
** Function                 : FLSHM_GetAppValdnStat

** Description              : Flash manager Get the application validation status

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(FLSHM_AppVldnStat_t, FLSHM_CODE) FLSHM_GetAppValdnStat(void)
{
	return FLSHM_ValdnState;
}

/***************************************************************************************************
** Function                 : FLSHM_StartAppValdn

** Description              : Flash manager Start Application validation

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_StartAppValdn(void)
{
	/* Change the state to validate all the logical blocks */
	FLSHM_ValdnState = FLSHM_APPVALDN_REQ;
}

/***************************************************************************************************
** Function                 : FLSHM_StartDwnlValdn

** Description              : Flash manager Start validating the downloaded Image

** Parameter                : None

** Return value             : FLSHM_ProgStat_t

** Remarks                  : None
***************************************************************************************************/
FUNC(FLSHM_AppVldnStat_t, FLSHM_CODE) FLSHM_StartDwnlValdn(VAR(uint32, FLASHM_DATA) FlashStrtAddress, VAR(uint32, FLSHM_DATA) FlashEndAddress, VAR(uint32, FLSHM_VAR) CheckSum)
{
	/* Change the validation state to Validation req */
	FLSHM_ValdnState = FLSHM_DWNLD_VLDN_REQ;

	/* Save the received CRC */
	FLSHM_ValidHeadVal.Crc = CheckSum;

	FLSHM_ValdnCurrAddress = FlashStrtAddress;

	FLSHM_VldnSize = FlashEndAddress - FlashStrtAddress + FLSHM_ONE;

	/* If flash program is downloaded is done before */
	if (FLASHMGR_PROGRAM_DONE == FLSHM_FlshMngrState)
	{
		/* Change the state to Verify Program downloaded */
		FLSHM_FlshMngrState = FLASHMGR_VERIFY;
	}
	else
	{
	  /* Do nothing */
	}

	return FLSHM_APPVALDN_REQ_ACCEPT;
}

/***************************************************************************************************
** Function                 : FLSHM_ResetAppValdnStat

** Description              : Resets the CRC validation state to Idle

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_ResetAppValdnStat(void)
{
	/* Reset the Validation manager ot Idle */
	FLSHM_ValdnState = FLSHM_APPVALDN_IDLE;
}

/***************************************************************************************************
** Function                 : FLSHM_GetCMDStatus

** Description              : Get Flash command status

** Parameter                : None

** Return value             : FLSHM_SUCCESS
**                              FLSHM_ERASEFAILED
**                              FLSHM_WRONGADDRESS

** Remarks                  : None
***************************************************************************************************/
FLSHM_ProgStat_t FLSHM_GetCMDStatus(void)
{
    return FLSHM_CmdStat;
}

/***************************************************************************************************
** Function                 : FLSHM_GetFlashState

** Description              : Get flash current state

** Parameter                : None

** Return value             : FlashMgr_State

** Remarks                  : None
***************************************************************************************************/
FLSHM_FlshMngrState_t FLSHM_GetFlashState(void)
{
    return FLSHM_FlshMngrState;
}

/***************************************************************************************************
** Function                 : FLSHM_GetCheckSum

** Description              : Get CheckSumCalculated

** Parameter                : None

** Return value             : FlashMgr_State

** Remarks                  : None
***************************************************************************************************/
uint16 FLSHM_GetCheckSum(void)
{
    return (uint32_t)FLSHM_CalctdCRC;
}
