/*******************************************************************************
**
** -----------------------------------------------------------------------------
** File Name    : ISOUDS_RdDTCInf.h
**
** Description  : Include component of ISOUDS_RdDTCInf.c
**
** -----------------------------------------------------------------------------
**
*******************************************************************************/
/* To avoid multi-inclusions */
#ifndef ISOUDS_RDDTCINF_H
#define ISOUDS_RDDTCINF_H

/************************************* Inclusion files ************************/
#include "ISOUDS.h"

/************************** Declaration of global symbol and constants ********/

/********************************* Declaration of global macros ***************/
typedef enum
{
	reportNumberOfDTCByStatusMask = 0x01,
	reportDTCByStatusMask = 0x02,
	reportDTCSnapshotIdentification = 0x03,
	reportDTCSnapshotRecordByDTCNumber = 0x4,
	reportDTCStoredDataByRecordNumber = 0x5,
	reportDTCExtDataRecordByDTCNumber = 0x6,
	reportNumberOfDTCBySeverityMaskRecord = 0x7,
	reportDTCBySeverityMaskRecord = 0x8,
	reportSeverityInformationOfDTC = 0x9,
	reportSupportedDTC = 0x0A,
	reportFirstTestFailedDTC = 0x0B,
	reportFirstConfirmedDTC = 0x0C,
	reportMostRecentTestFailedDTC = 0x0D,
	reportMostRecentConfirmedDTC = 0x0E,
	reportMirrorMemoryDTCByStatusMask = 0x0F,
	reportMirrorMemoryDTCExtDataRecordByDTCNumber = 0x10,
	reportNumberOfMirrorMemoryDTCByStatusMask = 0x11,
	reportNumberOfEmissionsOBDDTCByStatusMask = 0x12,
	reportEmissionsOBDDTCByStatusMask = 0x13,
	reportDTCFaultDetectionCounter = 0x14,
	reportDTCWithPermanentStatus = 0x15,
	reportDTCExtDataRecordByRecordNumber = 0x16,
	reportUserDefMemoryDTCByStatusMask = 0x17,
	reportUserDefMemoryDTCSnapshotRecordByDTCNumber = 0x18,
	reportUserDefMemoryDTCExtDataRecordByDTCNumber = 0x19,
	reportWWHOBDDTCByMaskRecord = 0x42,
	reportWWHOBDDTCWithPermanentStatus = 0x55
}ISOUDS_RdDTCSubfn_e;

/********************************* Declaration of global types ****************/
/* SID of Read Diagnostic Information session service */
#define     ISOUDS_SIDRDDTCINF      (0x19)
#define		ISOUDS_RDDTCLEN			0x01

#define RDDTCINFSRVLEN 				        		(uint16)0x03
#define RDDTCINFSRVSNPSHTLEN 		                (uint8)0x06
#define RDDTCINFSRVSRPTSPRTDTCLEN 	                (uint8)0x02
#define RDDTCINFSRVREP_NO_DTC_BY_SEV_MASK_REC_LEN 	(uint8)0x04
#define RDDTCINFSRVREP_DTC_BY_SEV_MASK_REC_LEN 	    (uint8)0x04
#define RDDTCINFSRVREP_SEVTY_INFO_OF_DTC 	        (uint8)0x05
#define RDDTCINF_USR_DFND_MEMORY_LEN        		(uint8)0x07
#define RDDTCINF_FIRST_MOST_LEN                     (uint8)0x02 
#define RDDTCINF_FIRST_MOST_RESP_LEN                (uint8)0x04 
#define RDDTCINF_MIRROR_MEMORY_LEN                  (uint8)0x03 
#define RDDTCINF_EXT_DATA_LEN                      	(uint8)0x06
#define RDDTCINF_EMISSION_DTC_LEN                 	(uint8)0x03
#define RDDTCINF_FAULT_DETC_LEN                 	(uint8)0x02  
#define RDDTCINF_DTC_WITH_PRMNT_LEN                 (uint8)0x02
#define RDDTCINF_USR_DFN_MEM_LEN                 	(uint8)0x04
#define RDDTCINF_WWH_OBD_MASK_LEN                 	(uint8)0x05
#define RDDTCINF_WWH_OBD_PARM_LEN                 	(uint8)0x03 

/****************************** External links of global variables ************/

/****************************** External links of global constants ************/

/*******************************************************************************
**                                      FUNCTIONS                              *
*******************************************************************************/

/********************************** Function definitions **********************/
extern void ISOUDS_RdDTCInf (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[]);

#endif  /* ISOUDS_RDDTCINF_H */
