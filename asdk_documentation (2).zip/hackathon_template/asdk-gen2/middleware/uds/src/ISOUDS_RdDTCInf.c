/*******************************************************************************
**
** -----------------------------------------------------------------------------
** File Name    : ISOUDS_RdDTCInf.c
**
** Description : This service Reads DTC Information
**
** -----------------------------------------------------------------------------
**
*******************************************************************************/

/**************************************** Inclusion files *********************/
#include "Platform_Types.h"
#include "ISOUDS_RdDTCInf.h"
#include "ISOUDS_RdDTCInf_Cfg.h"
#include "Fcm_cfg.h"
/************************** Declaration of local symbol and constants *********/

/********************************* Declaration of local macros ****************/
    													

/********************************* Declaration of local types *****************/

/******************************* Declaration of local variables ***************/

/******************************* Declaration of local constants ***************/

/****************************** Declaration of exported variables *************/

/****************************** Declaration of exported constants *************/

/*******************************************************************************
**                                      FUNCTIONS                              *
*******************************************************************************/

/**************************** Internal functions declarations *****************/

/******************************** Function definitions ************************/

/*******************************************************************************
** Function                 : ISOUDS_RdDTCInf

** Description              : This service allows the tool to read the status of 
							  Diagnostic Trouble
                              Code (DTC) information from any ECU.

** Parameter ISOUDSConfPtr  : Pointer to service configuration structure

** Parameter databuff       : service data buffer

** Return value             : None
*******************************************************************************/
void ISOUDS_RdDTCInf (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[])
{
    uint16   idxResp;
    uint16   numDTCs = (uint8)0U;
    uint32   DTCInf;
    uint8  Val_Flag = (uint8)0U;
    uint8 DTCRecNo;
    // uint8 DTCSevMask;
    uint8 DTCStatMask;

	/* read sub-function */
    ISOUDS_RdDTCSubfn_e rdDTCSubFun = dataBuff[0];

    if (ISOUDSConfPtr->srvSt == (uint8)ISOUDS_RXMSG)
    {
		if (ISOUDSConfPtr->srvLen > ISOUDS_RDDTCLEN)
		{

			/* Check for subfunction */
			switch(rdDTCSubFun)
			{
				case reportNumberOfDTCByStatusMask:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVLEN)
					{
						/* If RdDTCInf request is for sub function reportDTCByStatusMask */
				
						/* read status mask */
						DTCStatMask = dataBuff[1];	
						
						/* supported bits DTC status mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Get the number of faults matching status mask */
						numDTCs = ISOUDS_RdDTC_ReportNoOfDTCByStatusMask(DTCStatMask);
						
						/* DTC Format Identifier  = SO_14229-1_DTCFormat */
						dataBuff[2] = 0x01;  
						
						dataBuff[3] = (uint8)((numDTCs >> 8) & 0xFF);
						dataBuff[4] = (uint8)(numDTCs);			
						
						/* Response length for the current Service ID */
						ISOUDSConfPtr->srvLen = 6U;
				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
					}

				break;

				case reportDTCByStatusMask:

					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVLEN)
					{
						/* If RdDTCInf request is for sub function reportDTCByStatusMask */
				
						/* read status mask */
						DTCStatMask = dataBuff[1];
				
						/* supported bits Diag mask into next byte */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS; 
						
						/* Read the DTC matching the status mask into the dataBudd[] */
						idxResp = ISOUDS_RdDTC_ReportDTCByStatusMask(DTCStatMask, dataBuff + 2);

						/* Response length for the current Service ID */
						ISOUDSConfPtr->srvLen = idxResp + 3U;
				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
					}
				break;

				case reportDTCSnapshotIdentification:
					// RDDTCINFSRVSNPSHTLEN
					// Here we are using only one record number. reportDTCSnapshotRecordByDTCNumber covers to this*/
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportDTCSnapshotRecordByDTCNumber:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVSNPSHTLEN)
					{
						/* read DTC */
						DTCInf = ((uint32)dataBuff[3]) | ((uint32)dataBuff[2] << 8) | ((uint32)dataBuff[1] << 16);
						
						/* Read DTC Snapshot Record */
						DTCRecNo = (uint8)dataBuff[4];
						
						/* initialize number of bytes in response counter */
						idxResp = (uint8)0;
						
						/* Read DTC Record data by number and its validity Valid */	
						Val_Flag = ISOUDS_RdDTC_GetDTCSnpShotRecdByDTCnum(DTCInf, DTCRecNo, &dataBuff[1], &idxResp); 
												
						/* if DTC Record number is valid  */
						if(TRUE == Val_Flag)
						{			
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = idxResp + 2U;
						
							/* Send positive response */
							ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
						}
						else
						{
							/* Negative response */
							ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
						
							/* Invalid Message Length Or Invalid Format */
							ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_ROOR;
						}				
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
					}				
				break;

				case reportDTCStoredDataByRecordNumber:
					/* Here we are using only one record number. reportSupportedDTC covers to this */ 
					// RDDTCINFSRVLEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportDTCExtDataRecordByDTCNumber:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVSNPSHTLEN)
					{
						/* read DTC */
						DTCInf = ((uint32)dataBuff[3]) | ((uint32)dataBuff[2] << 8) | ((uint32)dataBuff[1] << 16);
                        /* Need to get the Clarification on Byte Order: Mayank */
                                        
                        /* Read Record number */
                        DTCRecNo = (uint8)dataBuff[4];
                                          
                        /* initialize number of bytes in response counter */
                        idxResp = (uint8)0;
                                           
                        /* Read DTC Record data by number and its validity Valid */     
                        Val_Flag = ISOUDS_RdDTC_GetDTCSnpShotExtRecdByDTCnum(DTCInf, DTCRecNo, &dataBuff[1], &idxResp);
                        /* if DTC is valid and Index is lesser than Number of DTC's */
                        if(TRUE == Val_Flag)
                        { 
							/* Need to get the Clarification on Byte Order: Mayank ISOUDS_RdDTC_ReportSupportedDTCs */
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = idxResp + 2;
				
							/* Send positive response */
							ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
						}
						else
						{
							/* Negative response */
							ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
							/* Invalid Message Length Or Invalid Format */
							ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_ROOR;
						}
					}					
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
					}				
				break;

				case reportNumberOfDTCBySeverityMaskRecord:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVREP_NO_DTC_BY_SEV_MASK_REC_LEN)
					{
						#if 0
						DTCSevMask = dataBuff[1];										
						DTCStatMask = dataBuff[2];
										
						/* supported bits Diag mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Read the DTC format and DTC count into the beffer */
						idxResp = ISOUDS_RdDTC_ReportNumberOfDTCBySeverityMaskRecord(DTCSevMask, DTCStatMask, dataBuff + 2);

						/* Response length for the current Service ID */
						ISOUDSConfPtr->srvLen = idxResp + 3U;
				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
						#endif
						/* TODO: sub fuction NOT implimented, returning negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* SubFunction not supported */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;					
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}
				break;

				case reportDTCBySeverityMaskRecord:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVREP_DTC_BY_SEV_MASK_REC_LEN)
					{
						#if 0
						DTCSevMask = dataBuff[1];							
						DTCStatMask = dataBuff[2];
											
						/* supported bits Diag mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Read the Load DTC with seviority mask record */
						idxResp = ISOUDS_RdDTC_ReportDTCBySeverityMaskRecord(DTCSevMask, DTCStatMask, dataBuff + 2);
									
						/* Response length for the current Service ID */
						ISOUDSConfPtr->srvLen = idxResp + 3U;
				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
						#endif
						/* TODO: sub fuction NOT implimented, returning negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* SubFunction not supported */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;						
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}				
				break;

				case reportSeverityInformationOfDTC:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVREP_SEVTY_INFO_OF_DTC)
					{
						#if 0
						/* read DTC */
						DTCInf = ((uint32)dataBuff[3]) | ((uint32)dataBuff[2] << 8) | ((uint32)dataBuff[1] << 16);
						/* Need to get the Clarification on Byte Order: Mayank */
						
						/* Read Record number */
						DTCRecNo = (uint8)dataBuff[4];
						
						/* initialize number of bytes in response counter */
						idxResp = (uint8)0;

						/* Read DTC Record data by number and its validity Valid */	
						Val_Flag = ISOUDS_RdDTC_ReportSeverityInformationOfDTC(DTCInf, dataBuff + 2);
						/* if DTC is valid and Index is lesser than Number of DTC's */
						if(TRUE == Val_Flag)
						{      
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = idxResp + 2;
				
							/* Send positive response */
							ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
						}
						else
						{
							/* Negative response */
							ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
							/* Invalid Message Length Or Invalid Format */
							ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_ROOR;
						}	
						#endif
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* SubFunction not supported */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;					
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}				
				break;

				case reportSupportedDTC:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVSRPTSPRTDTCLEN)
					{
						/* supported bits Diag mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Read the DTC matching the status mask into the dataBudd[] */
						idxResp = ISOUDS_RdDTC_ReportSupportedDTCs(dataBuff + 2);
									
						/* Response length for the current Service ID */
						ISOUDSConfPtr->srvLen = idxResp + 3U;
				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}				
				break;

				case reportFirstTestFailedDTC:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVSRPTSPRTDTCLEN)
					{
						/* supported bits Diag mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Read the DTC matching the status mask into the dataBudd[] */
						idxResp = ISOUDS_RdDTC_ReportFirstTestFailed(dataBuff + RDDTCINF_FIRST_MOST_LEN);
									
						if (idxResp == TRUE)
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = RDDTCINF_FIRST_MOST_RESP_LEN +3U;
						}
						else
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = 3U;
						}				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}
				break;

				case reportFirstConfirmedDTC:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVSRPTSPRTDTCLEN)
					{
						/* supported bits Diag mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Read the DTC matching the status mask into the dataBudd[] */
						idxResp = ISOUDS_RdDTC_ReportFirstConfirmed(dataBuff + RDDTCINF_FIRST_MOST_LEN);
									
						if (idxResp == TRUE)
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = RDDTCINF_FIRST_MOST_RESP_LEN +3U;
						}
						else
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = 3U;
						}				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}
				break;

				case reportMostRecentTestFailedDTC:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVSRPTSPRTDTCLEN)
					{
						/* supported bits Diag mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Read the DTC matching the status mask into the dataBudd[] */
						idxResp = ISOUDS_RdDTC_ReportMostRecentTestFailed(dataBuff + RDDTCINF_FIRST_MOST_LEN);
									
						if (idxResp == TRUE)
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = RDDTCINF_FIRST_MOST_RESP_LEN +3U;
						}
						else
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = 3U;
						}				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}				
				break;
			
				case reportMostRecentConfirmedDTC:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINFSRVSRPTSPRTDTCLEN)
					{
						/* supported bits Diag mask */
						dataBuff[1] = FCM_SUPPORTED_DTC_STATUS_BITS;
						
						/* Read the DTC matching the status mask into the dataBudd[] */
						idxResp = ISOUDS_RdDTC_ReportMostRecentConfirmed(dataBuff + RDDTCINF_FIRST_MOST_LEN);
									
						if (idxResp == TRUE)
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = RDDTCINF_FIRST_MOST_RESP_LEN +3U;
						}
						else
						{
							/* Response length for the current Service ID */
							ISOUDSConfPtr->srvLen = 3U;
						}				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}
				break;

				case reportMirrorMemoryDTCByStatusMask:
					// RDDTCINF_MIRROR_MEMORY_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;
				
				case reportMirrorMemoryDTCExtDataRecordByDTCNumber:
					// RDDTCINF_EXT_DATA_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;
				
				case reportNumberOfMirrorMemoryDTCByStatusMask:
					// RDDTCINF_MIRROR_MEMORY_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportNumberOfEmissionsOBDDTCByStatusMask:
					// RDDTCINF_EMISSION_DTC_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportEmissionsOBDDTCByStatusMask:
					// RDDTCINF_EMISSION_DTC_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;
				
				case reportDTCFaultDetectionCounter:
					/* Service execution and response */
					if (ISOUDSConfPtr->srvLen == RDDTCINF_FAULT_DETC_LEN)
					{						
						/* Read the DTC matching the status mask into the dataBudd[] */
						idxResp = ISOUDS_RdDTC_ReportDTCFaultDetectionCounter(dataBuff + 1);

						/* Response length for the current Service ID */
						ISOUDSConfPtr->srvLen =  idxResp + 2U;
				
						/* Send positive response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;			
					}

				break;
				
				case reportDTCWithPermanentStatus:
					// RDDTCINF_DTC_WITH_PRMNT_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportDTCExtDataRecordByRecordNumber:
					// RDDTCINFSRVLEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportUserDefMemoryDTCByStatusMask:
					// RDDTCINF_USR_DFN_MEM_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportUserDefMemoryDTCSnapshotRecordByDTCNumber:
					// RDDTCINF_USR_DFND_MEMORY_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportUserDefMemoryDTCExtDataRecordByDTCNumber:
					// RDDTCINF_USR_DFND_MEMORY_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;

				case reportWWHOBDDTCByMaskRecord:
					// RDDTCINF_WWH_OBD_MASK_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;				
				break;

				case reportWWHOBDDTCWithPermanentStatus:
					// RDDTCINF_WWH_OBD_PARM_LEN
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;				
				break;	

				default :
					/* Negative response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
				
					/* SubFunction not supported */
					ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
				break;															
			}        
		}
		else
		{
			/* Negative response */
			ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

			/* Invalid Message Length Or Invalid Format */
			ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;	
		}
	}
	else
	{
		/* Negative response */
		ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

		/* NRC - Request Sequence Error */
		ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
	}
}
/**************************** Internal Function definitions *******************/
