/***************************************************************************************************
** Copyright (c) 2018 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Fcm.c
** Module Name  : Fault Code Management
** -------------------------------------------------------------------------------------------------
**
** Description : Extracts the information from CAN driver and provides to upper layer and 
**               vice-versa.
**
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  
** - Baseline Created
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "Fcm.h"
#include "stub.h"
#include <stddef.h>
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
#define PRE_TEST_FAILED_MASK 0x5C
/********************************* Declaration of local types *************************************/
asdk_fcm_dtc_cbk_t asdk_fcm_dtc_cbk = {0,};
/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/
/* Variables to store the operation cycle transition information */
static eFCM_OperationCycleType lCurrentOperationCycle[NUMBER_OF_DTC_GROUPS]  = {FCM_OPERATION_CYCLE_STOP, FCM_OPERATION_CYCLE_STOP, FCM_OPERATION_CYCLE_STOP};
static eFCM_OperationCycleType lPreviousOperationCycle[NUMBER_OF_DTC_GROUPS] = {FCM_OPERATION_CYCLE_STOP, FCM_OPERATION_CYCLE_STOP, FCM_OPERATION_CYCLE_STOP};

/* Variable to control the DTC setting */
static eFCM_ControDTCType	FCM_ControlDTCStatus = FCM_DTC_SETTING_ON;
uint8_t FCM_Aging_Flag[FCM_MAXNUM_DTCS];
uint8_t FCM_FindDTCIndexFlg;
FCM_DTCSnpShot_Info FCM_DTCSnapShotInfo[FCM_MAXNUM_DTCS];
FCM_DTCExtndSnpsht_Info FCM_DTCExtndSnapShotInfo[FCM_MAXNUM_DTCS];

/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/

/******************************** Function definitions ********************************************/

/***************************************************************************************************
** Function                 : Fcm_Init

** Description              : This function Initializes FCM parameters

** Parameter                : None

** Return value             : None
***************************************************************************************************/
void FCM_Init(asdk_fcm_dtc_cbk_t *asdk_fcm_dtc_cbk_fun)
{
	uint8_t Indx;
	uint16_t FcmInfoSize;

	/* Reset the Operation cycle */
	for (Indx = 0; Indx <(uint8_t)NUMBER_OF_DTC_GROUPS; Indx++)
	{
		lCurrentOperationCycle[Indx]  = FCM_OPERATION_CYCLE_STOP;
		lPreviousOperationCycle[Indx] = FCM_OPERATION_CYCLE_STOP;
	}
    /* read fault status and Occurrence Count & Aging count from EEPROM */
	/* Expecting an API call from NVM to update DTC data in FCM_DTCInfo variable */
	/* Remove the below for loop once NVM functionality is added */
	FcmInfoSize = sizeof(FCM_DTCInfo);

	/* Assign FCM callback */
	if(asdk_fcm_dtc_cbk_fun != NULL)
	{
		asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun = asdk_fcm_dtc_cbk_fun->asdk_fcm_clear_dtc_cbk_fun;
		asdk_fcm_dtc_cbk.asdk_fcm_update_dtc_cbk_fun = asdk_fcm_dtc_cbk_fun->asdk_fcm_update_dtc_cbk_fun;
		asdk_fcm_dtc_cbk.asdk_fcm_read_dtc_cbk_fun = asdk_fcm_dtc_cbk_fun->asdk_fcm_read_dtc_cbk_fun;
	}
	
	/* Turn the DTC setting control ON */
	FCM_ControlDTCStatus = FCM_DTC_SETTING_ON;
	
	(void)APP_FCM_ReadDTCInfo (&FCM_DTCInfo[0],FcmInfoSize);
	(void)APP_FCM_ReadDTCSnapShotAddInfo(&FCM_DTCSnapShotInfo[0], sizeof(FCM_DTCSnapShotInfo));
	(void)APP_FCM_ReadDTCExtSnapShotAddInfo(&FCM_DTCExtndSnapShotInfo[0], sizeof(FCM_DTCExtndSnapShotInfo));
	
}

/***************************************************************************************************
** Function                 : FCM_FindDTCIndex

** Description              : This function processes Faults status

** Parameter                : FCM_DTC_Number:

** Return value             : FCM_DTC_Idx: DTC Index
***************************************************************************************************/
uint8_t FCM_FindDTCIndex(uint32_t FCM_DTC_Number)
{
	uint16_t DTC_Index;

	/* Loop to detect the DTC index */
	for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
	{
		if (FCM_DTC_Number == FCM_DtcCfg_Tabl[DTC_Index].Fault_Id)
		{
			break;
		}
		else
		{
			/* Do nothing */
		}
	}
	
	return DTC_Index;
}

/***************************************************************************************************
** Function                 : FCM_FindNmDTCIndex

** Description              : This function processes Faults status

** Parameter                : FCM_DTC_Number:

** Return value             : FCM_DTC_Idx: DTC Index
***************************************************************************************************/
uint16_t FCM_FindNmDTCIndex(uint32_t FCM_DTC_Number)
{
	uint16_t DTC_Index;
	
	/* Loop to detect the DTC index */
	for (DTC_Index = NETWORK_DTC_GROUP_START_INDEX; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
	{
		if (FCM_DTC_Number == FCM_DtcCfg_Tabl[DTC_Index].Fault_Id)
		{
			break;
		}
		else
		{
			/* Do nothing */
		}
	}
	return DTC_Index;
}

/***************************************************************************************************
** Function                 : Fcm_NotifyTestResult

** Description              : This function processes Faults status

** Parameter                : FCM_DTC_Idx: DTC Index
                              FCM_FaultSt: Fault Status

** Return value             : None
***************************************************************************************************/
void FCM_NotifyTestResult (uint8_t FCM_DTC_Idx, eFCM_TestResultType FCM_FaultSt)
{
	FCM_DTC_FaultStatusType DTCStatus_Bkp;

	if (FCM_TRUE == appFcmInitStatus())
	{
		/* check if the index is valid */
		if ((FCM_DTC_SETTING_ON == FCM_ControlDTCStatus) && (FCM_DTC_Idx < FCM_MAXNUM_DTCS))
		{
			DTCStatus_Bkp.byte = FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.byte;

			/* check for fault state */
			switch (FCM_FaultSt)
			{
				case FCM_TESTFAIL:
				{
				#if (FCM_TST_FAILED_STAT_SUPT == FCM_TRUE)
					/* Set the test failed status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testFailed = FCM_TRUE;
				#endif
				
				#if (FCM_TST_FAILED_THIS_OPCYCLE_STAT_SUPT == FCM_TRUE)
					/* Set the test failed this operation cycle status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testFailedThisOperationCycle = FCM_TRUE;
				#endif
				
				#if (FCM_PENDING_DTC_STAT_SUPT == FCM_TRUE)
					/* Set the Pending DTC status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.pendingDTC = FCM_TRUE;
				#endif

				#if (FCM_CONFIRMED_DTC_STAT_SUPT == FCM_TRUE)
					if (FCM_DTCInfo[FCM_DTC_Idx].OccurenceCount < FCM_DtcCfg_Tabl[FCM_DTC_Idx].OccurenceThrehlod)
					{
						/* Increment the Occurrence count by the Increment value */
						FCM_DTCInfo[FCM_DTC_Idx].OccurenceCount += FCM_DtcCfg_Tabl[FCM_DTC_Idx].OccIncrmntVal;
					}
					else
					{
						/* Do nothing */
					}

					/* Store the Most recent failed DTC information */
					FCM_MostRecentFailedDTCInfo.Fault_Id = FCM_DTCInfo[FCM_DTC_Idx].Fault_Id;
					FCM_MostRecentFailedDTCInfo.FaultStatus = FCM_DTCInfo[FCM_DTC_Idx].FaultStatus;
							
					/* Check if Occurrence count reached threshold */
					if (FCM_DTCInfo[FCM_DTC_Idx].OccurenceCount >= FCM_DtcCfg_Tabl[FCM_DTC_Idx].OccurenceThrehlod)
					{
						/* Set the Confirmed DTC status bit */
						FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.confirmedDTC = FCM_TRUE;
					#if (FCM_WARNING_INDICATOR_STAT_SUPT == FCM_TRUE)
						/* Set the Warning Indication status bit */
						FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.warningIndicatorRequested = FCM_TRUE;
					#endif
						
						/* Check if it is the first confirmed DTC since last clear */
						if (FCM_FALSE == FCM_FirstCnfmdDTCInfoFlag)
						{
							/* Store the First confirmed DTC information */
							FCM_FirstCnfmdDTCInfo.Fault_Id = FCM_DTCInfo[FCM_DTC_Idx].Fault_Id;
							FCM_FirstCnfmdDTCInfo.FaultStatus = FCM_DTCInfo[FCM_DTC_Idx].FaultStatus;
							
							/*To Store SnapShot For First Occurance Of DTC Set Here*/
							
							/* Indicate First confirmed DTC since last clear */
							FCM_FirstCnfmdDTCInfoFlag = FCM_TRUE;
						}
						else
						{
							/* Do nothing */
						}
						/* Store the Most recent confirmed DTC information */
						FCM_MostRecentCnfmdDTCInfo.Fault_Id = FCM_DTCInfo[FCM_DTC_Idx].Fault_Id;
						FCM_MostRecentCnfmdDTCInfo.FaultStatus = FCM_DTCInfo[FCM_DTC_Idx].FaultStatus;
						
						/*To Store SnapShot For Most Occurance Of DTC Set Here*/
							
						/* Indicate the Most recent DTC is confirmed */
						FCM_MostRecentCnfmdDTCInfoFlag = FCM_TRUE;

						/* Test failed in the previous operation cycle */
						if ((FCM_DTCExtndSnapShotInfo[FCM_DTC_Idx].FreqCountr < FCM_FREQ_CNT_THRSHLD) && ((FCM_FALSE == DTCStatus_Bkp.Signal.pendingDTC) ||
							/* Test healed in same cycle and confirmed back  */
							((FCM_FALSE == DTCStatus_Bkp.Signal.testFailed) && (FCM_TRUE == DTCStatus_Bkp.Signal.testFailedThisOperationCycle))))
						{
							FCM_DTCExtndSnapShotInfo[FCM_DTC_Idx].FreqCountr++;
						}
						/* Confirmed DTC set, reset the counter */
						FCM_DTCExtndSnapShotInfo[FCM_DTC_Idx].OperatCycleCntr = FCM_ZERO;
					}
					else
					{
						/* Do nothing */
					}
				#endif
					/* Clear the Aging counter */
					FCM_DTCInfo[FCM_DTC_Idx].AgingCount = FCM_ZERO;
					
				#if (FCM_TST_NOT_CMPLTD_SNC_LST_CLR_STAT_SUPT == FCM_TRUE)
					/* Clear the test not completed since last clear status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testNotCompletedSinceLastClear = FCM_FALSE;
				#endif
				
				#if (FCM_TST_FAILED_SNC_LST_CLR_STAT_SUPT == FCM_TRUE)
					/* Set the test failed this since last clear status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testFailedSinceLastClear = FCM_TRUE;
				#endif
				
				#if (FCM_TST_NOT_CMPLTD_THIS_OPCYCLE_STAT_SUPT == FCM_TRUE)
					/* Clear the Test not completed this operation cycle status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testNotCompletedThisOperationCycle = FCM_FALSE;
				#endif
				
					/* Check if it is first Test failed since last clear*/
					if (FCM_FALSE == FCM_FirstFailedDTCInfoFlag)
					{
						/* Store the First test failed DTC since last clear information */
						FCM_FirstFailedDTCInfo.Fault_Id = FCM_DTCInfo[FCM_DTC_Idx].Fault_Id;
						FCM_FirstFailedDTCInfo.FaultStatus = FCM_DTCInfo[FCM_DTC_Idx].FaultStatus;
						/*To Store SnapShot For First Occurance Of DTC Set Here*/

						
						/* Indicate first test failed since last clear */
						FCM_FirstFailedDTCInfoFlag = FCM_TRUE;
						FCM_MostRecentFailedDTCInfoFlag = FCM_TRUE;
					}
					else
					{
						/* Do Nothing */
					}
					
						/* IF FF configuration is set, Log the FF data*/
						(void)FCM_UpdateFreezeFrameInfo(FCM_DTC_Idx);
				}
				break;

				case FCM_TESTPASS:
				{
				#if (FCM_TST_FAILED_STAT_SUPT == FCM_TRUE)
					/* Clear the test failed status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testFailed = FCM_FALSE;
				#endif

					/* Rest the Occurence count */
					FCM_DTCInfo[FCM_DTC_Idx].OccurenceCount = FCM_ZERO;
					


				#if (FCM_TST_NOT_CMPLTD_SNC_LST_CLR_STAT_SUPT == FCM_TRUE)
					/* Clear the Test not completed since last clear status bit */
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testNotCompletedSinceLastClear = FCM_FALSE;
				#endif

				#if (FCM_TST_NOT_CMPLTD_THIS_OPCYCLE_STAT_SUPT == FCM_TRUE)
					/* Clear the test not completed this operation cycle  status bit*/
					FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.Signal.testNotCompletedThisOperationCycle = FCM_FALSE;
				#endif
					/* Operation cycle threshold reached */
					if (FCM_DTCExtndSnapShotInfo[FCM_DTC_Idx].OperatCycleCntr >= FCM_OPRTN_CYCLE_THRSHLD)
					{
						/* Reset the Frequency counter */
						FCM_DTCExtndSnapShotInfo[FCM_DTC_Idx].FreqCountr = FCM_ZERO;
					}
				}
				break;
				
				default:
				{
					/* we should not reach here */
				}
				break;
			} /* end of switch */

			if (DTCStatus_Bkp.byte != FCM_DTCInfo[FCM_DTC_Idx].FaultStatus.byte)
			{
				(void)App_FCM_DTC_StatusChange(FCM_DTC_Idx);
			}
			else
			{
				/* Do nothing */
			}
		}
		else
		{
			/* index is invalid. Do not perform any operation */
		}
	}
	else
    {
        /* Do nothing if FCM not init */
    }
}

/***************************************************************************************************
** Function                 : FCM_UpdateOperationCycle

** Description              : This function updates the Operation cycle status of requestd DTC group

** Parameter                : DTC_GroupIndex: Index of DTC group
							  CycleStatus: Request operation cycle change

** Return value             : num_dtcs: number of DTC's
***************************************************************************************************/
void FCM_UpdateOperationCycle(eFCM_GroupType DTC_GroupIndex, eFCM_OperationCycleType CycleStatus)
{
	eFCM_GroupType DTC_Group_Index;
	uint8_t Loop_Index;
	uint8_t LpStart_Index;
	uint8_t LpEnd_Index;
	
	if (FCM_TRUE == appFcmInitStatus())
	{
		/* Check if DTC group is valid */
		if (DTC_GroupIndex < NUMBER_OF_DTC_GROUPS)
		{
			/* Check if the Operation Cycle status is valid */
			if ((FCM_OPERATION_CYCLE_START == CycleStatus) ||
				(FCM_OPERATION_CYCLE_STOP == CycleStatus))
			{
				/* Update the Current operation cycle to new status */
				lCurrentOperationCycle[DTC_GroupIndex] = CycleStatus;
			}
			else
			{
				/* Invalid Operation cycle status Ignore */
			}
		}
		else
		{
			/* Invalid DTC group, Ignore */
		}
		if (FCM_DTC_SETTING_ON == FCM_ControlDTCStatus)
		{
			/* Monitor the DTC group Operation cycle change */
			for (DTC_Group_Index = BODY_DTC_GROUP; DTC_Group_Index < NUMBER_OF_DTC_GROUPS; DTC_Group_Index++)
			{
				/* Check if the Operation cycle is changed */
				if (lCurrentOperationCycle[DTC_Group_Index] == lPreviousOperationCycle[DTC_Group_Index])
				{
					/* Do nothing */
				}
				else
				{
					/* checkFlag */
					switch(lCurrentOperationCycle[DTC_Group_Index])
					{
						/* Operation cycle is started */
						case FCM_OPERATION_CYCLE_START:
						{
							/* Find the DTC List for the Operation cycle change requested */
							if (BODY_DTC_GROUP == DTC_Group_Index)
							{
								/* Update the Start and stop index for the loop */
								LpStart_Index = BODY_DTC_GROUP_START_INDEX;
								LpEnd_Index = BODY_DTC_GROUP_END_INDEX;
							}
							else if (NETWORK_DTC_GROUP == DTC_Group_Index)
							{
								/* Update the Start and stop index for the loop */
								LpStart_Index = NETWORK_DTC_GROUP_START_INDEX;
								LpEnd_Index = NETWORK_DTC_GROUP_END_INDEX;
								
							}
							else
							{
								/* Unknown group: Update the Start and stop index for the loop */
								LpStart_Index = IGN_ACC_DTC_GROUP_START_INDEX;
								LpEnd_Index = IGN_ACC_DTC_GROUP_END_INDEX;
							}
							
							for (Loop_Index = LpStart_Index; Loop_Index < LpEnd_Index; Loop_Index++)
							{
								FCM_DTCInfo[Loop_Index].FaultStatus.Signal.testFailed			= FCM_FALSE;
							#if (FCM_TST_FAILED_THIS_OPCYCLE_STAT_SUPT == FCM_TRUE)
								/* Reset the test failed this operation cycle status bit */
								FCM_DTCInfo[Loop_Index].FaultStatus.Signal.testFailedThisOperationCycle = FCM_FALSE;
							#endif
							
							#if (FCM_TST_NOT_CMPLTD_THIS_OPCYCLE_STAT_SUPT == FCM_TRUE)
								/* Clear the Test not completed this operation cycle status bit */
								FCM_DTCInfo[Loop_Index].FaultStatus.Signal.testNotCompletedThisOperationCycle = FCM_TRUE;
							#endif
								/* Operation cycle is has reached the threshold */
								if (FCM_DTCExtndSnapShotInfo[Loop_Index].OperatCycleCntr < FCM_OPRTN_CYCLE_THRSHLD)
								{
									FCM_DTCExtndSnapShotInfo[Loop_Index].OperatCycleCntr++;
								}
							}
						}
						break;
						
						/* Operation cycle is stoped */
						case FCM_OPERATION_CYCLE_STOP:
						{
							uint8_t Indx;
						#if (FCM_PENDING_DTC_STAT_SUPT == FCM_TRUE)
							if (BODY_DTC_GROUP == DTC_Group_Index)
							{
								LpStart_Index = BODY_DTC_GROUP_START_INDEX;
								LpEnd_Index = BODY_DTC_GROUP_END_INDEX;
							}
							else if (NETWORK_DTC_GROUP == DTC_Group_Index)
							{
								LpStart_Index = NETWORK_DTC_GROUP_START_INDEX;
								LpEnd_Index = NETWORK_DTC_GROUP_END_INDEX;
							}
							else
							{
								/* Unknown group: Update the Start and stop index for the loop */
								LpStart_Index = IGN_ACC_DTC_GROUP_START_INDEX;
								LpEnd_Index = IGN_ACC_DTC_GROUP_END_INDEX;
							}
							
							for (Loop_Index = LpStart_Index; Loop_Index < LpEnd_Index; Loop_Index++)
							{
								if ((FCM_FALSE == FCM_DTCInfo[Loop_Index].FaultStatus.Signal.testNotCompletedThisOperationCycle) &&
									(FCM_FALSE == FCM_DTCInfo[Loop_Index].FaultStatus.Signal.testFailedThisOperationCycle))
								{
										/* Reset the Pending DTC status bit */
										FCM_DTCInfo[Loop_Index].FaultStatus.Signal.pendingDTC = FCM_FALSE;
										
									#if (FCM_CONFIRMED_DTC_STAT_SUPT == FCM_TRUE)
										/* Check if confirmed DTC status is set */
										if (FCM_TRUE == FCM_DTCInfo[Loop_Index].FaultStatus.Signal.confirmedDTC)
										{
											if ((FCM_Aging_Flag[Loop_Index] == 0u)&&(FCM_DTCInfo[Loop_Index].AgingCount < FCM_DtcCfg_Tabl[Loop_Index].AgingThrehlod))
											{
												/* Increment the Aging counter */
												FCM_DTCInfo[Loop_Index].AgingCount += FCM_DtcCfg_Tabl[Loop_Index].AgingIncrmntVal;
												FCM_Aging_Flag[Loop_Index] = 0;
											}
											else
											{
												/* Do nothing */
											}

											/* Check if Aging counter reached the threshold */
											if (FCM_DTCInfo[Loop_Index].AgingCount >= FCM_DtcCfg_Tabl[Loop_Index].AgingThrehlod)
											{
												/* DTC aged: Clear the confirmed DTC status bit */
												FCM_DTCInfo[Loop_Index].FaultStatus.Signal.confirmedDTC = FCM_FALSE;
												/* DTC aged: Clear the Warning Indicator status bit */
												#if (FCM_WARNING_INDICATOR_STAT_SUPT == FCM_TRUE)
												FCM_DTCInfo[Loop_Index].FaultStatus.Signal.warningIndicatorRequested = FCM_FALSE;
												#endif
												FCM_DTCInfo[Loop_Index].AgingCount = 0;
											}
											else
											{
												/* Do nohing */
											}
										}
										else
										{
											/* Do Nothing */
										}
									#endif
								}
								else
								{
									/* Do nothing */
								}
							}
						#endif
						for (Indx = 0; Indx < FCM_MAXNUM_DTCS; Indx++)
							{				
								FCM_Aging_Flag[Indx] = 0;
							}
						}
						break;
						
						default:
						{
							/* Operation should never hit this case */
						}
						break;
					}
					
					/* Set the previous monitoring cycle as current monitoring cycle */
					lPreviousOperationCycle[DTC_Group_Index] = lCurrentOperationCycle[DTC_Group_Index];

					(void)App_FCM_OpCyclChngUpdt(DTC_GroupIndex, CycleStatus);
				}
			}
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing if FCM not init */
	}
}

/***************************************************************************************************
** Function                 : FCM_ClearAllDTCInfo

** Description              : This function Initializes FCM parameters

** Parameter                : None

** Return value             : returns the status of operation
***************************************************************************************************/
uint8_t FCM_ClearAllDTCInfo (void)
{
	uint8_t	Indx;
	uint8_t	ClearStatus = FALSE;
	
	if (FCM_TRUE == appFcmInitStatus())
	{
		/* Reset the Operation cycle */
		for (Indx = 0; Indx < (uint8_t)NUMBER_OF_DTC_GROUPS; Indx++)
		{
			lCurrentOperationCycle[Indx]  = FCM_OPERATION_CYCLE_STOP;
			lPreviousOperationCycle[Indx] = FCM_OPERATION_CYCLE_STOP;
		}
		
		/* Re-Initialize the Status Bits */
		for (Indx = 0; Indx < FCM_MAXNUM_DTCS; Indx++)
		{
			/* Clear the DTC status bits according to ISO 14229-1 2013 Specification */
			FCM_DTCInfo[Indx].FaultStatus.Signal.testFailed							= FCM_FALSE;
			FCM_DTCInfo[Indx].FaultStatus.Signal.testFailedThisOperationCycle			= FCM_FALSE;
			FCM_DTCInfo[Indx].FaultStatus.Signal.pendingDTC							= FCM_FALSE;
			FCM_DTCInfo[Indx].FaultStatus.Signal.confirmedDTC							= FCM_FALSE;
		#if (FCM_TST_NOT_CMPLTD_SNC_LST_CLR_STAT_SUPT == FCM_TRUE)
			FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedSinceLastClear		= FCM_TRUE;
		#else
			FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedSinceLastClear		= FCM_FALSE;
		#endif
			FCM_DTCInfo[Indx].FaultStatus.Signal.testFailedSinceLastClear				= FCM_FALSE;
			
		#if (FCM_TST_NOT_CMPLTD_THIS_OPCYCLE_STAT_SUPT == FCM_TRUE)
			FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedThisOperationCycle	= FCM_TRUE;
		#else
			FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedThisOperationCycle	= FCM_FALSE;
		#endif
			FCM_DTCInfo[Indx].FaultStatus.Signal.warningIndicatorRequested				= FCM_FALSE;
			
			FCM_DTCInfo[Indx].OccurenceCount = FCM_ZERO;
			FCM_DTCInfo[Indx].AgingCount = FCM_ZERO;
			
			FCM_ClearSnapshotInfo (Indx);
		}
		
		/* Clear the first failed DTC information */
		FCM_FirstFailedDTCInfoFlag = FCM_FALSE;
		FCM_FirstFailedDTCInfo.Fault_Id = DEFAULT_FIRST_FAILED_DTC;
		FCM_FirstFailedDTCInfo.FaultStatus.byte = DEFAULT_FIRST_FAILED_DTC_STAT;
		
		/* Clear the first confirmed DTC information */
		FCM_FirstCnfmdDTCInfoFlag = FCM_FALSE;
		FCM_FirstCnfmdDTCInfo.Fault_Id = DEFAULT_FIRST_FAILED_DTC;
		FCM_FirstCnfmdDTCInfo.Fault_Id = DEFAULT_FIRST_FAILED_DTC;
		
		/* Clear the most recent confirmed DTC information */
		FCM_MostRecentCnfmdDTCInfoFlag = FCM_FALSE;
		FCM_MostRecentCnfmdDTCInfo.Fault_Id = DEFAULT_FIRST_FAILED_DTC;
		FCM_MostRecentCnfmdDTCInfo.FaultStatus.byte = DEFAULT_FIRST_FAILED_DTC_STAT;

		/* Clear the most recent Failed DTC information */
		FCM_MostRecentFailedDTCInfoFlag = FCM_FALSE;
		FCM_MostRecentFailedDTCInfo.Fault_Id = DEFAULT_FIRST_FAILED_DTC;
		FCM_MostRecentFailedDTCInfo.FaultStatus.byte = DEFAULT_FIRST_FAILED_DTC_STAT;

		ClearStatus = App_FCMClearAllDTC();
	}
	else
	{
		/*FCM not init*/
		ClearStatus = FCM_FALSE;
	}
	return ClearStatus;
}

/***************************************************************************************************
** Function                 : FCM_ClearRequestdDTCInfo

** Description              : This function Cleares FCM DTC group info

** Parameter                : DTC_Number : DTC number whose status to be cleared

** Return value             : None
***************************************************************************************************/
uint8_t FCM_ClearRequestdDTCInfo (uint32_t DTC_Group_number)
{
	uint8_t Indx;
	uint8_t dtc_clear_status = FALSE;
	uint8_t DTC_count = 0, start_index = 0;
	
	if (FCM_TRUE == appFcmInitStatus())
	{
		lCurrentOperationCycle[DTC_Group_number]  = FCM_OPERATION_CYCLE_STOP;
		lPreviousOperationCycle[DTC_Group_number] = FCM_OPERATION_CYCLE_STOP;

		/* Re-Initialize the Status Bits */
		for (Indx = 0; Indx < FCM_MAXNUM_DTCS; Indx++)
		{
			if (FCM_DtcCfg_Tabl[Indx].DTC_Group == DTC_Group_number)
			{
				if(DTC_count == 0)
					start_index = Indx;
				
				 DTC_count++;

				/* Clear the DTC status bits according to ISO 14229-1 2013 Specification */
				FCM_DTCInfo[Indx].FaultStatus.Signal.testFailed							= FCM_FALSE;
				FCM_DTCInfo[Indx].FaultStatus.Signal.testFailedThisOperationCycle			= FCM_FALSE;
				FCM_DTCInfo[Indx].FaultStatus.Signal.pendingDTC							= FCM_FALSE;
				FCM_DTCInfo[Indx].FaultStatus.Signal.confirmedDTC							= FCM_FALSE;
			#if (FCM_TST_NOT_CMPLTD_SNC_LST_CLR_STAT_SUPT == FCM_TRUE)
				FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedSinceLastClear		= FCM_TRUE;
			#else
				FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedSinceLastClear		= FCM_FALSE;
			#endif
				FCM_DTCInfo[Indx].FaultStatus.Signal.testFailedSinceLastClear				= FCM_FALSE;
				
			#if (FCM_TST_NOT_CMPLTD_THIS_OPCYCLE_STAT_SUPT == FCM_TRUE)
				FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedThisOperationCycle	= FCM_TRUE;
			#else
				FCM_DTCInfo[Indx].FaultStatus.Signal.testNotCompletedThisOperIndxationCycle	= FCM_FALSE;
			#endif
				FCM_DTCInfo[Indx].FaultStatus.Signal.warningIndicatorRequested				= FCM_FALSE;
				FCM_DTCInfo[Indx].OccurenceCount								= FCM_ZERO;
				FCM_DTCInfo[Indx].AgingCount									= FCM_ZERO;
 				FCM_ClearSnapshotInfo (Indx);

			}
		}
		dtc_clear_status = App_FCMClearReqDTCUpdate(start_index, DTC_count);
	}
	else
	{
		/*FCM not init*/
		dtc_clear_status = FCM_FALSE;
	}
	return dtc_clear_status;
}

/***************************************************************************************************
** Function                 : FCM_CopyDTCStatusByDTCNumber

** Description              : This function copies the DTC ststus by DTC number

** Parameter                : DTC_Number
							  data_ptr	: Pointer to Buffer to store the DTC info

** Return value             : None
***************************************************************************************************/
void FCM_CopyDTCStatusByDTCNumber (uint32_t DTC_Number, uint8_t* data_ptr)
{
	uint16_t DTC_Index;
	
	/* Find the DTC Index */
	DTC_Index = FCM_FindDTCIndex(DTC_Number);
	
	/* Loop till the all DTCs */
	if (DTC_Index < FCM_MAXNUM_DTCS)
	{
		/* Copy the DTC Number to buffer */
		*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_SIXTEEN);
		*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_EIGHT);
		*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id);
		/*Copy the DTC status into buffer */
		*data_ptr++ = (FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);
	}
	else
	{
		/* Do nothing */
	}
}


/***************************************************************************************************
** Function                 : FCM_ReportNoOfDTCByStatusMask

** Description              : This function returns number of faults with fault 
												status matching the status mask.

** Parameter                : FCM_DTC_StatusMask: Status mask

** Return value             : DTC_Count: number of DTC's with the status mask
***************************************************************************************************/
uint16_t FCM_ReportNoOfDTCByStatusMask (uint8_t FCM_DTC_StatusMask)
{
	uint16_t DTC_Index;
	uint16_t DTC_Count;
	
	/* Initialize the DTC count to Zero */
	DTC_Count = 0;
	
	for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
	{
		/* Check if the status mask is matching */
		if (0 != ((FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS) & FCM_DTC_StatusMask))
		{
			/* Status mask is matched, Increment the Count */
			DTC_Count++;
		}
		else
		{
			/* Do nothing */
		}
	}

    return (DTC_Count);
}


/***************************************************************************************************
** Function                 : FCM_ReportDTCByStatusMask

** Description              : This function returns the fault DTC number &
										status matching the Fault status mask

** Parameter                : FCM_DTC_StatusMask: Status mask request
							  data_ptr			: Pointer to Buffer to store the DTC info

** Return value             : Data_Count: number of bytes updated in data buffer
***************************************************************************************************/
uint16_t FCM_ReportDTCByStatusMask (uint8_t FCM_DTC_StatusMask, uint8_t* data_ptr)
{
	uint16_t DTC_Index;
	uint16_t Data_Count;
	
	/* Initialize the DTC count to Zero */
	Data_Count = 0;
	
	if (FCM_TRUE == appFcmInitStatus())
	{
		for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
		{
			/* Check if the status mask is matching */
			if (0 != ((FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS) & FCM_DTC_StatusMask))
			{
				/* Status Mask is matched */
				/* Copy the DTC Number to buffer */
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_SIXTEEN);
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_EIGHT);
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id);
				/*Copy the DTC status into buffer */
				*data_ptr++ = (FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);
				
				/* Increment the Data count to four */
				Data_Count += FCM_FOUR;
			}
			else
			{
				/* Do nothing */
			}
		}
	}
	else
	{
		/* do nothing if FCM not init*/
	}
	
    return (Data_Count);
}

/***************************************************************************************************
** Function                 : FCM_ReportSupportedDTCs

** Description              : This function returns all the supported DTC and status

** Parameter                : data_ptr	: Pointer to Buffer to store the DTC info

** Return value             : Data_Count: number of bytes updated in data buffer
***************************************************************************************************/
uint16_t FCM_ReportSupportedDTCs (uint8_t* data_ptr)
{
	uint16_t DTC_Index;
	uint16_t Data_Count;
	
	/* Initialize the DTC count to Zero */
	Data_Count = 0;
	
	/* Loop till the all DTCs */
	for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
	{
		/* Copy the DTC Number to buffer */
		*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_SIXTEEN);
		*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_EIGHT);
		*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id);
		/*Copy the DTC status into buffer */
		*data_ptr++ = (FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);
		
		/* Increment the Data count to four */
		Data_Count += FCM_FOUR;
	}
	
    return (Data_Count);
}

/***************************************************************************************************
** Function                 : FCM_ReportFirstFailedDTC

** Description              : This function returns first faild DTC information

** Parameter                : data_ptr	: Pointer to Buffer to store the DTC info

** Return value             : status
***************************************************************************************************/
uint8_t FCM_ReportFirstFailedDTC (uint8_t* data_ptr)
{
	if (FCM_TRUE == FCM_FirstFailedDTCInfoFlag)
	{
		/* Copy the DTC Number to buffer */
		*data_ptr++ = (uint8_t)(FCM_FirstFailedDTCInfo.Fault_Id >> FCM_SIXTEEN);
		*data_ptr++ = (uint8_t)(FCM_FirstFailedDTCInfo.Fault_Id >> FCM_EIGHT);
		*data_ptr++ = (uint8_t)(FCM_FirstFailedDTCInfo.Fault_Id);
		/*Copy the DTC status into buffer */
		*data_ptr++ = (FCM_FirstFailedDTCInfo.FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);
		
		/* Update the Snapshot record Here */
	}
	else
	{
		/* Do Nothing */
	}
	
    return (FCM_FirstFailedDTCInfoFlag);
}

/***************************************************************************************************
** Function                 : FCM_ReportFirstCnfmdDTC

** Description              : This function returns first confirmed DTC information

** Parameter                : data_ptr	: Pointer to Buffer to store the DTC info

** Return value             : status
***************************************************************************************************/
uint8_t FCM_ReportFirstCnfmdDTC (uint8_t* data_ptr)
{
	if (FCM_TRUE == FCM_FirstCnfmdDTCInfoFlag)
	{
		/* Copy the DTC Number to buffer */
		*data_ptr++ = (uint8_t)(FCM_FirstCnfmdDTCInfo.Fault_Id >> FCM_SIXTEEN);
		*data_ptr++ = (uint8_t)(FCM_FirstCnfmdDTCInfo.Fault_Id >> FCM_EIGHT);
		*data_ptr++ = (uint8_t)(FCM_FirstCnfmdDTCInfo.Fault_Id);
		/*Copy the DTC status into buffer */
		*data_ptr++ = (FCM_FirstCnfmdDTCInfo.FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);
		
		/* Update the snapshot record here */
	}
	else
	{
		/* Do Nothing */
	}

    return (FCM_FirstCnfmdDTCInfoFlag);
}

/***************************************************************************************************
** Function                 : FCM_ReportMostRecentCnfmdDTC

** Description              : This function returns most recent confirmed DTC information

** Parameter                : data_ptr	: Pointer to Buffer to store the DTC info

** Return value             : status
***************************************************************************************************/
uint8_t FCM_ReportMostRecentCnfmdDTC (uint8_t* data_ptr)
{
	if (FCM_TRUE == FCM_MostRecentCnfmdDTCInfoFlag)
	{
		/* Copy the DTC Number to buffer */
		*data_ptr++ = (uint8_t)(FCM_MostRecentCnfmdDTCInfo.Fault_Id >> FCM_SIXTEEN);
		*data_ptr++ = (uint8_t)(FCM_MostRecentCnfmdDTCInfo.Fault_Id >> FCM_EIGHT);
		*data_ptr++ = (uint8_t)(FCM_MostRecentCnfmdDTCInfo.Fault_Id);
		/*Copy the DTC status into buffer */
		*data_ptr++ = (FCM_MostRecentCnfmdDTCInfo.FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);

		/* Update the snap shot record here */
	}
	else
	{
		/* Do Nothing */
	}

    return (FCM_MostRecentCnfmdDTCInfoFlag);
}
/***************************************************************************************************
** Function                 : FCM_ReportMostRecentTestFailed

** Description              : This function returns most recent failed DTC information

** Parameter                : data_ptr	: Pointer to Buffer to store the DTC info

** Return value             : status
***************************************************************************************************/
uint8_t FCM_ReportMostRecentTestFailed (uint8_t* data_ptr)
{
	if (FCM_TRUE == FCM_MostRecentFailedDTCInfoFlag)
	{
		/* Copy the DTC Number to buffer */
		*data_ptr++ = (uint8_t)(FCM_MostRecentFailedDTCInfo.Fault_Id >> FCM_SIXTEEN);
		*data_ptr++ = (uint8_t)(FCM_MostRecentFailedDTCInfo.Fault_Id >> FCM_EIGHT);
		*data_ptr++ = (uint8_t)(FCM_MostRecentFailedDTCInfo.Fault_Id);
		/*Copy the DTC status into buffer */
		*data_ptr++ = (FCM_MostRecentFailedDTCInfo.FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);

		/* Update the snap shot record here */
	}
	else
	{
		/* Do Nothing */
	}

    return (FCM_MostRecentFailedDTCInfoFlag);
}
/***************************************************************************************************
** Function                 : FCM_UpdateCntrolDTCSetting

** Description              : This function updates the Control DTC setting

** Parameter                : DTCControlStat : Control DTC setting

** Return value             : status
***************************************************************************************************/
void FCM_UpdateCntrolDTCSetting (uint8_t DTCControlStat)
{
	/* Update the Requested control DTC setting */
	FCM_ControlDTCStatus = (eFCM_ControDTCType)DTCControlStat;
}

/***************************************************************************************************
** Function                 : FCM_GetCnfrmdDTCStatusByDTCNumber

** Description              : This function returns confirmed DTC

** Parameter                : DTC_Number

** Return value             : None
***************************************************************************************************/
uint8_t FCM_GetCnfrmdDTCStatusByDTCNumber (uint32_t DTC_Number)
{
	uint16_t DTC_Index;
	uint8_t RetVal;
	
	RetVal = FCM_FALSE;
	
	/* Find the DTC Index */
	DTC_Index = FCM_FindDTCIndex(DTC_Number);
	
	/* Loop till the all DTCs */
	if (DTC_Index < FCM_MAXNUM_DTCS)
	{
		if(FCM_TRUE == (FCM_DTCInfo[DTC_Index].FaultStatus.Signal.confirmedDTC))
		{
			RetVal = FCM_TRUE;
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
	
	return RetVal;
}

/***************************************************************************************************
** Function                 : FCM_GetDTCStatusByDTCNmbr

** Description              : This function returns DTC status

** Parameter                : DTC_Number

** Return value             : None
***************************************************************************************************/
uint8_t FCM_GetDTCStatusByDTCNmbr (uint32_t DTC_Num)
{
	uint8_t RetVal;
	uint8_t DTC_Index;

	RetVal = FCM_FALSE;

	DTC_Index = FCM_FindDTCIndex(DTC_Num);

	/* Loop till the all DTCs */
	if (DTC_Index < FCM_MAXNUM_DTCS)
	{
		RetVal = FCM_DTCInfo[DTC_Index].FaultStatus.byte;
	}
	else
	{
		/* Do nothing */
	}

	return RetVal;
}

/***************************************************************************************************
** Function                 : FCM_GetDTCStatusByDTCIndex

** Description              : This function returns DTC status

** Parameter                : DTC_Number

** Return value             : None
***************************************************************************************************/
uint8_t FCM_GetDTCStatusByDTCIndex (uint8_t DTC_Index)
{
	uint8_t RetVal;

	RetVal = FCM_FALSE;

	/* Loop till the all DTCs */
	if (DTC_Index < FCM_MAXNUM_DTCS)
	{
		RetVal = FCM_DTCInfo[DTC_Index].FaultStatus.byte;
	}
	else
	{
		/* Do nothing */
	}

	return RetVal;
}


/***************************************************************************************************
** Function                 : FCM_GetHealedDTCStatusByDTCNumber

** Description              : This function returns Healed DTC

** Parameter                : DTC_Number

** Return value             : None
***************************************************************************************************/
uint8_t FCM_GetHealedDTCStatusByDTCNumber (uint16_t DTC_Index)
{
	uint8_t RetVal;
	
	RetVal = FCM_FALSE;
	
	/* Loop till the all DTCs */
	if (DTC_Index < FCM_MAXNUM_DTCS)
	{
		if((0x26 == (FCM_DTCInfo[DTC_Index].FaultStatus.byte)) || (0x2E == (FCM_DTCInfo[DTC_Index].FaultStatus.byte)) || (0x2C == (FCM_DTCInfo[DTC_Index].FaultStatus.byte)) || (0x28 == (FCM_DTCInfo[DTC_Index].FaultStatus.byte)))
		{
			RetVal = FCM_TRUE;
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
	
	return RetVal;
}

/***************************************************************************************************
** Function                 : FCM_ReportCnfmDTCForJ1939DM1

** Description              : This function returns the confirm fault DTC number, 
**									represented in j1939 format

** Parameter                : data_ptr			: Pointer to Buffer to store the DTC info

** Return value             : Data_Count: number of DTCs
***************************************************************************************************/
uint16_t FCM_ReportCnfmDTCForJ1939DM1 (uint8_t* data_ptr)
{
	uint16_t DTC_Index;
	uint16_t Data_Count;
	
	/* Initialize the DTC count to Zero */
	Data_Count = 0;
	
	if (FCM_TRUE == appFcmInitStatus())
	{
		for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
		{
			/* Check if the status mask is matching */
			if (0 != ((FCM_DTCInfo[DTC_Index].FaultStatus.byte & (FCM_CONFIRMED_DTC_STAT_SUPT << FCM_THREE))))
			{
				/* Status Mask is matched */
				/* Copy the DTC Number to buffer */
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_EIGHT);
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_SIXTEEN);
				*data_ptr++ = (uint8_t)FCM_J1939_FMI;
				*data_ptr++ = (uint8_t)FCM_J1939_OCCURANCE_COUNT;
				
				/* Increment the Data count to four */
				Data_Count += 1;
			}
			else
			{
				/* Do nothing */
			}
		}
	}
	else
	{
		/* Do nothing */
	}
    return (Data_Count);
}
/***************************************************************************************************
** Function                 : FCM_ReportDTCSnapshotIdentification

** Description              : This function returns logged DTDC with snaphot record identification

** Parameter                : data_ptr	: Pointer to Buffer to store the DTC info

** Return value             : Data_Count: number of bytes updated in data buffer
***************************************************************************************************/
uint8_t FCM_ReportDTCSnapshotIdentification (uint8_t* data_ptr, uint16_t *length)
{
	uint8_t DTC_Rec_Validity = FCM_FALSE;
	uint16_t DTC_Index;
	uint16_t Data_Count;
	
	/* Initialize the DTC count to Zero */
	Data_Count = 0;
	
	if (FCM_TRUE == appFcmInitStatus())
	{
		/* Loop till the all DTCs */
		for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
		{

				/* Copy the DTC Number to buffer */
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_SIXTEEN);
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_EIGHT);
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id);
				/*Copy the DTC status into buffer */
				*data_ptr++ = FCM_DTCInfo[DTC_Index].FaultStatus.byte;
				/* Increment the Data count to four */
				Data_Count += FCM_FOUR;
		}
		*length = Data_Count;
		DTC_Rec_Validity = FCM_TRUE;
	}
	else
	{
		DTC_Rec_Validity = FCM_FALSE;
	}
	
    return DTC_Rec_Validity;
}

/***************************************************************************************************
** Function                 : FCM_AppReportDTCByStatusMask

** Description              : This function returns the fault DTC number &
										status matching the Fault status mask

** Parameter                : FCM_DTC_StatusMask: Status mask request
							  data_ptr			: Pointer to Buffer to store the DTC info

** Return value             : Data_Count: number of bytes updated in data buffer
***************************************************************************************************/
uint16_t FCM_AppReportDTCByStatusMask (uint8_t FCM_DTC_StatusMask, uint8_t* data_ptr, uint16_t* Index_prt)
{
	uint16_t DTC_Index;
	uint16_t Data_Count;
	
	/* Initialize the DTC count to Zero */
	Data_Count = 0;
	
	if (FCM_TRUE == appFcmInitStatus())
	{
		for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
		{
			/* Check if the status mask is matching */
			if (0 != ((FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS) & FCM_DTC_StatusMask))
			{
				/* Status Mask is matched */
				/* Copy the DTC Number to buffer */
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_SIXTEEN);
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_EIGHT);
				*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id);
				/*Copy the DTC status into buffer */
				*data_ptr++ = (FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS);
				/* passing DTC index */
				*Index_prt++ = DTC_Index;
				/* Increment the Data count to four */
				Data_Count += FCM_FOUR;
			}
			else
			{
				/* Do nothing */
			}
		}
	}
	else
	{
		/* do nothing if FCM not init*/
	}
    return (Data_Count);
}

/***************************************************************************************************
** Function                 : FCM_PassDTCtableInfo

** Description              :pass DTC table information.

** Parameter                : FCM_DTC_CfgType * FcmDTCInfoPtr
								uint16_t *FcmInfoSize

** Return value             : None
***************************************************************************************************/
void FCM_PassDTCtableInfo(FCM_DTC_InfoType * FcmDTCInfoPtr, uint16_t *FcmInfoSize)
{
	/* Check for valid address */
	if(FcmDTCInfoPtr!= NULL)
	{
		FcmDTCInfoPtr = &FCM_DTCInfo[0];
		(*FcmInfoSize) = sizeof(FCM_DTCInfo);
	}
	else
	{
		/* Do nothing */
	}
}


/***************************************************************************************************
** Function                 : FCM_ReportDTCFaultDetectionCounter

** Description              :This function gets the prefailed faults and size .

** Parameter                : data_ptr  - data buffer, holds prefailed faults.

** Return value             : size of prefailed faults
***************************************************************************************************/
uint8_t FCM_ReportDTCFaultDetectionCounter (uint8_t *data_ptr)
{
	uint16_t DTC_Index;
	uint16_t Data_Count;
	
	/* Initialize the DTC count to Zero */
	Data_Count = 0;
	
	for (DTC_Index = 0; DTC_Index < FCM_MAXNUM_DTCS; DTC_Index++)
	{
		/* Check if the status mask is matching */
		if (0 == ((FCM_DTCInfo[DTC_Index].FaultStatus.byte & FCM_SUPPORTED_DTC_STATUS_BITS) & PRE_TEST_FAILED_MASK))
		{
			/* pre failed Mask is matched */
			/* Copy the DTC Number to buffer */
			*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_SIXTEEN);
			*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id >> FCM_EIGHT);
			*data_ptr++ = (uint8_t)(FCM_DTCInfo[DTC_Index].Fault_Id);
			/*Copy the DTC status into buffer */
			*data_ptr++ = (FCM_DTCInfo[DTC_Index].OccurenceCount);
			/* Increment the Data count to four */
			Data_Count += FCM_FOUR;
		}
		else
		{
			/* Do nothing */
		}
	}
    return (Data_Count);
}
