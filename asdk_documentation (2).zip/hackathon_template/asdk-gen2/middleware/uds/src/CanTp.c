/***************************************************************************************************
** Copyright (c) 2018 Embitel
**
** This software is the property of Embitel.
** It can not be used or duplicated without Embitel.
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOTP.c
** Module name  : Can Transport layer
** -------------------------------------------------------------------------------------------------
**
** Description  : Provides methods for segmentation, transmission with flow control and re-assembly.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00  
** - Baseline for CANTP module
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "ISOUDS.h"
#include "CANIL.h"

/********************** Declaration of local symbol and constants *********************************/
/****************************** Declaration of exported variables *********************************/
/****************************** Declaration of exported constants *********************************/
/********************************* Declaration of local macros ************************************/
/********************************* Declaration of local types *************************************/
/******************************* Declaration of local variables ***********************************/
static uint8 ISOTP_FirstFCRcvd;
static uint8 ISOTP_BlkSize;
static uint16 ISOTP_STmin;
static uint16 ISOTP_TpBuffIdx;
static uint16 ISOTP_BSLen;
static volatile uint32 ISOTP_NATime;
static volatile uint32 ISOTP_NBTime;
static volatile uint32 ISOTP_NCTime;
static uint32 ISOTP_TimeOutNA;
static uint32 ISOTP_TimeOutNB;
static uint32 ISOTP_TimeOutNC;
static ISOTP_CfgType ISOTP_FrmCfg;
static ISOTP_CfgType ISOTP_FirstFrmCfg;
static uint8 ISOTP_NWLSt;
static ISOTP_Msg_Type ISOTP_canfrm;
static ISOTP_App_CfgType ISOTP_TP_Cfg;
static uint8 ISOTP_St;
static VAR(uint8, AUTOMATIC) ISOTP_StMultiFrame;
static uint8 ISOTP_BuffFlowCtrl[3U] = {0x30U, 0x00U, 0x00U};
static const ISOTP_App_CfgType ISOTP_TP_flowctrl =
{ 
  .dataPtr = &ISOTP_BuffFlowCtrl[0U], 
  .dataLen = 3U
};

static uint16 ISOTP_MultiFrameLen;

uint8 ISOTP_CHFlag;
extern ISOTPTXReq_CHTYPE ISOTP_TxReqConfTable[ISOTP_NO_OF_CHANNELS];
/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/


/**************************** Internal functions declarations *************************************/
static void ISOTP_iTmrMon (void);
static void ISOTP_Rst (void);
#if (ISOTP_ST_PADDING == ISOTP_PAD_REQUIRED)
static void ISOTP_PrfrmPad (uint16 byteIdx);
#endif


/******************************** Function definitions ********************************************/

/***************************************************************************************************
** Function                 : ISOTP_Init

** Description              : Initialization of CAN TP parameters

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void ISOTP_Init (void)
{
    /* Initialize to IDLE state */
    ISOTP_St = (uint8)ISOTP_IDLE;
    ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;

    /* Initialize the counters to O */
    ISOTP_NATime = (uint32)ISOTP_ZERO;
    ISOTP_NBTime = (uint32)ISOTP_ZERO;
    ISOTP_NCTime = (uint32)ISOTP_ZERO;

    /* Initialize the first FC frame received to ISOTP_FALSE */
    ISOTP_FirstFCRcvd = (uint8)ISOTP_ZERO;

    /* Initialize the Tp buffer Index to 0 */
    ISOTP_TpBuffIdx = (uint16)ISOTP_ZERO;
	
	ISOTP_StMultiFrame = ISOTP_FALSE;

    /* set the CAN ID tx parameters as per configuration */
    ISOTP_canfrm.Msg_ID = (uint32)ISOTP_TXOBD_CANID;    
}

/***************************************************************************************************
** Function                 : ISOTP_RxMsgCbk

** Description              : Receive callback function of Diagnostic frame

** Parameter rxData         : Data array

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void ISOTP_RxMsgCbk(uint32 Msg_ID, uint8 dlc,const uint8 *dataBuff, ISOTP_ReqType ReqType, uint8 ISOTP_CH)
{
    uint16 dataLen;
    uint16 idx;
    uint8 cFSeqNum;
    uint8 frmType;
    uint8 RespBuf[3];
    static uint8 Srv_id;
    (void)Msg_ID;

    ISOTP_CHFlag = ISOTP_CH;
#if (ISOTP_ST_PADDING != ISOTP_PAD_REQUIRED)
    uint8 processCF;
#endif

#if (ISOTP_ST_PADDING == ISOTP_PAD_REQUIRED)
    if (dlc == (uint8)ISOTP_EIGHT)
#else
	if (dlc > (uint8)ISOTP_ONE + ISOTP_ADD_MODE_OFST)
#endif
    {
		#if ((ISOTP_ADDRESSING == ISOTP_EXTENDED_ADD) || (ISOTP_ADDRESSING == ISOTP_MIXED_ADD))
		if (ISOTP_SOURCE_ADDRESS == dataBuff[ISOTP_ZERO])
		{
		#endif
		/* Get the PDU frame Type */
        frmType = dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] & (uint8)ISOTP_FRAMEMASK;
	    switch (frmType)
        {
            /* Single Frame */
            case ISOTP_SF:
            {
                /* Check if Tx is not in Progress and processing is not in progress */
                if ((ISOTP_NWLSt != (uint8)ISOTP_NWLST_TXINPROG) &&
                                                     (ISOTP_NWLSt != (uint8)ISOTP_NWLST_PROCINPROG))
                {
					/* Get the Length info */
                    dataLen = (uint16)dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] & (uint16)ISOTP_SEQMASK;
					/* Check if RX in Progress. */
					if(ISOTP_StMultiFrame == ISOTP_TRUE)
					{							   
						/* Store the length info in conf structure */
                        ISOTP_FirstFrmCfg.nBytes = dataLen;

                       	/* Check if data length received is valid */
						if ((dataLen > (uint16)ISOTP_ZERO) && (dataLen <= (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST)))
						{
                            for (idx = (uint8)ISOTP_ZERO; idx < dataLen; idx++)
                            {
                                ISOTP_FirstFrmCfg.tpBuff[idx] = dataBuff[idx + (uint8)ISOTP_ONE];
                            }
                        }

                        /* Call the message Indication function */
					   	ISOUDS_MsgIndiIm(&ISOTP_FirstFrmCfg);
					}
					else
					{
						/* Check if data length received is valid */
						if ((dataLen > (uint16)ISOTP_ZERO) && (dataLen <= (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST)))
						{
							#if (ISOTP_ST_PADDING != ISOTP_PAD_REQUIRED)
							if (dlc >= (dataLen + ISOTP_ONE + ISOTP_ADD_MODE_OFST))
							#endif
							{
								/* Check if Tp state is not in IDLE */
								if (ISOTP_St != (uint8)ISOTP_IDLE)
								{
									/* reset all the TP counters */
									ISOTP_NATime = (uint32)ISOTP_ZERO;
									ISOTP_NBTime = (uint32)ISOTP_ZERO;
									ISOTP_NCTime = (uint32)ISOTP_ZERO;

									/* Reset Tp parameters, go to IDLE state */
									ISOTP_Rst ();
								}

								/* Set the operation state to single frame received */
								ISOTP_St = (uint8)ISOTP_SFRX;

								/* Store the length info in conf structure */
								ISOTP_FrmCfg.nBytes = dataLen;

								for (idx = (uint8)ISOTP_ZERO; idx < dataLen; idx++)
								{
									ISOTP_FrmCfg.tpBuff[idx] = dataBuff[idx + (uint8)(ISOTP_ONE + ISOTP_ADD_MODE_OFST)];
								}

								/* Call the message Indication function */
								ISOTP_FrmCfg.ReqType = ReqType;
								ISOUDS_MsgIndi(&ISOTP_FrmCfg);

								/* Reset Tp parameters, go to IDLE state */
								ISOTP_Rst ();
							}
						}
					}
                }
                break;
            }
            
            /* First Frame */
            case ISOTP_FF:
            {
                /* Check if Tx is not in Progress */
                if ((ISOTP_NWLSt != (uint8)ISOTP_NWLST_TXINPROG) &&
                                                     (ISOTP_NWLSt != (uint8)ISOTP_NWLST_PROCINPROG))
                {
                    #if (ISOTP_ST_PADDING != ISOTP_PAD_REQUIRED)
                    if (dlc == (uint8)ISOTP_EIGHT)
                    #endif
                    {
                        /* Get the data length info */
							dataLen = ((uint16)(((uint16)dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] &
                                             (uint16)ISOTP_SEQMASK) << ISOTP_EIGHT) +
                                             (uint16)dataBuff[ISOTP_ONE + ISOTP_ADD_MODE_OFST]);
                        
                        /* Store the current service ID*/
							Srv_id = (uint8)dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST];
							
							/* Set Multiframe Status to TRUE */
							ISOTP_StMultiFrame = ISOTP_TRUE;
							
							/* Data Length is greater than Buffer size defined */  
							if(dataLen <= ISOTP_BUFFSIZE)  
							{
							/* Check if data length is valid */
								if (dataLen > (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))    
								{
								/* Check if Tp state is not in IDLE */
								if (ISOTP_St != (uint8)ISOTP_IDLE)
								{
									/* reset all the TP counters */
									ISOTP_NATime = (uint32)ISOTP_ZERO;
									ISOTP_NBTime = (uint32)ISOTP_ZERO;
									ISOTP_NCTime = (uint32)ISOTP_ZERO;

									/* Reset Tp parameters, go to IDLE state */
									ISOTP_Rst ();
								}                            

								/* Store the length info in conf structure */
								ISOTP_FrmCfg.nBytes = dataLen;
							   
								ISOTP_MultiFrameLen = dataLen;

								ISOTP_FrmCfg.ReqType = ReqType;
								//ISOUDS_FFIndi (&ISOTP_FrmCfg);

								/* Change state to receive in progress */
								ISOTP_NWLSt = (uint8)ISOTP_NWLST_RXINPROG;

								/* Store the received bytes of FF */
								for (idx = (uint8)ISOTP_ZERO; idx < (uint8)(ISOTP_SIX - ISOTP_ADD_MODE_OFST); idx ++)
								{
								   ISOTP_FrmCfg.tpBuff[idx] =
														  dataBuff[idx + (uint8)(ISOTP_TWO + ISOTP_ADD_MODE_OFST)];
								}

								ISOTP_TpBuffIdx = idx;

								/* Decrement the number of bytes by Received Bytes */
								ISOTP_FrmCfg.nBytes -= (uint16)(ISOTP_SIX - ISOTP_ADD_MODE_OFST);

								ISOTP_FrmCfg.seqNum = (uint8)ISOTP_ZERO;

								/* Form the Byte 1 of PCI for FC frame Tx */
								ISOTP_FrmCfg.frmInfo = (uint8)ISOTP_FC | (uint8)ISOTP_FCCTS;

								/* Set the timer limits */
								ISOTP_TimeOutNA =
										   ((uint32)(ISOTP_iTimeOut[ISOTP_RXIDX].tmrA));
								ISOTP_TimeOutNB =
										   ((uint32)(ISOTP_iTimeOut[ISOTP_RXIDX].tmrB));
								ISOTP_TimeOutNC =
										   ((uint32)(ISOTP_iTimeOut[ISOTP_RXIDX].tmrC));

								/* Start Timer B */
								ISOTP_NBTime = (uint32)ISOTP_ONE;

								/* change the state to Flow control Tx Request */
								ISOTP_St = (uint8)ISOTP_FCTXREQ;

								/* Transmit the Flow Control Message. */
								ISOTP_TxRequest(&ISOTP_TP_flowctrl);


							}
							else
							{
								/* Reset the Tp parameters */
								ISOTP_Rst ();
							}
						}
						else
						{
						/* Reset the Tp parameters */
							ISOTP_Rst ();
						}
                    }
                }
                break;
            }
            
            /* Consecutive frame */
            case ISOTP_CF:
            {
                /* Check if Rx is in Progress */
                if (ISOTP_NWLSt == (uint8)ISOTP_NWLST_RXINPROG)
                {
                    /* Check if Consecutive frame is awaited */
                    if (ISOTP_St == (uint8)ISOTP_CFWAIT)
                    {
#if (ISOTP_ST_PADDING != ISOTP_PAD_REQUIRED)
                        processCF = ISOTP_ZERO;

                        /* Check if last CF is to be received */
                        if (ISOTP_FrmCfg.nBytes <= (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
                        {
                            if (dlc >= ((uint8)ISOTP_FrmCfg.nBytes + ISOTP_ONE + ISOTP_ADD_MODE_OFST))
                            {
                                processCF = ISOTP_ONE;
                            }
                        }
                        /* Not the last CF */
                        else
                        {
                            if (dlc == (uint8)ISOTP_EIGHT)
                            {
                                processCF = ISOTP_ONE;
                            }
                        }

                        if (processCF == ISOTP_ONE)
#endif
                        {
                            /* Get the sequence number */
                            cFSeqNum = dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] & (uint8)ISOTP_SEQMASK;
                            /* Stop timer C */
                            ISOTP_NCTime = (uint32)ISOTP_ZERO;
                            /* Check if the received sequence number is correct */
                            if (cFSeqNum == 
                                  ((ISOTP_FrmCfg.seqNum + (uint8)ISOTP_ONE) & (uint8)ISOTP_SEQMASK))
                            {
                                /* Increment to next sequence number - same as cFSeqNum */
                                ISOTP_FrmCfg.seqNum = cFSeqNum;

                                /* change state to consecutive frame received */
                                ISOTP_St = (uint8)ISOTP_CFRX;

                                /* Decrement the nBytes by the number of data bytes 
                                   received in CF */
                                if (ISOTP_FrmCfg.nBytes >= (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
                                {
                                    /* Decrement number of bytes by 7 */
                                    ISOTP_FrmCfg.nBytes -= (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST);

                                    /* Copy the data received */
                                    for (idx = (uint8)ISOTP_ZERO; idx < (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST); idx++)
                                    {
                                        ISOTP_FrmCfg.tpBuff[ISOTP_TpBuffIdx + idx] =
                                                          dataBuff[idx + (uint8)(ISOTP_ONE + ISOTP_ADD_MODE_OFST)];
                                    }

                                    /* Increment the Tp buffer index */
                                    ISOTP_TpBuffIdx += idx;
                                }
                                else
                                {
                                    /* Copy the data received */
                                    for (idx = (uint16)ISOTP_ZERO; idx < ISOTP_FrmCfg.nBytes; idx++)
                                    {
                                        ISOTP_FrmCfg.tpBuff[ISOTP_TpBuffIdx + idx] =
                                                          dataBuff[idx + (uint8)(ISOTP_ONE + ISOTP_ADD_MODE_OFST)];
                                    }

                                    /* completely received the total number of bytes */
                                    ISOTP_FrmCfg.nBytes = (uint16)ISOTP_ZERO;
                                }

                                /* Decrement the block size length by the number of data bytes - */
                                /*  -  received in CF */
                                ISOTP_BSLen -= (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST);

                                /* If all the bytes have been received */
                                if (ISOTP_FrmCfg.nBytes == (uint16)ISOTP_ZERO)
                                {
                                    /* Call the message Indication function */
                                   
								   ISOTP_FrmCfg.ReqType = ReqType;

								   ISOTP_FrmCfg.nBytes = ISOTP_MultiFrameLen;

									ISOUDS_MsgIndi(&ISOTP_FrmCfg);
									/* Set Multiframe Status to FALSE */
						            ISOTP_StMultiFrame = ISOTP_FALSE;
                                    /* Reset Tp Parameters and change state to IDLE */
                                    ISOTP_Rst ();
                                }
                                /* another consecutive frame is awaited */
                                else if (ISOTP_BSLen > (uint8)ISOTP_ZERO)
                                {
                                    /* Start timer C */
                                    ISOTP_NCTime = (uint32)ISOTP_ONE;

                                    /* Change state to CF wait */
                                    ISOTP_St = (uint8)ISOTP_CFWAIT;
                                }
                                #if 0
                                /* flow control frame is to be transmitted */
                                else if (ISOTP_FrmCfg.nBytes > (uint16)ISOTP_ZERO)
                                {
                                    /* Start timer B */
                                    ISOTP_NBTime = (uint32)ISOTP_ONE;

                                    /* Change state to FC frame TX */
                                    ISOTP_St = (uint8)ISOTP_FCTXREQ;
                                }
                                #endif
                                /* flow control frame is to be transmitted */
                                else
                                {
                                    /* Start timer B */
                                    ISOTP_NBTime = (uint32)ISOTP_ONE;

                                    /* Change state to FC frame TX */
                                    ISOTP_St = (uint8)ISOTP_FCTXREQ;
                                }
                            }
                            /* Incorrect sequence number */
                            else
                            {
                                /* Reset Tp Parameters and change state to IDLE */
                                ISOTP_Rst ();

                                RespBuf[ISOTP_ZERO] = (uint8)ISOTP_NEGRES;
                                RespBuf[ISOTP_ONE]  = (uint8)Srv_id;
                                RespBuf[ISOTP_TWO]  = (uint8)ISOTP_RSE;
                                /*  MISRA: Assigning address of auto variable 'RespBuf' to static [MISRA 2004 Rule 17.6, required]
									Exception: RespBuf[ISOTP_ZERO] is used immediately in ISOTP_TxRequest() */
                                ISOTP_TP_Cfg.dataPtr = &RespBuf[ISOTP_ZERO];
                                ISOTP_TP_Cfg.dataLen = ISOTP_NEGRESPLEN;
                                
                                ISOTP_TxRequest(&ISOTP_TP_Cfg);

                                /* Reset UDS parameters */
                                ISOUDS_Rst ();

                                /* change the state to IDLE */
                                ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;
                            }
                        }
                    }
                }
                break;
            }
            
            /* Flow control */
            case ISOTP_FC:
            {
                /* Check if Tx is in Progress */
                if (ISOTP_NWLSt == (uint8)ISOTP_NWLST_TXINPROG)
                {
                    /* Check if Flow control frame is awaited */
                    if (ISOTP_St == (uint8)ISOTP_FCWAIT)
                    {
#if (ISOTP_ST_PADDING != ISOTP_PAD_REQUIRED)
                        if (dlc >= ((uint8)ISOTP_THREE + ISOTP_ADD_MODE_OFST)
#endif
                        {
                            /* Check if the Flow status is Continue To Send */
                            if ((dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] &
                                                        (uint8)ISOTP_SEQMASK) == (uint8)ISOTP_FCCTS)
                            {
                                /* Check if First flow control frame is already received or not */
                                if (ISOTP_FirstFCRcvd == (uint8)ISOTP_ZERO)
                                {
                                    /* Update Block Size */
                                    ISOTP_BlkSize = dataBuff[ISOTP_ONE + ISOTP_ADD_MODE_OFST];

                                    /* Check if seperation time is greater than 0x7F and not in the 
                                       range [F1, F9] */
                                    if (((dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST]) > (uint8)ISOTP_TIMERLMT1) &&
                                       (((dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST]) < (uint8)ISOTP_TIMERLMT2) ||
                                        ((dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST]) > (uint8)ISOTP_TIMERLMT3)))
                                    {
                                        /* limit values greater than 0x7F to max valid value 
                                           i.e.0x7F */
                                        ISOTP_STmin = 
                                                ((uint16)ISOTP_TIMERLMT1);
                                    }
                                    /* If seperation time is in the range [F1, F9] */
                                    else if (((dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST]) >= (uint8)ISOTP_TIMERLMT2) &&
                                    		 ((dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST]) <= (uint8)ISOTP_TIMERLMT3))
                                    {
                                        ISOTP_STmin = ((uint16)dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST]) -
                                                       (uint16)ISOTP_FRAMEMASK;
                                    }
                                    else
                                    {
                                        ISOTP_STmin = (uint16)dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST];
                                    }

                                    /* First flow frame received */
                                    ISOTP_FirstFCRcvd = (uint8)ISOTP_ONE;
                                }
                                
                                /* Check if block size is zero */
                                if (ISOTP_BlkSize == (uint8)ISOTP_ZERO)
                                {
                                    /* Transmit all blocks at a time */
                                    ISOTP_BSLen = (uint16)ISOTP_FrmCfg.nBytes;
                                }
                                else
                                {
                                    /* total number of bytes */
                                    ISOTP_BSLen = (uint16)((uint16)ISOTP_BlkSize * 
                                                           (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST));
                                }

                                ISOTP_TimeOutNC = ISOTP_STmin;

                                /* Stop timer B */
                                ISOTP_NBTime = (uint8)ISOTP_ZERO;

                                /* Request for Tx of CF is put immediately here - so no need of -
                                    - starting timer C here */

                                /* Change the state to Consecutive frame Tx Wait */
                                ISOTP_St = (uint8)ISOTP_CFTXWAIT;
								#if ((ISOTP_ADDRESSING == ISOTP_EXTENDED_ADD) || (ISOTP_ADDRESSING == ISOTP_MIXED_ADD))
								/* N_TA */
								ISOTP_canfrm.dataBuff[ISOTP_ZERO] = ISOTP_DEST_ADDRESS;
								#endif
                                /* N_PCI for CF */
                                ISOTP_canfrm.dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] = ISOTP_FrmCfg.frmInfo;

                                /* Data of consecutive frame to be transmitted */
                                if (ISOTP_FrmCfg.nBytes < (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
                                {
                                    for (idx = (uint16)ISOTP_ZERO; idx < ISOTP_FrmCfg.nBytes; idx++)
                                    {
                                        ISOTP_canfrm.dataBuff[idx + (uint8)ISOTP_ONE + ISOTP_ADD_MODE_OFST] =
                                                    ISOTP_FrmCfg.tpBuff[ISOTP_TpBuffIdx + idx];
                                    }

#if (ISOTP_ST_PADDING == ISOTP_PAD_REQUIRED)
                                    /* Perform Padding */
                                    ISOTP_PrfrmPad (ISOTP_FrmCfg.nBytes);

                                    ISOTP_canfrm.dlc = (uint8)ISOTP_EIGHT;
#else
                                    ISOTP_canfrm.dlc = (uint8)(ISOTP_FrmCfg.nBytes + ISOTP_ONE - ISOTP_ADD_MODE_OFST);

#endif
                                }
                                else
                                {
                                    for (idx = (uint8)ISOTP_ZERO; idx < (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST); idx++)
                                    {
                                        ISOTP_canfrm.dataBuff[idx + (uint8)ISOTP_ONE + ISOTP_ADD_MODE_OFST] =
                                                    ISOTP_FrmCfg.tpBuff[ISOTP_TpBuffIdx + idx];
                                    }

                                    ISOTP_canfrm.dlc = (uint8)ISOTP_EIGHT;
                                }

                                /* Start the timer A */
                                ISOTP_NATime = (uint32)ISOTP_ONE;

                                /* Request data link layer for Tx of CF */
                                (*ISOTP_TxReqConfTable[ISOTP_CHFlag])(ISOTP_canfrm.Msg_ID,\
                                		CANIL_STANDARD, ISOTP_canfrm.dlc, ISOTP_canfrm.dataBuff);

                            }
                            /* Flow control status is WAIT */
                            else if ((dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] & (uint8)ISOTP_SEQMASK) ==
                                                                                  (uint8)ISOTP_FCWT)
                            {
                                /* Re-start the timer B */
                                ISOTP_NBTime = (uint32)ISOTP_ONE;

                                /* Wait for next flow control frame */
                            }
                            /* If Flow status is overflow/ FS is incorrect */
                            else
                            {
                                /* Stop the timer B */
                                ISOTP_NBTime = (uint32)ISOTP_ZERO;

                                /* Reset Tp parameters and change state to IDLE */
                                ISOTP_Rst ();

                                /* Reset UDS parameters */
                                ISOUDS_Rst ();

                                /* Change the network status to IDLE */
                                ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;
                            }
                        }
                    }
                }
                break;
            }
            default:
            {
                /* Do Nothing */
                break;
            }
        }
		#if ((ISOTP_ADDRESSING == ISOTP_EXTENDED_ADD) || (ISOTP_ADDRESSING == ISOTP_MIXED_ADD))
		}
		#endif
    }
}

/***************************************************************************************************
** Function                 : ISOTP_TxRequest

** Description              : Transmits either single frame or first frame

** Parameter nBytes         : number of bytes to be transmitted

** Parameter txData         : Data array

** Return value             : ISOTP_TRUE - If tramission request is placed successfully
                              ISOTP_FALSE - If tramission request couldn't be placed

** Remarks                  : None
***************************************************************************************************/
uint8 ISOTP_TxRequest (const ISOTP_App_CfgType * ISOTP_MsgCfg)
{
    uint8 retVal;
    uint16 idx;

    /* For debug message transfer */
    if (ISOTP_MsgCfg->Msg_ID != 0)
    {
        ISOTP_CHFlag = ISOTP_MsgCfg-> ISOTP_CHFlag;
        ISOTP_canfrm.Msg_ID = ISOTP_MsgCfg->Msg_ID;
    }
    else
    {
       ISOTP_canfrm.Msg_ID = (uint32)ISOTP_TXOBD_CANID;  
    }
    
    /* Check if TP state is idle */
    if ((ISOTP_St == (uint8)ISOTP_IDLE) &&
            (ISOTP_MsgCfg->dataLen <= (uint16)ISOTP_BUFFSIZE))
    {
        /* Set the status to transmission in progress */
        ISOTP_NWLSt = (uint8)ISOTP_NWLST_TXINPROG;

        /* Set the timer limits */
        ISOTP_TimeOutNA = ((uint32)ISOTP_iTimeOut[ISOTP_TXIDX].tmrA);

        /* Start the timer A */
        ISOTP_NATime = (uint32)ISOTP_ONE;

        /* decide whether Single frame or segmented frames is/are needed */
        if (ISOTP_MsgCfg->dataLen <= ((uint16)ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
        {
            /* change the state to Single frame Transmission */
            ISOTP_St = (uint8)ISOTP_SFTX;

            /* Store the number of bytes */
            ISOTP_FrmCfg.nBytes = ISOTP_MsgCfg->dataLen;

            /* Form the SF frame */
			#if ((ISOTP_ADDRESSING == ISOTP_EXTENDED_ADD) || (ISOTP_ADDRESSING == ISOTP_MIXED_ADD))
			/* N_TA */
			ISOTP_canfrm.dataBuff[ISOTP_ZERO] = ISOTP_DEST_ADDRESS;
			#endif
            /* N_PCI */
            ISOTP_canfrm.dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] = (uint8)(ISOTP_MsgCfg->dataLen);

            /* N_Data */
            for (idx = (uint16)ISOTP_ZERO; idx < ISOTP_MsgCfg->dataLen; idx++)
            {
                ISOTP_FrmCfg.tpBuff[idx] = (ISOTP_MsgCfg->dataPtr)[idx];
                ISOTP_canfrm.dataBuff[idx + (uint16)ISOTP_ONE + ISOTP_ADD_MODE_OFST] = ISOTP_FrmCfg.tpBuff[idx];
            }

#if (ISOTP_ST_PADDING == ISOTP_PAD_REQUIRED)
            /* if necessary, pad the remaining bytes */
            if (ISOTP_MsgCfg->dataLen < ((uint8)ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
            {
                ISOTP_PrfrmPad (ISOTP_MsgCfg->dataLen + ISOTP_ADD_MODE_OFST);
            }

            ISOTP_canfrm.dlc = (uint8)ISOTP_EIGHT;
 
#else

            ISOTP_canfrm.dlc = (uint8)(ISOTP_MsgCfg->dataLen + 1 + ISOTP_ADD_MODE_OFST);

#endif

            	/* Request data link layer for Tx of CF */
            (*ISOTP_TxReqConfTable[ISOTP_CHFlag])(ISOTP_canfrm.Msg_ID,\
            		CANIL_STANDARD, ISOTP_canfrm.dlc, ISOTP_canfrm.dataBuff);

        }
        /* Segmentation necessary */
        else
        {
            /* change the state to First frame Transmission */
            ISOTP_St = (uint8)ISOTP_FFTX;

            /* Store the number of bytes */
            ISOTP_FrmCfg.nBytes = ISOTP_MsgCfg->dataLen;

            /* N_PCI - The data length is limited to 8bits - max 0xFF */
            ISOTP_FrmCfg.frmInfo = ((uint8)ISOTP_FF) |
                                   ((uint8)((ISOTP_FrmCfg.nBytes >> ISOTP_EIGHT) &
                                   ((uint16)ISOTP_SEQMASK)));

            /* Sequence number */
            ISOTP_FrmCfg.seqNum = (uint8)ISOTP_ZERO;

            /* Copy data to Tp buffer */
            for (idx = (uint16)ISOTP_ZERO; idx < ISOTP_MsgCfg->dataLen; idx++)
            {
                ISOTP_FrmCfg.tpBuff[idx] = (ISOTP_MsgCfg->dataPtr)[idx];
            }

            /* Set the timer limits */
            ISOTP_TimeOutNB = ((uint32)ISOTP_iTimeOut[ISOTP_TXIDX].tmrB);
            ISOTP_TimeOutNC = ((uint32)ISOTP_iTimeOut[ISOTP_TXIDX].tmrC);

			#if ((ISOTP_ADDRESSING == ISOTP_EXTENDED_ADD) || (ISOTP_ADDRESSING == ISOTP_MIXED_ADD))
			/* N_TA */
			ISOTP_canfrm.dataBuff[ISOTP_ZERO] = ISOTP_DEST_ADDRESS;
			#endif
			
            /* Form the FF */
            ISOTP_canfrm.dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] = ISOTP_FrmCfg.frmInfo;

            /* Length limited to 0xFF */
            ISOTP_canfrm.dataBuff[ISOTP_ONE + ISOTP_ADD_MODE_OFST] = (uint8)(ISOTP_FrmCfg.nBytes & ISOTP_ENDVALUE);

            /* first 6 bytes to be transmitted */
            for (idx = (uint8)ISOTP_ZERO; idx < ((uint8)ISOTP_SIX - ISOTP_ADD_MODE_OFST); idx++)
            {
                ISOTP_canfrm.dataBuff[idx + (uint8)ISOTP_TWO + ISOTP_ADD_MODE_OFST] = ISOTP_FrmCfg.tpBuff[idx];
            }

            ISOTP_canfrm.dlc = (uint8)ISOTP_EIGHT;

            
            /* Request data link layer for Tx of CF */
           (*ISOTP_TxReqConfTable[ISOTP_CHFlag])(ISOTP_canfrm.Msg_ID,\
        		   CANIL_STANDARD, ISOTP_canfrm.dlc, ISOTP_canfrm.dataBuff);
        }

        /* Return ISOTP_TRUE - if tx request is placed */
        retVal = (uint8)ISOTP_ONE;
    }
    else
    {
        /* Return ISOTP_FALSE - if tx request couldn't be placed */
        retVal = (uint8)ISOTP_ZERO;
    }

    return (retVal);
}

/***************************************************************************************************
** Function                 : ISOTP_TxCnfCbk

** Description              : Transmit callback function of Diagnostic frame

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void ISOTP_TxCnfCbk (void)
{
    /* check for the current state */
    switch (ISOTP_St)
    {
        /* TP state in Single frame Transmission */
        case ISOTP_SFTX:
        {
            /* Stop the timer A */
            ISOTP_NATime = (uint32)ISOTP_ZERO;

            /* Change the network state to IDLE */
            ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;

            /* Call the confirmation service primitive */
           
			ISOUDS_TxCnfCbk(&ISOTP_FrmCfg);

            /* reset Tp parameters and Go back to IDLE state */
            ISOTP_Rst ();           

            break;
        }
        
        /* TP state in First frame Transmission */
        case ISOTP_FFTX:
        {
            /* 6 bytes already transmitted in FF */
            ISOTP_FrmCfg.nBytes -= (uint16)ISOTP_SIX - ISOTP_ADD_MODE_OFST;

            /* Increment the sequence number */
            ISOTP_FrmCfg.seqNum += (uint8)ISOTP_ONE;

            /* form the PCI of CF to be transmitted */
            ISOTP_FrmCfg.frmInfo = (uint8)(ISOTP_CF) | (ISOTP_FrmCfg.seqNum);

            /* Next data byte idx of tp buffer to be transmitted */
            ISOTP_TpBuffIdx = (uint16)ISOTP_SIX - ISOTP_ADD_MODE_OFST;

            /* Stop the timer A */
            ISOTP_NATime = (uint32)ISOTP_ZERO;

            /* Start Timer B */
            ISOTP_NBTime = (uint32)ISOTP_ONE;

            /* Wait for FC frame */
            ISOTP_St = (uint8)ISOTP_FCWAIT;

            break;
        }
        
        /* TP state in Flow control transmission */
        case ISOTP_FCTX:
        {
            /* Stop timer A */
            ISOTP_NATime = (uint32)ISOTP_ZERO;

            /* Check if the flow status is continue to send */
            if ((ISOTP_FrmCfg.frmInfo & (uint8)ISOTP_SEQMASK) == (uint8)ISOTP_FCCTS)
            {
                /* Start timer C */
                ISOTP_NCTime = (uint32)ISOTP_ONE;

                /* Wait for CF frame */
                ISOTP_St = (uint8)ISOTP_CFWAIT;
            }
            /* flow status if overflow */
            else
            {
                /* reset Tp parametrs and go to IDLE state */
                ISOTP_Rst ();
            }
            break;
        }
        
        /* TP state in Consecutive frame Transmission wait state */
        case ISOTP_CFTXWAIT:
        {
            /* If BSLen is gretaer than or equal to 7 */
            if (ISOTP_BSLen >= (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
            {
                /* Decrement the block size by 7 */
                ISOTP_BSLen -= (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST);
            }

            /* Decrement the no. of bytes */
            if (ISOTP_FrmCfg.nBytes < (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
            {
                ISOTP_FrmCfg.nBytes = (uint16)ISOTP_ZERO;
            }
            else
            {
                ISOTP_FrmCfg.nBytes -= (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST);
            }

            /* Stop timer A */
            ISOTP_NATime = (uint32)ISOTP_ZERO;

            /* Check if all bytes are transmitted */
            if (ISOTP_FrmCfg.nBytes == (uint16)ISOTP_ZERO)
            {
                /* Change the network state to IDLE */
                ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;

                /* Indicate the SrvD of Tx finished */
                
				ISOUDS_TxCnfCbk(&ISOTP_FrmCfg);

                /* Reset Tp parameters and change state to IDLE */
                ISOTP_Rst ();               
            }
            
            /* Check if another block is to be transmitted */
            else if (ISOTP_BSLen > (uint16)ISOTP_ZERO)
            {
                /* Increment the tp buffer index */
                ISOTP_TpBuffIdx += (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST);

                /* Next sequence number */
                ISOTP_FrmCfg.seqNum = 
                                    (ISOTP_FrmCfg.seqNum + (uint8)ISOTP_ONE) & (uint8)ISOTP_SEQMASK;

                /* Form the PCI of next CF */
                ISOTP_FrmCfg.frmInfo = (uint8)ISOTP_CF | ISOTP_FrmCfg.seqNum;

                /* Start timer C */
                ISOTP_NCTime = (uint32)ISOTP_ONE;

                /* Change state to CFTX */
                ISOTP_St = (uint8)ISOTP_CFTX;
            }
            
            /* if BSlen is zero Wait for Flow control frame */
            else
            {
                /* Increment the tp buffer index */
                ISOTP_TpBuffIdx += (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST);

                /* Next sequence number */
                ISOTP_FrmCfg.seqNum = (ISOTP_FrmCfg.seqNum + 
                                      (uint8)ISOTP_ONE) & (uint8)ISOTP_SEQMASK;

                /* Form the PCI of next CF */
                ISOTP_FrmCfg.frmInfo = (uint8)ISOTP_CF | ISOTP_FrmCfg.seqNum;

                /* Start Timer B*/
                ISOTP_NBTime = (uint32)ISOTP_ONE;

                /* Wait for FC frame */
                ISOTP_St = (uint8)ISOTP_FCWAIT;
            }
            break;
        }
        
        default:
        {
            /* Do Nothing */
            break;
        }
    }
}

/***************************************************************************************************
** Function                 : ISOTP_Main

** Description              : TP Main function, runs continuously in Background

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
void ISOTP_Main (void)
{
    uint16 idx;

    /* If state is in consecutive frame transmission state */
    if (ISOTP_St == (uint8)ISOTP_CFTX)
    {
        /* Check if STMin value is reached */
        if (ISOTP_NCTime >= ISOTP_STmin)
        {
			#if ((ISOTP_ADDRESSING == ISOTP_EXTENDED_ADD) || (ISOTP_ADDRESSING == ISOTP_MIXED_ADD))
			/* N_TA */
			ISOTP_canfrm.dataBuff[ISOTP_ZERO] = ISOTP_DEST_ADDRESS;
			#endif		
            /* N_PCI for CF */
            ISOTP_canfrm.dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] = ISOTP_FrmCfg.frmInfo;

            /* Data of consecutive frame to be transmitted */
            if (ISOTP_FrmCfg.nBytes < (uint16)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST))
            {
                for (idx = (uint16)ISOTP_ZERO; idx < ISOTP_FrmCfg.nBytes; idx++)
                {
                    ISOTP_canfrm.dataBuff[idx + (uint16)ISOTP_ONE + ISOTP_ADD_MODE_OFST] =
                                ISOTP_FrmCfg.tpBuff[ISOTP_TpBuffIdx + idx];
                }

#if (ISOTP_ST_PADDING == ISOTP_PAD_REQUIRED)
                /* Peform Padding */
                ISOTP_PrfrmPad (ISOTP_FrmCfg.nBytes);

                ISOTP_canfrm.dlc = (uint8)ISOTP_EIGHT;
#else
                ISOTP_canfrm.dlc = (uint8)(ISOTP_FrmCfg.nBytes + ISOTP_ONE + ISOTP_ADD_MODE_OFST);
#endif
            }
            else
            {
                for (idx = (uint8)ISOTP_ZERO; idx < (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST); idx++)
                {
                  ISOTP_canfrm.dataBuff[idx + (uint8)(ISOTP_ONE + ISOTP_ADD_MODE_OFST)] =
                                                         ISOTP_FrmCfg.tpBuff[ISOTP_TpBuffIdx + idx];
                }
                ISOTP_canfrm.dlc = (uint8)ISOTP_EIGHT;
            }

            /* Stop timer C */
            ISOTP_NCTime = (uint32)ISOTP_ZERO;

            /* Start Timer A */
            ISOTP_NATime = (uint32)ISOTP_ONE;

            /* Change state to CFTXWAIT */
            ISOTP_St = (uint8)ISOTP_CFTXWAIT;

            /* Request data link layer for Tx of CF */
           (*ISOTP_TxReqConfTable[ISOTP_CHFlag])(ISOTP_canfrm.Msg_ID,\
        		   CANIL_STANDARD, ISOTP_canfrm.dlc, ISOTP_canfrm.dataBuff);
        }
    }
    /* If state is in FCTXREQ */
    else if (ISOTP_St == (uint8)ISOTP_FCTXREQ)
    {
		#if ((ISOTP_ADDRESSING == ISOTP_EXTENDED_ADD) || (ISOTP_ADDRESSING == ISOTP_MIXED_ADD))
		/* N_TA */
		ISOTP_canfrm.dataBuff[ISOTP_ZERO] = ISOTP_DEST_ADDRESS;
		#endif	
        /* N_PCI for FC */
        ISOTP_canfrm.dataBuff[ISOTP_ZERO + ISOTP_ADD_MODE_OFST] = ISOTP_FrmCfg.frmInfo;

        ISOTP_canfrm.dataBuff[ISOTP_ONE + ISOTP_ADD_MODE_OFST] = (uint8)ISOTP_FCBS;

        /* store the Block Size length */
        ISOTP_BSLen = (uint16)ISOTP_FCBS * (uint8)(ISOTP_SEVEN - ISOTP_ADD_MODE_OFST);

        /* Store the minimum separation time */
        ISOTP_canfrm.dataBuff[ISOTP_TWO + ISOTP_ADD_MODE_OFST] = (uint8)ISOTP_FCSTMIN;

#if (ISOTP_ST_PADDING == ISOTP_PAD_REQUIRED)
        /* pad the remaining bytes*/
        ISOTP_PrfrmPad ((uint8)(ISOTP_TWO + ISOTP_ADD_MODE_OFST));
        ISOTP_canfrm.dlc = (uint8)ISOTP_EIGHT;

#else
        ISOTP_canfrm.dlc = (uint8)ISOTP_THREE + ISOTP_ADD_MODE_OFST;
#endif

        /* Stop timer B */
        ISOTP_NBTime = (uint32)ISOTP_ZERO;

        /* Start timer A */
        ISOTP_NATime = (uint32)ISOTP_ONE;

        /* Change state to FC TX */
        ISOTP_St = (uint8)ISOTP_FCTX;

        /* Request data link layer for Tx of CF */
       (*ISOTP_TxReqConfTable[ISOTP_CHFlag])(ISOTP_canfrm.Msg_ID,\
    		   CANIL_STANDARD, ISOTP_canfrm.dlc, ISOTP_canfrm.dataBuff);
    }
    else
    {
        /* Do Nothing */
    }

    /* Call the timer Monitoring Function */
    ISOTP_iTmrMon ();
}

/***************************************************************************************************
** Function                 : ISOTP_GetStatus

** Description              : Returns the status of TP module.

** Parameter rxData         : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
uint8 ISOTP_GetStatus(void)
{
   /* Reurn the Status of ISOTP. */
   return(ISOTP_St);
}


/**************************** Internal Function definitions ***************************************/

/***************************************************************************************************
** Function                 : ISOTP_Rst

** Description              : Resets the required TP parameters.

** Parameter rxData         : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
static void ISOTP_Rst (void)
{
    /* Reset the Block size length */
    ISOTP_BSLen = (uint16)ISOTP_ZERO;

    /* Reset the first Flow control frame received to ISOTP_FALSE */
    ISOTP_FirstFCRcvd = (uint8)ISOTP_ZERO;

    /* Reset the Tp buffer index to 0 */
    ISOTP_TpBuffIdx = (uint8)ISOTP_ZERO;

    /* Reset the frame info */
    ISOTP_FrmCfg.frmInfo = (uint8)ISOTP_ZERO;

    /* Reset the sequence number */
    ISOTP_FrmCfg.seqNum = (uint8)ISOTP_ZERO;

    /* Reset the number of bytes */
    ISOTP_FrmCfg.nBytes = (uint16)ISOTP_ZERO;

    /* change state to IDLE */
    ISOTP_St = (uint8)ISOTP_IDLE;

    /* Reset MultiFrame status */
    ISOTP_StMultiFrame = ISOTP_FALSE;
}

/***************************************************************************************************
** Function                 : ISOTP_iTmrMon

** Description              : Monitors the TP timers.

** Parameter rxData         : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
static void ISOTP_iTmrMon (void)
{
    /* Check if counter A is running */
    if (ISOTP_NATime > (uint32)ISOTP_ZERO)
    {
        /* Check if the counter limit is reached */
        if (ISOTP_NATime >= ISOTP_TimeOutNA)
        {
            /* Abort Message transmission/ reception */
            ISOTP_Rst ();
            ISOUDS_Rst();

            /* Reset the counter */
            ISOTP_NATime = (uint32)ISOTP_ZERO;

            /* Clear the transmission request placed */
            ISOTP_CANIF_ABORTTRANSMIT();

            /* Change the network status to IDLE */
            ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;
        }
        /* Else increment the counter */
        else
        {
            ISOTP_NATime += (uint32)ISOTP_PERIOD_SCHED;
        }
    }

    /* Check if counter B is running */
    if (ISOTP_NBTime > (uint32)ISOTP_ZERO)
    {
        /* Check if the counter limit is reached */
        if (ISOTP_NBTime >= ISOTP_TimeOutNB)
        {
            /* Abort Message transmission/ reception */
            ISOTP_Rst ();
            ISOUDS_Rst();
			
            /* Reset the counter */
            ISOTP_NBTime = (uint32)ISOTP_ZERO;            

            /* Change the network status to IDLE */
            ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;
        }
        /* Else increment the counter */
        else
        {
            ISOTP_NBTime += (uint32)ISOTP_PERIOD_SCHED;
        }
    }

    /* Check if counter C is running */
    if (ISOTP_NCTime > (uint32)ISOTP_ZERO)
    {
        /* Check if the counter limit is reached */
        if (ISOTP_NCTime >= ISOTP_TimeOutNC)
        {
            /* Abort Message transmission/ reception */
            ISOTP_Rst ();
            ISOUDS_Rst();
 
            /* Reset the counter */
            ISOTP_NCTime = (uint32)ISOTP_ZERO;            

            /* Change the network status to IDLE */
            ISOTP_NWLSt = (uint8)ISOTP_NWLST_IDLE;
        }
        /* Else increment the counter */
        else
        {
            ISOTP_NCTime += (uint32)ISOTP_PERIOD_SCHED;
        }
    }
}

FUNC(uint8, CAN_CODE) ISOTP_GetMultiframeStat(void)
{
	return ISOTP_StMultiFrame;
}

FUNC(void, CAN_CODE) ISOTP_ResetMultiframeStat(void)
{
	ISOTP_StMultiFrame = ISOTP_FALSE;
}

#if (ISOTP_ST_PADDING == ISOTP_PAD_REQUIRED)
/***************************************************************************************************
** Function                 : ISOTP_PrfrmPad

** Description              : Indicates that a new request has been received

** Parameter                : None

** Return value             : None

** Remarks                  : None
***************************************************************************************************/
static void ISOTP_PrfrmPad (uint16 byteIdx)
{
    uint8 idx;

    /* append the remaining bytes */
    for (idx = (uint8)byteIdx; idx < (uint8)ISOTP_SEVEN; idx++)
    {
        ISOTP_canfrm.dataBuff[idx + (uint8)ISOTP_ONE] = (uint8)ISOTP_PADDATA_VAL;
    }
}

#endif

