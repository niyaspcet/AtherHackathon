/***************************************************************************************************
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOUDS_SA.c
**
** Description  : Security Access Service
**
** -------------------------------------------------------------------------------------------------
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "ISOUDS.h"
#include "ISOUDS_SA.h"
#include "ISOUDS_AES128.h"

/********************** Declaration of local symbol and constants *********************************/
/* Request Seed security access Type */
#define     ISOUDS_SAREQSEED            ((uint8)1)
/* Send Key security access Type */
#define     ISOUDS_SASENDKEY            ((uint8)2)

/* Seed SIZE */
#define     ISOUDS_SASEED_MAXSIZE           (32)
/* Security Access Service length */
#define     ISOUDS_SASERLEN             (2)
/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/

/******************************* Declaration of local constants ***********************************/

/* Variable holding intermediate message state.*/
uint8_t MasterKeyVal[16U] =
{	0x00U,
	0x01U,
	0x02U,
	0x03U,
	0x04U,
	0x05U,
	0x06U,
	0x07U,
	0x08U,
	0x09U,
	0x0AU,
	0x0BU,
	0x0CU,
	0x0DU,
	0x0EU,
	0x0FU
};


/****************************** Declaration of exported variables *********************************/
/* Is seed Static or to be generated each time when Unlock request comes is decided by this variable */
/* ISOUDS_TRUE = Same seed everytime for same level
   ISOUDS_FALSE = Random seed is generated every time */
uint8 ISOUDS_SAStatic_Seed;

/* Status to indicate which security Access level is currently there */
uint8 ISOUDS_SALevel;
/* Attempt counts if Exceeds limit ECU is locked for some time and
will not accept any request for unlocking */
uint8 ISOUDS_SAAttCnt;

/* Timers */
/* Security Access Delay timer for session.
After this time particular session will time out and ECU will lock again */
uint32 ISOUDS_SATimerSession;
/* Security Access Delay timer for Recevie key
Under this time the key should be Received for send seed.otherwise it will be count as ISOUDS_FALSE attempt*/
uint32 ISOUDS_SATimerWaitingForKey;
/* Security Access delay timer to lock ECU if attempt count exceeds limit */
uint32 ISOUDS_SATimerAttCntExceeded;

/* Requested Current Security levels */
uint8 ISOUDS_SACurrentRequestedLevel;

/* To start stop the timers */
uint32 ISOUDS_SATimerSessionRunning;
uint32 ISOUDS_SATimerWaitingForKeyRunning;
uint32 ISOUDS_SATimerAttCntExceededRunning;
uint32 ISOUDS_SALockTime;

uint32 ISOUDS_SAPowerOnDelayTime;
uint8 ISOUDS_SAPowerOnDelayFlag;


/* Variable to Check ISOUDS Session change */
uint8 ISOUDS_OldSess;

/* Seed */
uint8 GenratedSeed[ISOUDS_SASEED_MAXSIZE]  = { 0x00U };

/* security access Service State */
static uint8 ISOUDS_SAState;
/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/
static void ISOUDS_GetSeed (uint8 *datavalue,uint8 SeedSize);
static uint8 ISOUDS_ValidateKey (uint8 *datavalue, uint8 SecurityLevel);
/******************************** Function definitions ********************************************/

/***************************************************************************************************
** Function                 : ISOUDS_SAInit

** Description              : Initializes the required security parameters

** Parameter                : None

** Return value             : None
***************************************************************************************************/
void ISOUDS_SAInit (uint8 bootFlag)
{
    /* Initialize the ECU Unlock status to ISOUDS_FALSE */
    if(bootFlag == 0)
    {
        ISOUDS_StECUUnLock = ISOUDS_FALSE;
	ISOUDS_SAPowerOnDelayFlag = ISOUDS_TRUE;
	ISOUDS_SAPowerOnDelayTime = 1;
    }
    else
    {
       // ISOUDS_StECUUnLock = ISOUDS_TRUE; // Already Unlocked in Application
	ISOUDS_SAPowerOnDelayFlag = ISOUDS_FALSE;
	ISOUDS_SAPowerOnDelayTime = 0;
    }
    /* Is seed Static or to be generated each time when Unlock request comes is decided by this variable */
    /* ISOUDS_TRUE = Same seed everytime for same level
       ISOUDS_FALSE = Random seed is generated every time */
    ISOUDS_SAStatic_Seed = ISOUDS_TRUE;

    /* Status to indicate which security Access level is currently there */
    ISOUDS_SALevel = 0x00;
    /* Attempt counts if Exceeds limit ECU is locked for some time and
    will not accept any request for unlocking */
    ISOUDS_SAAttCnt = 0x00;

    /* Timers */
    /* Security Access Delay timer for session.
    After this time particular session will time out and ECU will lock again */
    ISOUDS_SATimerSession = 0x0000;
    /* Security Access Delay timer for Recevie key
    Under this time the key should be Received for send seed.otherwise it will be count as ISOUDS_FALSE attempt*/
    ISOUDS_SATimerWaitingForKey = 0x0000;
    /* Security Access delay timer to lock ECU if attempt count exceeds limit */
    ISOUDS_SATimerAttCntExceeded = 0x0000;

    /* Requested Current Security levels */
    ISOUDS_SACurrentRequestedLevel = 0x00;

    /* To start stop the timers */
    ISOUDS_SATimerSessionRunning = ISOUDS_FALSE;
    ISOUDS_SATimerWaitingForKeyRunning = ISOUDS_FALSE;
    ISOUDS_SATimerAttCntExceededRunning = ISOUDS_FALSE;
	


    /* security access Service State */
    ISOUDS_SAState = ISOUDS_SA_STATE_A;

    /* Variable to Check ISOUDS Session change */
    ISOUDS_OldSess = ISOUDS_DS;
}

/***************************************************************************************************
** Function                 : ISOUDS_SA

** Description              : Sends the response to security access service request

** Parameter ISOUDSConfPtr  : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : None
***************************************************************************************************/
void ISOUDS_SA (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[])
{
    uint8 iChkValidKey = 0x00;
    uint8 idx = 0x00;
    uint8 iSAlevelSupported = 0x00;
    uint8 SecLevel;
    static uint16 SeedSize = 0;
	uint8 CheckRequestedLevel;

    /* Reimplementation of SA as per Appendix I,ISO 14229-1    */
    /*---------------------------------------------------------------------------------------------------------------------------------------------*/
    /* Check if the security access type is of requestSeed */
	CheckRequestedLevel = dataBuff[0];
    if(((CheckRequestedLevel % 2) == 1) && (CheckRequestedLevel >= 1)&& (CheckRequestedLevel <= 41))
    {
		ISOUDS_SAState = ISOUDS_SA_STATE_A;
	}
	else
	{
		/* Do Nothing */
	}
	
    /* If attempt count is exceeded,ignore everything until timer expires */
    if(((ISOUDS_SATimerAttCntExceededRunning == ISOUDS_TRUE) ||
		((uint8)TRUE == ISOUDS_SAPowerOnDelayFlag)) &&
		(((CheckRequestedLevel % 2) == 1) && (CheckRequestedLevel >= 1)&& (CheckRequestedLevel <= 41)))
    {
        /* Negative response */
       ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

       /* NRC - Request Sequence Error */
       ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_RTDNE;
    }
    else
    {
        switch(ISOUDS_SAState)
        {
            case ISOUDS_SA_STATE_A:
            case ISOUDS_SA_STATE_C:
            {
                /* If service is invoked due to reception of new request */
                if (ISOUDSConfPtr->srvSt == (uint8)ISOUDS_RXMSG)
                {
					/* store the security access type */
					ISOUDS_SACurrentRequestedLevel = dataBuff[0];

					/* Check if the security access type is of requestSeed */
					if (((ISOUDS_SACurrentRequestedLevel%2) == 1) && ((1 <= ISOUDS_SACurrentRequestedLevel) && (ISOUDS_SACurrentRequestedLevel  <= 41)))
					{
						/* If sufficient bytes are received */
						if (ISOUDSConfPtr->srvLen == (uint16)ISOUDS_SASERLEN)
						{
                            /* Check if ECU is already unlocked with current level or not */
                            if ((ISOUDS_StECUUnLock == ISOUDS_TRUE) && (ISOUDS_SACurrentRequestedLevel == ISOUDS_SALevel))
                            {
                                /* Send positive response with seed = 0 */
                                /* prepare the response */
                                dataBuff[0] = ISOUDS_SACurrentRequestedLevel;
                                
                                if(ISOUDS_SACurrentRequestedLevel == 0x01)
                                {
                                	SeedSize = ISOUDS_TOTAL_SEED_SIZE;
                                }
                                else
                                {
                                	/* Do nothing */
                                }
                                
                                /* Send seed with a value of zero */
                                for (idx = (uint8)1; idx <= (uint8)SeedSize; idx++)
                                {
                                  dataBuff[idx] = (uint8)0x00;
                                }

                                /* Response length for the current Service - including SID */
                                ISOUDSConfPtr->srvLen = (uint16)SeedSize + (uint16)2;

                                /* Send positive response */
                                ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
								
								ISOUDS_SAState = ISOUDS_SA_STATE_D;
                            }
                            else
                            {
                                /* Clear SA level check supported or not */
                                //iSAlevelSupported = ISOUDS_FALSE;

                                /* Check here if the particular security level is supported or not
                                If supported add the code in case to genrate particular level seed and
                                put in buffer,else send negative response */
                                /* whatever security level is supported please add the code in that case to generate that
                                seed,fill that seed and set iSAlevelSupported = ISOUDS_TRUE; */
                                switch(ISOUDS_SACurrentRequestedLevel)
                                {
                                	case 1:
                                	{
                                	   iSAlevelSupported = ISOUDS_TRUE;

                                	   SeedSize = ISOUDS_TOTAL_SEED_SIZE;

                                	   ISOUDS_GetSeed((uint8 *)(&dataBuff[1]),SeedSize);

                                	 }
                                	break;

                                    default:
                                    {
                                        iSAlevelSupported = ISOUDS_FALSE;

                                        /****************************************************************

                                        INSERT CODE TO GENERATE SEED AND UPDATE THE VARIABLE
                                        iSAlevelSupported Accordingly.

                                        *****************************************************************/
                                        /****************************************************************

                                        INSERT CODE TO COPY GENERATED SEED INTO RESPONSE BUFFER
                                        E.g.
                                        for (idx = (uint8)0; idx < (uint8)32; idx++)
                                        {
                                        dataBuff[idx + (uint8)1] = GenratedSeed[idx];
                                        }

                                        *****************************************************************/

                                    }
                                    break;
                                }

                                if(iSAlevelSupported == ISOUDS_TRUE)
                                {
                                    /* Send positive response */

                                    /* Change state machine to Seed send waiting for response */
                                    /* If any one state is unlocked then change to State D else state B */
                                    if(ISOUDS_StECUUnLock == ISOUDS_TRUE)
                                    {
                                        ISOUDS_SAState = ISOUDS_SA_STATE_D;
                                    }
                                    else
                                    {
                                        ISOUDS_SAState = ISOUDS_SA_STATE_B;
                                    }

                                    /* Get the Current timer value. */
                                    ISOUDS_SATimerWaitingForKey = 1;

                                    /* Change current Security level to Requested level */
                                    ISOUDS_SALevel = ISOUDS_SACurrentRequestedLevel;

                                    /* prepare the response */
                                    dataBuff[0] = ISOUDS_SACurrentRequestedLevel;

                                    /* Response length for the current Service - including SID */
                                    ISOUDSConfPtr->srvLen = ((uint16)SeedSize + (uint16)2);

                                    /* Send positive response */
                                    ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
                                }
                                else
                                {
                                    /* Security level is not supported send negative response */
                                    /* Negative response */
                                    ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                                    /* NRC - subFunction not suported */
                                    ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
                                }
                            }
                        }
						else
						{
							/* Negative response */
							ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

							/* NRC - Request Sequence Error */
							ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
						}
					}
					else if ((ISOUDS_SACurrentRequestedLevel == 4) || (ISOUDS_SACurrentRequestedLevel == 8) || (ISOUDS_SACurrentRequestedLevel == 42))
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

						/* NRC - Request Sequence Error */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_RSE;
					}
					else
					{
						/* Negative response */
						ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

						/* Invalid Message Length Or Invalid Format */
						ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
					}
                }
                else
                {
                    /* Negative response */
                    ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                    /* NRC - Request Sequence Error */
                    ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
                }
            }
            break;
            case ISOUDS_SA_STATE_B:
            case ISOUDS_SA_STATE_D:
            {
                /* If service is invoked due to reception of new request */
                if ((ISOUDSConfPtr->srvSt == (uint8)ISOUDS_RXMSG) &&
					(ISOUDS_SAState == ISOUDS_SA_STATE_B))
                {
                    /* If sufficient bytes are received */
                    if (ISOUDSConfPtr->srvLen == (ISOUDS_SA_KEY_SIZE + (uint16)2))
                    {

                            SecLevel = dataBuff[0];

                    
                        
                        if(((SecLevel%2) == 0) && ((2 <= SecLevel) && (SecLevel <= 42)))
                        {
                            /* Clear SA level check supported or not */
                            //iSAlevelSupported = ISOUDS_FALSE;
                            /* Clear Valid key check */
                            //iChkValidKey = ISOUDS_FALSE;

                            /* Check here if the particular security level is supported or not
                            If supported add the code in case to validate particular level key and
                            fill in buffer,else send negative response */
                            /* whatever security level is supported please add the code in that case to validate that
                            key,fill that key and set iSAlevelSupported = ISOUDS_TRUE; */
                            switch(SecLevel)
                            {
                            	case 2:
                                {
                                    iSAlevelSupported = ISOUDS_TRUE;

                                    /* Compare received Key request with Generated one */
                                    if(ISOUDS_ValidateKey((uint8 *)(&dataBuff[1]), SecLevel))
                                    {
                                      iChkValidKey = ISOUDS_TRUE;
                                    }
                                    else
                                    {
                                      iChkValidKey = ISOUDS_FALSE;
                                    }
                                }
                                break;
                                default:
                                {
                                    iSAlevelSupported = ISOUDS_FALSE;

                                    /****************************************************************

                                    INSERT CODE TO VALIDATE KEY & ACCORDINGLY UPDATED THE VARIABLE
                                    iChkValidKey. IF iChkValidKey IS ISOUDS_TRUE, THEN KEY IS VALID.

                                    *****************************************************************/

                                    iChkValidKey = ISOUDS_FALSE;
                                }
                                break;
                            }

                            if(iSAlevelSupported == ISOUDS_TRUE)
                            {
                                /* Check if the received key matches with the generated key */
                                if (iChkValidKey == ISOUDS_TRUE)
                                {
                                    /* Unlock the ECU */
                                    ISOUDS_StECUUnLock = ISOUDS_TRUE;

                                    /* Store current Unlocked level */
                                    ISOUDS_SALevel = ISOUDS_SACurrentRequestedLevel;

                                    /* Send positive response */
                                    dataBuff[0] = ISOUDS_SALevel +1;

                                    /* Response length for the current Service - including SID */
                                    ISOUDSConfPtr->srvLen = (uint16)2;

                                    /* Send positive response */
                                    ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;

                                    /* Start the Session Timer */
                                    ISOUDS_SATimerSessionRunning = ISOUDS_TRUE;

                                    /* Get the Current timer value. */
                                    ISOUDS_SATimerSession = 1;

                                    /* Clear the attempt Counter */
                                    ISOUDS_SAAttCnt = 0x00;

                                    /* Change State */
                                    ISOUDS_SAState = ISOUDS_SA_STATE_C;

                                    /* Stop waiting for key Timer */
                                    ISOUDS_SATimerWaitingForKeyRunning = ISOUDS_FALSE;

                                    /* Clear waitng for Key Timer */
                                    ISOUDS_SATimerWaitingForKey = 0x0000;
                                }
                                /* Invalid key is provided */
                                else 
                                {
                                    /* Invalid Key So increment attempt count */
                                    ISOUDS_SAAttCnt++;

                                    /* Check for Attempt counts and start Timer */
                                    if(ISOUDS_SAAttCnt > ISOUDS_MAXATTEMTCOUNT)
                                    {
                                        if(ISOUDS_SATimerAttCntExceeded == 0U)
                                        {
                                            /* Start attempt count timer to block future attempts */
                                            /* Get the Current timer value. */
                                            ISOUDS_SATimerAttCntExceeded = 1;
											
											ISOUDS_SATimerAttCntExceededRunning = ISOUDS_TRUE;
                                        }
                                        /* Negative response */
                                        ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                                        /* NRC - invalid key */
                                        ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_ENOA;
                                    }
                                    else
                                    {
                                        /* Negative response */
                                        ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                                        /* NRC - invalid key */
                                        ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IK;

                                        /* Stop waiting for key Timer */
                                        ISOUDS_SATimerWaitingForKeyRunning = ISOUDS_FALSE;

                                        /* Clear waitng for Key Timer */
                                        ISOUDS_SATimerWaitingForKey = 0x0000;
                                    }
                                }
                               
                            }
                            else
                            {
                                /* Negative response */
                                ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                                /* NRC - subFunction not suported */
                                ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
                            }
                        }
                        else
                        {
                            /* Negative response */
                            ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                            /* NRC - subFunction not suported */
                            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
                        }
                    }
                    else
                    {
                        /* Negative response */
                        ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                        /* Invalid Message Length Or Invalid Format */
                        ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
                    }
                }
                else
                {
                    /* Negative response */
                    ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                    /* NRC - Request Sequence Error */
                    ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_RSE;
                }
            }
            break;

            default:
            {
                /* Negative response */
                ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

                /* Invalid Message Length Or Invalid Format */
                ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
            }
            break;
        }
    }
}

/***************************************************************************************************
** Function                 : ISOUDS_GetSASt

** Description              : Gets ECU Lock Status

** Parameter ISOUDSConfPtr  : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : None
***************************************************************************************************/
uint8 ISOUDS_GetSASt (void)
{
    return (ISOUDS_StECUUnLock);
}

/***************************************************************************************************
** Function                 : ISOUDS_SAChkTimer

** Description              : Check Timers and Session change to lock ECU

** Parameter ISOUDSConfPtr  : void

** Parameter dataBuff       : void

** Return value             : None
***************************************************************************************************/
void ISOUDS_SAChkTimer (void)
{
    if (ISOUDS_SATimerSession > 0)
    {
        /* Check for timer overflow */
        if(ISOUDS_SATimerSession >= ISOUDS_SASESSIONTIMERMAX)
        {
            /* Session Timeout Lock ECU and Reset Everything */
            ISOUDS_SAReset();

            /* Stop timer */
            ISOUDS_SATimerSessionRunning = ISOUDS_FALSE;

            /* Clear Timer */
            ISOUDS_SATimerSession = 0;
        }else
		{
			ISOUDS_SATimerSession += ISOUDS_PERIOD_SCHED;
		}
		
    }


    if (ISOUDS_SATimerWaitingForKey > 0)
    {
        /* Check for timer overflow */
        if(ISOUDS_SATimerWaitingForKey >= ISOUDS_SAWAITKEYMAX)
        {
            /* Key not Received */
            ISOUDS_SAReset();

            /* Increment Attempt Count */
            ISOUDS_SAAttCnt++;

            /* Stop timer */
            ISOUDS_SATimerWaitingForKeyRunning = ISOUDS_FALSE;

            /* Clear Timer */
            ISOUDS_SATimerWaitingForKey = 0;
        }
		else
		{
			ISOUDS_SATimerWaitingForKey += ISOUDS_PERIOD_SCHED;
		}
    }

    if (ISOUDS_SATimerAttCntExceeded > 0)
    {
        /* Check for timer overflow */
        if(ISOUDS_SATimerAttCntExceeded >= ISOUDS_SASESSIONTIMERMAX)
        {
            /* Attempt Timer Expired Allow ECU Unlocking */
            ISOUDS_SAReset();

            /* Clear Attempt Count */
            ISOUDS_SAAttCnt = 0;

            /* Stop timer */
            ISOUDS_SATimerAttCntExceededRunning = ISOUDS_FALSE;

            /* Clear Timer */
            ISOUDS_SATimerAttCntExceeded = 0;

            /* Get the Current timer value. */
            ISOUDS_SALockTime = 1;

            /* Clear the timer. */
            ISOUDS_SATimerSession = 0;

            /* Clear the timer. */
            ISOUDS_SATimerWaitingForKey = 0;
        }
		else
		{
			ISOUDS_SATimerAttCntExceeded += ISOUDS_PERIOD_SCHED;
		}

    }

    if (ISOUDS_SALockTime > 0)
    {
        /* Check for timer overflow */
        if(ISOUDS_SALockTime >= ISOUDS_SALOCKPERIOD)
        {
            /* Attempt Timer Expired Allow ECU Unlocking */
            ISOUDS_SAReset();

            /* Clear Attempt Count */
            ISOUDS_SAAttCnt = 0;

            /* Stop timer */
            ISOUDS_SATimerAttCntExceededRunning = ISOUDS_FALSE;

            /* Clear Timer */
            ISOUDS_SATimerAttCntExceeded = 0;

            /* Clear Timer. */
            ISOUDS_SALockTime = 0;
        }
		else
		{
			ISOUDS_SALockTime += ISOUDS_PERIOD_SCHED;
		}
    }

    /* Check for ECU Session change.IF session changes lock ECU and
        Reset Service Layer */
    if(ISOUDS_OldSess != ISOUDS_Sess)
    {
        /* Session change Reset SA */
        ISOUDS_SAReset();
    }
	
	if ((ISOUDS_SAPowerOnDelayTime > 0) && (ISOUDS_SAPowerOnDelayFlag == ISOUDS_TRUE))
	{
		if (ISOUDS_SAPowerOnDelayTime > ISOUDS_SAPOWERON_DELAY)
		{
			ISOUDS_SAPowerOnDelayFlag = ISOUDS_FALSE;
		}
		else
		{
			ISOUDS_SAPowerOnDelayTime += ISOUDS_PERIOD_SCHED;
		}
	}

    /* Copy current session into old for checking */
    ISOUDS_OldSess = ISOUDS_Sess;
}

/***************************************************************************************************
** Function                 : ISOUDS_SAReset

** Description              : Resets the SA service parameters

** Parameter ISOUDSConfPtr  : void

** Parameter dataBuff       : void

** Return value             : None
***************************************************************************************************/
void ISOUDS_SAReset (void)
{
    /* Stop all Timers */
    ISOUDS_SATimerSessionRunning = ISOUDS_FALSE;
    ISOUDS_SATimerWaitingForKeyRunning = ISOUDS_FALSE;
 
    /* Clear all counters */
    ISOUDS_SATimerSession = 0;
    ISOUDS_SATimerWaitingForKey = 0;

    /* Change state to Default */
    ISOUDS_SAState = ISOUDS_SA_STATE_A;

    /* lock the ECU */
    ISOUDS_StECUUnLock = ISOUDS_FALSE;

    /* Reset the security level */
    ISOUDS_SALevel = 0U;
}

/***************************************************************************************************
** Function                 : ISOUDS_GetSAStLevel

** Description              : Gets ECU Lock Status of particular Level

** Parameter ISOUDSConfPtr  : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : uint8
                                ISOUDS_TRUE = particular level is supported and unlocked.
                                ISOUDS_FALSE = particular level is not unlocked or may be not supported.
***************************************************************************************************/
uint8 ISOUDS_GetSAStLevel (uint8 SALevel)
{
    uint8 iLevelStatus = ISOUDS_FALSE;
    /* Check if particular Security level is current level or not */
    if((SALevel == ISOUDS_SALevel) && (ISOUDS_StECUUnLock == ISOUDS_TRUE))
    {
        iLevelStatus = ISOUDS_TRUE;
    }
    else
    {
        iLevelStatus = ISOUDS_FALSE;
    }
    return (iLevelStatus);
}

/**************************** Internal Function definitions ***************************************/
/***************************************************************************************************
** Function                 : ISOUDS_GetSeed

** Description              : Fills the Seed in provided buffer.

** Parameter 			    : None

** Return value             : None
***************************************************************************************************/
static void ISOUDS_GetSeed (uint8 *datavalue, uint8 SeedSize)
{
    uint8 LoopIndx;
    (void)SeedSize;

    /* Generate Random number and store in "GenratedSeed" */
    GenerateRandomNum(GenratedSeed);
    
    /* Append Master Key Value to "GenratedSeed" */
	for(LoopIndx = 0U; LoopIndx < ISOUDS_MASTER_KEY_SIZE; LoopIndx++)
	{
		GenratedSeed[LoopIndx + ISOUDS_MASTER_KEY_SIZE] = MasterKeyVal[LoopIndx];
	}
    
	/* Copy data from "GenratedSeed" to UDS buffer */
    for (LoopIndx = (uint8)0U; LoopIndx < ISOUDS_TOTAL_SEED_SIZE; LoopIndx++)
    {
        datavalue[LoopIndx] = GenratedSeed[LoopIndx];
    }
}

uint32 Seed_Level1 = 0;
/***************************************************************************************************
** Function                 : ISOUDS_RetriveSeed

** Description              : Retrive seed from provided key.

** Parameter datavalue      : None

** Return value             : None
***************************************************************************************************/
static uint8 ISOUDS_ValidateKey (uint8 *datavalue, uint8 SecurityLevel)
{
	uint8 ret;
	uint8 KeySize = 16U;
	uint8 ByteIdx;
	uint8 CalculatedKey[ISOUDS_MASTER_KEY_SIZE] = {0};

	ret = ISOUDS_FALSE;

	if(SecurityLevel == 2U)
	{
		KeySize = ISOUDS_MASTER_KEY_SIZE;

		Generatecipherkey(GenratedSeed,CalculatedKey);
	}
	else
	{
		/* Do nothing */
	}

    for(ByteIdx = 0U; ByteIdx < KeySize; ByteIdx++)
    {
		if(CalculatedKey[ByteIdx] ==  datavalue [ByteIdx] )
		{
			/* Set the return value as ISOUDS_TRUE and keep comparing */
			ret = ISOUDS_TRUE;
		}
		else
		{
			/* Set the return value as ISOUDS_FALSE and stop comparing */
			ret = ISOUDS_FALSE;
			break;
		}
    }

    /* Return the value */
    return(ret);
}
