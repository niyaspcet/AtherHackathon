/*******************************************************************************
** Copyright (c) 2018 Embitel
**
** This software is the property of Embitel .
** It can not be used or duplicated without Embitel authorization .
**
** -----------------------------------------------------------------------------
** File Name   : ISOUDS_ClearDiagInfo.c
** Module Name : UDS
** -----------------------------------------------------------------------------
**
** Description : This service Clears DTCs
**
** -----------------------------------------------------------------------------
**
** Documentation reference :
**
********************************************************************************
** R E V I S I O N H I S T O R Y
********************************************************************************
** V01.00
** - Baseline for UDS module
**
*******************************************************************************/

/**************************************** Inclusion files *********************/
#include "ISOUDS.h"
#include "ISOUDS_ClearDiagInfo.h"
#include "ISOUDS_ClearDiagInfo_Cfg.h"
#include "ISOUDS_SA.h"
/********************** Declaration of local symbol and constants *************/

/********************************* Declaration of local macros ****************/
#define CLRDTCINFSRVLEN (uint16)0x04

/********************************* Declaration of local types *****************/

/******************************* Declaration of local variables ***************/

/******************************* Declaration of local constants ***************/

/****************************** Declaration of exported variables *************/

/****************************** Declaration of exported constants *************/

/*******************************************************************************
**                                      FUNCTIONS                              *
*******************************************************************************/

/**************************** Internal functions declarations *****************/

/******************************** Function definitions ************************/

/*******************************************************************************
** Function                 : ISOUDS_ClearDiagInfo

** Description              : Service to clear stored diagnostic information

** Parameter ISOUDSConfPtr  : Pointer to service configuration structure

** Parameter                : Pointer to service data buffer
*******************************************************************************/
void ISOUDS_ClearDiagInfo (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[])
{
    uint8 RespStat;
    uint8 SecAccss;
	uint32 DTCNumber;


    if (ISOUDSConfPtr->srvSt == (uint8)ISOUDS_RXMSG)
    {
		/* init service state with negative response */
		ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
		
        if (ISOUDSConfPtr->srvLen == CLRDTCINFSRVLEN)
        {
		#if (ISOUDS_CLRDIAG_INFO_SEC_SUPP == ISOUDS_TRUE)
			/* Get the security Status */
			SecAccss = ISOUDS_GetSAStLevel(ISOUDS_CLRDIAG_INFO_SEC_LEVL);
			if (SecAccss == ISOUDS_TRUE)
			{
		#endif			
				DTCNumber = ((uint32)dataBuff[ISOUDS_ZERO] << 16) | ((uint32)dataBuff[ISOUDS_ONE] << 8) | dataBuff[ISOUDS_TWO];
				/* Process the request */
				RespStat = ISOUDS_CLearDTCInfoReq(DTCNumber);

				if (RespStat == ISOUDS_POSRES)
				{
					/* Response length for the current Service - including
					   SID */
					ISOUDSConfPtr->srvLen = (uint8)1;

					/* Send positive response */
					ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
				}
				else
				{
					/* NRC - conditions not correct */
					ISOUDSConfPtr->srvNegResp = (uint8)RespStat;
				}
		#if (ISOUDS_CLRDIAG_INFO_SEC_SUPP == ISOUDS_TRUE)
			}
			else
			{
				/* NRC - conditions not correct */
				ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SAD;
			}
		#endif
        }
        else
        {
            /* Negative response */
            ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

            /* Invalid Message Length Or Invalid Format */
            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
        }
    }
    else
    {
        /* service invoked due to response pending from service */
		
		/* init service state with negative response */
		ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;
		
    	RespStat = ISOUDS_CLearDTCInfoReqStat();

		if (RespStat == ISOUDS_POSRES)
		{
			/* Response length for the current Service - including SID */
			ISOUDSConfPtr->srvLen = (uint16)1;

			/* Send positive response */
			ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
		}
#if 0
		else
		{
			/* Response pending */
			ISOUDSConfPtr->srvNegResp = (uint8)RespStat;
		}
#endif
    }
}

/**************************** Internal Function definitions *******************/
