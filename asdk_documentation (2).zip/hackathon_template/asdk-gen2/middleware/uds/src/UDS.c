/***************************************************************************************************
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOUDS.c
**
** Description  : Unified Diagnostic Services Stack
**
** -------------------------------------------------------------------------------------------------
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "CanTp.h"
#include "ISOUDS.h"
#include "ISOUDS_StrtDiagSess.h"
#include "ISOUDS_RtnCntrl.h"
#include "ISOUDS_ReqDwnld.h"
#include "ISOUDS_TrnsfrDa.h"
#include "ISOUDS_TrnsfrExit.h"
#include "ISOUDS_ECUReset.h"
#include "ISOUDS_TstrPrsnt.h"
#include "ISOUDS_SA.h"
#include "ISOUDS_CommCntrl.h"
#include "ISOUDS_CntrlDTCSetting.h"
#include "ISOUDS_RdDaByID.h"
#include "ISOUDS_WrDaByID.h"
#include "ISOUDS_RdDTCInf.h"
#include "FLSHM.h"
#include "ISOUDS_ClearDiagInfo.h"

/********************** Declaration of local symbol and constants *************/

/* Negative response length */
#define     ISOUDS_NEGRESPLEN          (3U)
/* invalid Service ID */
#define     ISOUDS_IDNONE              (0)
/* Single Frame */
#define     ISOUDS_SINGLEFRAME         (0)
/* Multiple Frame */
#define     ISOUDS_MULTIPLEFRAME       (1)
#define     ERR_MSG_BUF_LEN            (8)
/* Session Selection(SS) Configuration */

/*
ISOUDS_SS_T_T_T_F implies that service is supported in Extended Diagnostic, 
Programming and Default session
ISOUDS_SS_T_F_T_F implies that service is supported in Extended and default 
session only
ISOUDS_SS_T_F_F_F implies that service is supported in Extended Diagnostic 
session only
*/

/********************************* Declaration of local macros ****************/
#define M_ISOUDS_NUMSRV    (sizeof(ISOUDS_iTab)/sizeof(ISOUDS_iTabType))

/********************************* Declaration of local types *****************/
typedef struct
{
	/* Service id */
    uint8 SID;
	/* Hold address of the UDS service funtion */
    void (*ISOUDS_FunPtr)(ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[]);
	/* Diagnostic session in which the service is supported */
    uint8 srvSess;
	uint8 ReqType;
}ISOUDS_iTabType;

/******************************* Declaration of local variables ***************/

static ISO_wdt_reset_cbk_t wdt_immidiate_reset_fun = 0;
/* index */
static uint8 ISOUDS_iTabIdx;

/* Response pending state */
static uint8 ISOUDS_iStRespPendSnt;

/* P2 Timer */
static uint32 ISOUDS_iTmrP2;

/* S3 Timer */
static uint32 ISOUDS_iTmrS3;

/* P2 timer Limit */
static uint32 ISOUDS_iTmrP2Lim;

static uint32 ISOUDS_iTmrNRC78P2Min;

/* Positive response supression bit */
static boolean suppressPosRspMsgIndicationBit;

/* Status to indicate whether ECU is unlocked or not */
uint8 ISOUDS_StECUUnLock;

/******************************* Declaration of local constants ***************/
/* UDS table with service ids and related functions. */
static const ISOUDS_iTabType ISOUDS_iTab[ISOUDS_TABSIZE] =
{
    {
        (uint8)ISOUDS_SIDSTRTDIAGSESS,
        &ISOUDS_StrtDiagSess,
        (uint8)ISOUDS_SS_T_T_T_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
    {
        (uint8)ISOUDS_SIDECURST,
        &ISOUDS_ECUReset,
        (uint8)ISOUDS_SS_T_T_T_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
	{
        (uint8)ISOUDS_SIDTSTRPRSNT,
        &ISOUDS_TstrPrsnt,
        (uint8)ISOUDS_SS_T_T_T_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
    {
        (uint8)ISOUDS_SIDSA ,
        &ISOUDS_SA,
        (uint8)ISOUDS_SS_T_T_F_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
        {
        (uint8)ISOUDS_SIDRTNCNTRLID,
        &ISOUDS_RtnCntrl,
        (uint8)ISOUDS_SS_T_T_F_F,  // Changed by ather
		/*(uint8)ISOUDS_SS_T_T_T_F, */
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
   {
        (uint8)ISOUDS_SIDREQDWNLD,
        &ISOUDS_ReqDwnld,
        (uint8)ISOUDS_SS_F_T_F_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
    {
        (uint8)ISOUDS_SIDTRNSFRDTID,
        &ISOUDS_TrnsfrDa,
        (uint8)ISOUDS_SS_F_T_F_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
    {
        (uint8)ISOUDS_SIDTRNSFREXITDID,
        &ISOUDS_TrnsfrExit,
        (uint8)ISOUDS_SS_F_T_F_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
    {
        (uint8)ISOUDS_SIDRDDABYID,
        &ISOUDS_RdDaByID,
        (uint8)ISOUDS_SS_T_T_T_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    }, 
    {
        (uint8)CANSRV_SIDWRDABYID,
        &CanSrv_WrDaByID,
        (uint8)ISOUDS_SS_T_T_F_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
	{
        (uint8)ISOUDS_SIDCOMMCNTRL,
        &ISOUDS_CommCntrl,
        (uint8)ISOUDS_SS_T_T_T_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    }, 
    {
        (uint8)ISOUDS_SIDCNTRLDTCSET,
        &ISOUDS_CntrlDTCSetting,
        (uint8)ISOUDS_SS_T_T_T_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
    {
        (uint8)ISOUDS_SIDRDDTCINF,
        &ISOUDS_RdDTCInf,
        (uint8)ISOUDS_SS_T_T_T_F,
		(uint8)ISOUDS_RQ_TYPE_T_T_F
    },
    {
        (uint8)ISOUDS_SIDCLEARDIAGINFO,
        &ISOUDS_ClearDiagInfo,
        (uint8)ISOUDS_SS_T_F_T_F,
        (uint8)ISOUDS_RQ_TYPE_T_T_F
    },
};


/****************************** Declaration of exported variables *************/
/* ECU Reset Request */
boolean ISOUDS_EcuRstReq;

/* UDS Buffer for data */
uint8 ISOUDS_Buff[ISOUDS_BUFFSIZE];

/* UDS current session */
uint8 ISOUDS_Sess;

/* Timer for Ecu Reset */
uint32 ISOUDS_TmrECURst;

/* UDS configuration */
ISOUDS_ConfType ISOUDS_Conf;

/* ISOTP UDS configuration */
ISOTP_App_CfgType ISOTP_UDS_Cfg;

/* Timer Limits */
uint32 ISOUDS_iTmrP2Min;
uint32 ISOUDS_iTmrP2Max;
uint32 ISOUDS_iTmrSTmin;

/****************************** Declaration of exported constants *************/

/*******************************************************************************
**                                      FUNCTIONS                             **
*******************************************************************************/

/**************************** Internal functions declarations *****************/
static void ISOUDS_iTxNegResp (void);
static void ISOUDS_iTxRespPend (void);

/******************************** Function definitions ************************/

/*******************************************************************************
** Function                 : ISOUDS_Init

** Description              : Initialization of UDS parameters and set wdt reset callback

** Parameter                : None

** Return value             : None
*******************************************************************************/
void ISOUDS_Init (ISO_wdt_reset_cbk_t wdt_immidiate_reset)
{
    /* Initialize to Default session */
    ISOUDS_Sess = (uint8)ISOUDS_DS;

    /* Initialize the state to IDLE */
    ISOUDS_Conf.srvSt = (uint8)ISOUDS_IDLE;

    /* Initialize Frame */
    ISOUDS_Conf.srvFrame = (uint8)ISOUDS_SINGLEFRAME;

    /* Initialize the Timer P2 to OFF state */
    ISOUDS_iTmrP2 = (uint32)0;

    /* Initialize the Timer S3 to 0FF state */
    ISOUDS_iTmrS3 = (uint32)0;

    /* Ecu Reset Request */
    ISOUDS_EcuRstReq = ISOUDS_FALSE;

    /* Initialize the status of response pending sent to FALSE */
    ISOUDS_iStRespPendSnt = ISOUDS_FALSE;

    /* Timer for Ecu Reset */
    ISOUDS_TmrECURst = (uint32)0;
	
	/* positive response supress bit */
	suppressPosRspMsgIndicationBit = ISOUDS_FALSE;

    /* store wdt reset callback fuction */
    wdt_immidiate_reset_fun = wdt_immidiate_reset;
	
	ISOUDS_SAInit(0U);
}

/***************************************************************************************************
** Function                 : ISOUDS_MsgIndiIm

** Description              : Indicates that a new request has been received

** Parameter isoTpConfPtr   : Pointer to TP configuration structure

** Return value             : None
***************************************************************************************************/
FUNC(void, CAN_CODE) ISOUDS_MsgIndiIm (const ISOTP_CfgType *isoTpConfPtr)
{
    /* Service ID. */
	uint16 id = 0;
	uint8 idx = 0;
	uint8 len = 0;
	uint8 Buff[ERR_MSG_BUF_LEN] = {0,};
	
    /* UDS configuration */
    ISOUDS_ConfType L_ISOUDS_Conf;
	
	/* Store the length of data bytes received */
    len = (uint8)isoTpConfPtr->nBytes;
	
	/* Copy data from TP buffer to SrvD buffer */
    for (idx = (uint8)0; idx < len; idx++)
    {
        if (idx > ERR_MSG_BUF_LEN)
            break;
        Buff[idx] = isoTpConfPtr->tpBuff[idx];
    }
	
	/* Get the Service ID */
    id = Buff[0];

    L_ISOUDS_Conf.srvId = Buff[0];
    L_ISOUDS_Conf.srvLen = (uint8)isoTpConfPtr->nBytes;
    L_ISOUDS_Conf.ReqType = (ISOUDS_ReqType)isoTpConfPtr->ReqType;

	switch(id)
	{
		case ISOUDS_SIDTSTRPRSNT:
		ISOUDS_TstrPrsnt(&L_ISOUDS_Conf, &Buff[1]);
        break;
		
		case ISOUDS_SIDSTRTDIAGSESS:
		ISOUDS_StrtDiagSess(&L_ISOUDS_Conf, &Buff[1]);
        break;
		
		case ISOUDS_SIDSA:
		ISOUDS_SA(&L_ISOUDS_Conf, &Buff[1]);
        break;
		
		case ISOUDS_SIDTRNSFREXITDID:
		ISOUDS_TrnsfrExit(&L_ISOUDS_Conf, &Buff[1]);
        break;
		
		case ISOUDS_SIDECURST:
		ISOUDS_ECUReset(&L_ISOUDS_Conf, &Buff[1]);
        break;

        default:break;			
	}
}

/*******************************************************************************
** Function                 : ISOUDS_MsgIndi

** Description              : Indicates that a new request has been received

** Parameter isoTpConfPtr   : Pointer to TP configuration structure

** Return value             : None
*******************************************************************************/
void ISOUDS_MsgIndi (const ISOTP_CfgType *isoTpConfPtr)
{
    uint16 idx;

    /* if the present state is IDLE or RXPEND */
    if ((ISOUDS_Conf.srvSt == (uint8)ISOUDS_IDLE) ||
                    (ISOUDS_Conf.srvSt == (uint8)ISOUDS_RXPEND))
    {
        if ((ISOUDS_SIDTSTRPRSNT != isoTpConfPtr->tpBuff[0]) || (ISOUDS_TRUE != (isoTpConfPtr->tpBuff[1] >> 7)) || (ISOUDS_TSTRPRSNTSERLEN != isoTpConfPtr->nBytes))
    	{
            /* Store the length of data bytes received */
            ISOUDS_Conf.srvLen = (uint16)isoTpConfPtr->nBytes;

            /* Stop Timer S3 */
            ISOUDS_iTmrS3 = (uint32)0;

			/* Copy data from TP buffer to SrvD buffer */
			for (idx = (uint16)0; idx < ISOUDS_Conf.srvLen; idx++)
			{
				ISOUDS_Buff[idx] = isoTpConfPtr->tpBuff[idx];
			}

			/* Assign standard P2 timer limit */
			ISOUDS_iTmrP2Lim = (uint32)ISOUDS_STDP2LIM;

			/* Start timer P2 */
			ISOUDS_iTmrP2 = (uint32)0x01;

			/* Change state to RXMSG */
			ISOUDS_Conf.srvSt = (uint8)ISOUDS_RXMSG;

			ISOUDS_Conf.ReqType = (ISOUDS_ReqType)isoTpConfPtr->ReqType;
		}
		else
		{
			ISOUDS_MsgIndiIm(isoTpConfPtr);
		}
    }
}

/*******************************************************************************
** Function                 : ISOUDS_FFIndi

** Description              : Indicates that the first frame of new request has 
							  been received

** Parameter isoTpConfPtr   : Pointer to TP configuration structure

** Return value             : None
*******************************************************************************/
void ISOUDS_FFIndi (const ISOTP_CfgType *isoTpConfPtr)
{
    /* if the present state is IDLE or RXPEND */
    if ((ISOUDS_Conf.srvSt == (uint8)ISOUDS_IDLE) ||
		(ISOUDS_Conf.srvSt == (uint8)ISOUDS_RXPEND))
    {
        /* Store the length of data bytes */
        ISOUDS_Conf.srvLen = (uint16)isoTpConfPtr->nBytes;

        /* Change state to Reception Pending */
        ISOUDS_Conf.srvSt = (uint8)ISOUDS_RXPEND;

        /* request received in Multiple Frame */
        ISOUDS_Conf.srvFrame = (uint8)ISOUDS_MULTIPLEFRAME;

        ISOUDS_Conf.ReqType = (ISOUDS_ReqType)isoTpConfPtr->ReqType;

        /* Stop Timer S3 */
        ISOUDS_iTmrS3 = (uint32)0;
    }
}

/*******************************************************************************
** Function                 : ISOUDS_Main

** Description              : UDS Main Function

** Parameter                : None

** Return value             : None
*******************************************************************************/
void ISOUDS_Main (void)
{
    uint8   idx;
    uint8 srvFound;

    /* Initialization */
    srvFound = ISOUDS_FALSE;

    /* check the current state */
    if (ISOUDS_Conf.srvSt == (uint8)ISOUDS_RXMSG)
    {
        /* Store the service ID information */
        ISOUDS_Conf.srvId = ISOUDS_Buff[0];
		
		/* Only certain services support suppressPosRspMsgIndicationBit so if 
		   the service is supporting suppressPosRspMsgIndicationBit bit then we 
		   extract it else we set it to FALSE and neglect*/
		if( (ISOUDS_Conf.srvId == ISOUDS_SIDSTRTDIAGSESS) ||
		    (ISOUDS_Conf.srvId == ISOUDS_SIDECURST) ||
		    (ISOUDS_Conf.srvId == ISOUDS_SIDSA) ||
		    (ISOUDS_Conf.srvId == ISOUDS_SIDTSTRPRSNT) ||
		    (ISOUDS_Conf.srvId == ISOUDS_SIDRTNCNTRLID) ||
		    (ISOUDS_Conf.srvId == ISOUDS_SIDCOMMCNTRL) ||
		    (ISOUDS_Conf.srvId == ISOUDS_SIDCNTRLDTCSET) )
		{
			/* suppressPosRspMsgIndicationBit is suppoted */
			/* Check for positive response supress bit and change subfunction
			do that it does not effect other services i.e remove 7th bit*/
			suppressPosRspMsgIndicationBit = (boolean)(ISOUDS_Buff[1] >> 7);
			ISOUDS_Buff[1] = (ISOUDS_Buff[1] & 0x7fU);
		}
		else
		{
			/* suppressPosRspMsgIndicationBit is not supported,
			dont change anything and set it to zero */
			suppressPosRspMsgIndicationBit = ISOUDS_FALSE;
		}
		
        /* Depending on received SID, select the appropriate service */
        for (idx = (uint8)0; ((idx < ((uint8)M_ISOUDS_NUMSRV)) &&
		    (srvFound != ISOUDS_TRUE)); idx++)
        {
            if (ISOUDS_iTab[idx].SID == ISOUDS_Conf.srvId)
            {
				if (0 != (ISOUDS_iTab[idx].ReqType & ISOUDS_Conf.ReqType))
				{
                	srvFound = ISOUDS_TRUE;


					/* Check if the service is allowed in the current session */
					if (((ISOUDS_iTab[idx].srvSess) & ((uint8)((uint8)ISOUDS_ONE
						 << ISOUDS_Sess)))!= (uint8)0U)
					{
						/* Store the table index */
						ISOUDS_iTabIdx = idx;

						/* Call the service function */
						(ISOUDS_iTab[idx].ISOUDS_FunPtr)(&ISOUDS_Conf,
																   &ISOUDS_Buff[1]);
					}
					else
					{
						/* Negetive response: Service Not Supported In 
						Active Session */
						ISOUDS_Conf.srvNegResp = (uint8)ISOUDS_SNSIAS;

						/* Update the status to Negative Response state */
						ISOUDS_Conf.srvSt = (uint8)ISOUDS_RESPNEG;
					}
				}
            }
        }
        /* Unknown or Unsupported service */
        if (srvFound == ISOUDS_FALSE)
        {
        	if (ISOUDS_PHYSICAL_REQ == ISOUDS_Conf.ReqType)
        	{
	            /* Negetive response: Service Not Supported */
	            ISOUDS_Conf.srvNegResp = (uint8)ISOUDS_SNS;

	            /* Update the status to Negative Response state */
	            ISOUDS_Conf.srvSt = (uint8)ISOUDS_RESPNEG;
			}
        	else
        	{
        		/* Reset the required parameters and go to IDLE state */
        		ISOUDS_Rst ();
        	}
        }
    }
    else if (ISOUDS_Conf.srvSt == (uint8)ISOUDS_RESPPEND)
    {
        /* Call the service function */
        (ISOUDS_iTab[ISOUDS_iTabIdx].ISOUDS_FunPtr)(&ISOUDS_Conf,
															   &ISOUDS_Buff[1]);
    }
    else
    {
        /* Do Nothing */
    }

    if (ISOUDS_Conf.srvSt == (uint8)ISOUDS_RESP)
    {
		if(suppressPosRspMsgIndicationBit == ISOUDS_FALSE)
		{
			/* Update the Service ID for Positive response */
			ISOUDS_Buff[0] = ISOUDS_Conf.srvId + (uint8)0x40;
			
			/* Change state to Tx confirmation pending */
			ISOUDS_Conf.srvSt = (uint8)ISOUDS_TXPEND;
			
			/* Assign standard P2 timer limit */
			ISOUDS_iTmrP2Lim = (uint32)ISOUDS_STDP2LIM;

			/* Start timer P2 */
			ISOUDS_iTmrP2 = 1U;
			/* get data pointer */
			ISOTP_UDS_Cfg.dataPtr = &ISOUDS_Buff[0];
			
			/* get the length */
			ISOTP_UDS_Cfg.dataLen = ISOUDS_Conf.srvLen;
			
			/* Request for transmission of positive response */
			ISOTP_TxRequest (&ISOTP_UDS_Cfg);
		}
		else
		{
			/* No need to send any positive response */
			/* Change state to Ideal */
			ISOUDS_Conf.srvSt = (uint8)ISOUDS_IDLE;
			
			/* positive response supress bit */
			suppressPosRspMsgIndicationBit = ISOUDS_FALSE;
		}
		
		ISOUDS_SessionTimeoutCntr = 0U;
	}
    else if (ISOUDS_Conf.srvSt == (uint8)ISOUDS_RESPNEG)
    {
        /* If the service negative response code is ISOUDS_RCRRP */
        if (ISOUDS_Conf.srvNegResp == (uint8)ISOUDS_RCRRP)
        {
            /* change state to Response pending */
            ISOUDS_Conf.srvSt = (uint8)ISOUDS_RESPPEND;

            /* Service has a response pending, transmit negative response */
            /* and switch to ISOUDS_RESPPEND state */
            ISOUDS_iTxRespPend();
        }
		else if ((ISOUDS_PHYSICAL_REQ == ISOUDS_Conf.ReqType) ||
    			((ISOUDS_FUCTIONAL_REQ == ISOUDS_Conf.ReqType) /* && (ISOUDS_SFNS != ISOUDS_Conf.srvNegResp)*/))
        {
            /* Change state to Tx confirmation pending */
            ISOUDS_Conf.srvSt = (uint8)ISOUDS_TXPEND;

			/* Assign standard P2 timer limit */
			ISOUDS_iTmrP2Lim = (uint32)ISOUDS_STDP2LIM;

			/* Start timer P2 */
			ISOUDS_iTmrP2 = 1U;
            /* Request Transmission of negative response */
            ISOUDS_iTxNegResp ();
        }
		else
		{
			/* Reset the required parameters and go to IDLE state */
			ISOUDS_Rst ();
		}	
    }
    else
    {
        /* Do Nothing */
    }

    /* check if state is in Tx response pending */
    if (ISOUDS_Conf.srvSt == (uint8)ISOUDS_TXRESPPEND)
    {
        /* Go back to Response pending - Dont wait for Tx confirmation */
        ISOUDS_Conf.srvSt = (uint8)ISOUDS_RESPPEND;
    }
	else
	{
		/* Do nothing */
	}
	
	/* Check for security access Timers */
	ISOUDS_SAChkTimer();
	
	/* Check for Tester Present Timer */
	ISOUDS_MonitorTstrPrsnt();

	//ISOUDS_Mon();
}

/*******************************************************************************
** Function                 : ISOUDS_TxCnfCbk

** Description              : Confirmation of response sent

** Parameter                : None

** Return value             : None
*******************************************************************************/
void ISOUDS_TxCnfCbk (const ISOTP_CfgType *isoTpConfPtr)
{
    /* for future use */
    (void)isoTpConfPtr;

    /* Check if the current state is Tx confiramtion Pending */
    if (ISOUDS_Conf.srvSt == (uint8)ISOUDS_TXPEND)
    {
		ISOUDS_iTmrP2 = (uint32)0U;
        /* Reset the required parameters and go to IDLE state */
        ISOUDS_Rst ();
	
		if (ISOUDS_EcuRstReq == ISOUDS_TRUE)
		{
			ISOUDS_EcuRstReq = 0U;
            (*wdt_immidiate_reset_fun)();
			//WDT_ResetImmediate();
		}
		else
		{
			/* Do nothing */
		}
    }
	else
	{
		/* Do nothing */
	}
}

/*******************************************************************************
** Function                 : ISOUDS_Rst

** Description              : Resets the ISOUDS parameters

** Parameter                : None

** Return value             : None
*******************************************************************************/
void ISOUDS_Rst (void)
{
    /* Reset the state to IDLE */
    ISOUDS_Conf.srvSt = (uint8)ISOUDS_IDLE;

    /* Reset the service ID to invalid */
    ISOUDS_Conf.srvId = (uint8)ISOUDS_IDNONE;

    /* Initialize Frame */
    ISOUDS_Conf.srvFrame = (uint8)ISOUDS_SINGLEFRAME;

    /* Reset the service index value to Invalid */
    ISOUDS_iTabIdx = (uint8)0xFF;

    /* Reset the response pending sent to False */
    ISOUDS_iStRespPendSnt = (uint8)ISOUDS_FALSE;

    /* Check if active session is not default session */
    if (ISOUDS_Sess != (uint8)ISOUDS_DS)
    {
        /* Start the S3 timer */
        ISOUDS_SessionTimeoutCntr = (uint32)0x01;
    }

    /* check if the baud rate needs to be changed */
    //ISOUDS_ChangeBaudrate();
	
	/* Positive response supression bit */
	suppressPosRspMsgIndicationBit = ISOUDS_FALSE;
	
}

/*******************************************************************************
** Function                 : ISOUDS_Mon

** Description              : Monitors the service distributor timers

** Parameter                : None

** Return value             : None
*******************************************************************************/
void ISOUDS_Mon (void)
{
    /* Check if active session is not default session - timer will not run in 
	   Default session */
    if (ISOUDS_Sess != (uint8)ISOUDS_DS)
    {
        /* Check if timer S3 is running */
        if (ISOUDS_iTmrS3 > (uint32)0)
        {
            /* If Timer limit is reached */
            if (ISOUDS_iTmrS3 >= (uint32)ISOUDS_S3TMRLIM)
            {
            	/* Enable Communication */
        		//CANIL_RxTxCtrl(CANIL_RX, CANIL_ENABLE);
        		//CANIL_RxTxCtrl(CANIL_TX, CANIL_ENABLE);

                /* Switch to default session  */
                ISOUDS_Sess = (uint8)ISOUDS_DS;

                /* Stop timer S3 */
                ISOUDS_iTmrS3 = (uint32)0;

                /* Reset ISOUDS parameters */
                ISOUDS_Rst ();

                /* Initialize Flash Manager */
                //FLSHM_Init(); #TODO AFR Need flash Init

                /* Request Transfer Data Exit */
                ISOUDS_TrnsfrDaExit();
            }
            else
            {
                /* increment timer */
                ISOUDS_iTmrS3 += (uint32)ISOUDS_PERIOD_SCHED;
            }
        }
    }
    /* Check if timer P2 is running */
    if (ISOUDS_iTmrP2 > (uint32)0)
    {
        /* If Timer limit is reached */
        if (ISOUDS_iTmrP2 >= ISOUDS_iTmrP2Lim)
        {
            /* Reset ISOUDS parameters */
            ISOUDS_Rst ();

            /* Stop timer P2 */
            ISOUDS_iTmrP2 = (uint32)0;
        }
        else
        {
            /* increment timer */
            ISOUDS_iTmrP2 += (uint32)ISOUDS_PERIOD_SCHED;
        }
    }

    /* check if Ecu reset is requested */
    if (ISOUDS_EcuRstReq == ISOUDS_TRUE)
    {
        /* Check whether Time has elapsed. This is checked
        to make sure that CAN response is transmitted before ECU reset */
        if (ISOUDS_TmrECURst >= (uint32)ISOUDS_TMRTHRES)
        {
            /* reset the flag */
            ISOUDS_EcuRstReq = ISOUDS_FALSE;

            /* reset timer */
            ISOUDS_TmrECURst = (uint32)0;

            /* invoke the function to Reset ECU */
            /****************************************************************

            INSERT CODE TO INVOKE A FUNCTION WHICH WILL RESET THE ECU

            *****************************************************************/
			
			
        }
        else
        {
            ISOUDS_TmrECURst += (uint32)ISOUDS_PERIOD_SCHED;
        }
    }
}

/*******************************************************************************
** Function                 : ISOUDS_ReqECUReset

** Description              : Request ECU Reset

** Parameter                : None

** Return value             : None
*******************************************************************************/
void ISOUDS_ReqECUReset (void)
{
    /* Request ECU reset */
    ISOUDS_EcuRstReq = ISOUDS_TRUE;
    
    ISOUDS_TmrECURst = (uint32)1;
}


/**************************** Internal Function definitions *******************/

/*******************************************************************************
** Function                 : ISOUDS_iTxNegResp

** Description              : Transmits the negative response

** Parameter                : None

** Return value             : None
*******************************************************************************/
static void ISOUDS_iTxNegResp (void)
{
    /* SID for negative response */
    ISOUDS_Buff[0] = (uint8)ISOUDS_NEGRESPSID;

    /* Updates the buffer with the SID of received frame */
    ISOUDS_Buff[1] = ISOUDS_Conf.srvId;

    /* Updates the Negative response code */
    ISOUDS_Buff[2] = ISOUDS_Conf.srvNegResp;

    /* Stop timer P2 */
    ISOUDS_iTmrP2 = (uint32)0;

    /* get data pointer */
    ISOTP_UDS_Cfg.dataPtr = &ISOUDS_Buff[0];

    /* get the length */
    ISOTP_UDS_Cfg.dataLen = ISOUDS_NEGRESPLEN;

    /* Request for transmission of negative response */
    ISOTP_TxRequest (&ISOTP_UDS_Cfg);
}

/*******************************************************************************
** Function                 : ISOUDS_iTxRespPend

** Description              : Transmits the response pending message

** Parameter                : None

** Return value             : None
*******************************************************************************/
static void ISOUDS_iTxRespPend (void)
{
    static uint8 dataBuff_s[3];

    if ((ISOUDS_iTmrNRC78P2Min > (uint32)ISOUDS_NRC78P2MINLIM) ||
        (ISOUDS_iStRespPendSnt == (uint8)ISOUDS_FALSE))
    {
        /* SID for Negative Response */
        dataBuff_s[0] = (uint8)ISOUDS_NEGRESPSID;

        /*  SID of received frame */
        dataBuff_s[1] = ISOUDS_Conf.srvId;

        /*  Negative response code */
        dataBuff_s[2] = ISOUDS_Conf.srvNegResp;

        /* get data pointer */
		/*  MISRA: Assigning address of auto variable 'RespBuf' to static [MISRA 2004 Rule 17.6, required]
			Exception: &dataBuff_s[0] is used immediately in ISOTP_TxRequest() */
        ISOTP_UDS_Cfg.dataPtr = &dataBuff_s[0];

        /* get the length */
        ISOTP_UDS_Cfg.dataLen = ISOUDS_NEGRESPLEN;

        /* Request for transmission of negative response */
        ISOTP_TxRequest (&ISOTP_UDS_Cfg);

        /* Assign P2* timer limit */
        ISOUDS_iTmrP2Lim = (uint32)ISOUDS_NRC78P2MAXLIM;

        /* Re-start timer P2 */
        ISOUDS_iTmrNRC78P2Min = (uint32)0x01;

        /* change state to Transmit response pending */
        ISOUDS_Conf.srvSt = (uint8)ISOUDS_TXRESPPEND;

        /* Response pending Transmitted */
        ISOUDS_iStRespPendSnt = (uint8)ISOUDS_TRUE;
    }
    else
    {
        /* stay in Response pending state - Response pending already 
		Transmitted */
        ISOUDS_Conf.srvSt = (uint8)ISOUDS_RESPPEND;
		
		ISOUDS_iTmrNRC78P2Min += ISOUDS_PERIOD_SCHED;

        /* clear to buffer */
        dataBuff_s[0] = (uint8)0;
        dataBuff_s[1] = (uint8)0;
        dataBuff_s[2] = (uint8)0;
    }
}


