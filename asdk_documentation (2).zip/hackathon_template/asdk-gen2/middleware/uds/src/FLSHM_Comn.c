
/***************************************************************************************************
** Copyright (c) 2019 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : FLSHM_Comn.c
** Module name  : FLSH Manager common source
** -------------------------------------------------------------------------------------------------
**
** Description : FLASHM_Comn.c  file should be common between application and bootloader
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference :
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 05/10/2018
** - Baseline Created
***************************************************************************************************/

/************************************** Inclusion files *******************************************/
//#include "dal/dal_flash/dal_flash.h"
#include "FLSHM_Cfg.h"
#include "FLSHM_Comn.h"
#include "FLSHM.h"
#define FEATURE_FLS_DF_BLOCK_SECTOR_SIZE (2048u)
// #define DFLASH_SECTOR_SIZE				FEATURE_FLS_DF_BLOCK_SECTOR_SIZE
/********************************** Component configuration ***************************************/

/********************************* Declaration of local functions *********************************/

/************************** Declaration of local symbol and constants *****************************/

/********************************* Declaration of local macros ************************************/

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/

/*********************************** Start of Common Data *****************************************/

/*********************************** End of Common data   *****************************************/
/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/
static uint64 ReprogReqBuff;
extern  asdk_flashm_cbk_t asdk_flashm_cbk;

/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/***************************************************************************************************
** Function         : FLSHM_GetReprogStat

** Description      : returns the Flash reprog status

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(uint8, FLSHM_CODE) FLSHM_GetReprogStat(void)
{
	uint8 	ReprogFlag 		= 0U;
	uint8* 	ReprogFlagAddr 	= (uint8*)FLSHM_APP_UPDATE_REQ_ADDR;

	ReprogFlag = *ReprogFlagAddr;

	return ReprogFlag;
}

/***************************************************************************************************
** Function         : FLSHM_SetReprogStat

** Description      : Sets the Reprog Request status

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_ClrReprogReq(void)
{
	if(asdk_flashm_cbk.asdk_flashm_erase_cbk_fun != NULL)
	{
		(void)asdk_flashm_cbk.asdk_flashm_erase_cbk_fun (FLSHM_APP_UPDATE_REQ_ADDR, DFLASH_SECTOR_SIZE);
	}
}

/***************************************************************************************************
** Function         : FLSHM_SetReprogStat

** Description      : Sets the Reprog Request status

** Parameter        : None

** Return value     : None

** Remarks          : None
***************************************************************************************************/
FUNC(void, FLSHM_CODE) FLSHM_ReqReprog(void)
{
	ReprogReqBuff = FLSHM_REPROG_REQ;
	if(asdk_flashm_cbk.asdk_flashm_write_cbk_fun != NULL)
	{
		(void)asdk_flashm_cbk.asdk_flashm_write_cbk_fun (FLSHM_APP_UPDATE_REQ_ADDR, FLSHM_APP_UPDATE_REQ_BUFF_SIZE, (uint8*)&ReprogReqBuff);
	}
}



