/*******************************************************************************
**
** -----------------------------------------------------------------------------
** File Name    : ISOUDS_CommCntrl.c
**
** Description  : Communication Control Service
**
** -----------------------------------------------------------------------------
**
*******************************************************************************/

/**************************************** Inclusion files *********************/
#include "ISOUDS_CommCntrl.h"
#include "CANIL.h"

/********************** Declaration of local symbol and constants *************/
#define    ISOUDS_ERXTX         (uint8)0  /* Enable Rx and Tx */
#define    ISOUDS_ERXDTX        (uint8)1  /* Enable Rx and Disable Tx */
#define    ISOUDS_DRXETX        (uint8)2  /* Disable RX and Enable Tx */
#define    ISOUDS_DRXTX         (uint8)3  /* Disable Rx and Tx */

#define    ISOUDS_NCM           (uint8)1  /* Network Comm Messages */
#define    ISOUDS_NWMCM         (uint8)2  /* Netwrok Mgmt Comm Messages */
#define    ISOUDS_NWMCMANCM     (uint8)3  /* Network comm and Mgmt Comm 
										     messages */

#define    ISOUDS_DESCTIRNCN    (uint8)0  /* Dis/Ena specified comm type */
#define    ISOUDS_DESNIBNN01    (uint8)1  /* Dis/Ena Specified Nw id by num1 */
#define    ISOUDS_DESNIBNN02    (uint8)2  /* Dis/Ena Specified Nw id by num2 */
#define    ISOUDS_DESNIBNN03    (uint8)3  /* Dis/Ena Specified Nw id by num3 */
#define    ISOUDS_DESNIBNN04    (uint8)4  /* Dis/Ena Specified Nw id by num4 */
#define    ISOUDS_DESNIBNN05    (uint8)5  /* Dis/Ena Specified Nw id by num5 */
#define    ISOUDS_DESNIBNN06    (uint8)6  /* Dis/Ena Specified Nw id by num6 */
#define    ISOUDS_DESNIBNN07    (uint8)7  /* Dis/Ena Specified Nw id by num7 */
#define    ISOUDS_DESNIBNN08    (uint8)8  /* Dis/Ena Specified Nw id by num8 */
#define    ISOUDS_DESNIBNN09    (uint8)9  /* Dis/Ena Specified Nw id by num9 */
#define    ISOUDS_DESNIBNN10    (uint8)10 /* Dis/Ena Specified Nw id by num10 */
#define    ISOUDS_DESNIBNN11    (uint8)11 /* Dis/Ena Specified Nw id by num11 */
#define    ISOUDS_DESNIBNN12    (uint8)12 /* Dis/Ena Specified Nw id by num12 */
#define    ISOUDS_DESNIBNN13    (uint8)13 /* Dis/Ena Specified Nw id by num13 */
#define    ISOUDS_DESNIBNN14    (uint8)14 /* Dis/Ena Specified Nw id by num14 */

#define    ISOUDS_DENWRIRO      (uint8)15 /* Dis/Ena Nw req received on */

#define    ISOUDS_CMMCNTRLSERLEN    (3)   /* Service Length */


/********************************* Declaration of local macros ****************/

/********************************* Declaration of local types *****************/

/******************************* Declaration of local variables ***************/

/******************************* Declaration of local constants ***************/

/****************************** Declaration of exported variables *************/

/****************************** Declaration of exported constants *************/

/*******************************************************************************
**                                      FUNCTIONS                              *
*******************************************************************************/

/**************************** Internal functions declarations *****************/

/******************************** Function definitions ************************/
//#pragma section APPLICATIONMEM
/*******************************************************************************
** Function                 : ISOUDS_CommCntrl

** Description              : Communication Control

** Parameter canSrvDConfPtr : Pointer to service configuration structure

** Parameter dataBuff       : Pointer to service data buffer

** Return value             : None
*******************************************************************************/
void ISOUDS_CommCntrl (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[])
{
    uint8 posResp = (uint8)0U;
    uint8 ctrlType = (uint8)0U;
    uint8 cnc = (uint8)0U;
    uint8 commTypelownib = (uint8)0U;
    uint8 commTypehighnib = (uint8)0U;
	uint8 commType = (uint8)0U;
    uint8 req = (uint8)0U;

    /* init service state with negative response */
    ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

    /* check if we have received correct message request length */
    if (ISOUDSConfPtr->srvLen == (uint16)ISOUDS_CMMCNTRLSERLEN)
    {
        /* get the control type parameter value */
        ctrlType = dataBuff[0] & (uint8)0x7F;

        /* Get only the suppressPosRspMsgIndicationBit value */
        /* 1-> implies Do not send positive response */
        posResp = dataBuff[0] & (uint8)0x80;

        /* check if control type is valid */
        if (ctrlType <= ISOUDS_DRXTX)
        {
            /* get the lower nibble value */
            commTypelownib = dataBuff[1] & (uint8)0x03;

            /* get the higher nibble value */
            commTypehighnib = dataBuff[1] & (uint8)0xF0;
			
			commType = commTypelownib + commTypehighnib;
			
			switch(commType)
			{
				case ISOUDS_NCM:			
								req = 0x01;								
								break;
				case ISOUDS_NWMCM:	
								req = 0x01;				
								break;
				
				case ISOUDS_NWMCMANCM:
								req = 0x01;
								break;				
			}
            /****************************************************************
			
            INSERT CODE TO CHECK IF REQUEST IS VALID & UPDATE THE
            VARIABLE req ACCORDINGLY

            *****************************************************************/
			/** Uncomment below code once requirement is integrated i.e. CANIF and CANM.*******/
            /* if valid */
            if (req == (uint8)0x01)
            {
				#if 0
				/* Check if request received for Normal Communication messages */
				if ((commType & ISOUDS_NCM) == ISOUDS_NCM)
				{
					if(ctrlType == ISOUDS_ERXTX)
					{
						//CANIL_RxTxCtrl(CANIL_RX, CANIL_ENABLE);
						//CANIL_RxTxCtrl(CANIL_TX, CANIL_ENABLE);
					}
					else if(ctrlType == ISOUDS_ERXDTX)
					{
						//CANIL_RxTxCtrl(CANIL_RX, CANIL_ENABLE);
						//CANIL_RxTxCtrl(CANIL_TX, CANIL_DISABLE);
					}
					else if(ctrlType == ISOUDS_DRXETX)
					{
						//CANIL_RxTxCtrl(CANIL_RX, CANIL_DISABLE);
						//CANIL_RxTxCtrl(CANIL_TX, CANIL_ENABLE);
					}
					// else if(ctrlType == ISOUDS_DRXTX)
					// {
					// 	//CANIL_RxTxCtrl(CANIL_RX, CANIL_DISABLE);
					// 	//CANIL_RxTxCtrl(CANIL_TX, CANIL_DISABLE);
					// }
					else 
					{
						//CANIL_RxTxCtrl(CANIL_RX, CANIL_DISABLE);
						//CANIL_RxTxCtrl(CANIL_TX, CANIL_DISABLE);
					}
				}
				else
				{
					/* Do nothing */
				}
				#endif
				/* Check if request received for Network Communication 
				messages*/
				// if ((commType & ISOUDS_NWMCM) == ISOUDS_NWMCM)
				// {
					// if(ctrlType == ISOUDS_ERXTX)
					// {
							// /* To be defined */
					// }
					
					// else if(ctrlType == ISOUDS_ERXDTX)
					// {
						// /* To be defined */
					// }
					// else if(ctrlType == ISOUDS_DRXETX)
					// {
						// /* To be defined */					
					// }
					
					// else if(ctrlType == ISOUDS_DRXTX)
					// {
						// /* To be defined */			
					// }
					// else
					// {
						// /* Do nothing*/
					// }
				// }
			// else
			// {
				// /* Do nothing */
			// }
			
				
				/***************************************************************

                INSERT CODE TO CHECK IF ALL CONDITIONS ARE MET & UPDATE THE
                VARIABLE cnc ACCORDINGLY

                ***************************************************************/
                /* if valid */
                if (cnc == (uint8)0)
                {
                    /* check if positive response is to be sent */
                    if (posResp == (uint8)0)
                    {
                        /* Store the reset type in response buffer */
                        dataBuff[0] = ctrlType;

                        /* Response length for the current Service - including 
						SID */
                        ISOUDSConfPtr->srvLen = (uint16)2;

                        /* Send positive response */
                        ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
                    }
                    else
                    {
                        /* Reset the required UDS parameters and Go To IDLE 
						state */
                        ISOUDS_Rst();
                    }
              	}
                else
                {
                    /* Conditions not correct */
                    // ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_CNC;
                }
          	}
            else
            {
                /* Request Out of Range */
                ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_ROOR;
            }
        }
        else
        {
            /* Sub Function Not Supported */
            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
        }
    }
    else
    {
        /* Invalid Message Length Or Invalid Format */
        ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
    }
}
/**************************** Internal Function definitions *******************/
