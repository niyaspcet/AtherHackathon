/*******************************************************************************
**
** -----------------------------------------------------------------------------
** File Name    : ISOUDS_TstrPrsnt.c
**
** Description  : Tester Present Service
**
** -----------------------------------------------------------------------------
**
*******************************************************************************/

/**************************************** Inclusion files *********************/
#include "ISOUDS_TstrPrsnt.h"
#include "ISOUDS_TrnsfrDa.h"
#include "FLSHM.h"
/********************** Declaration of local symbol and constants *************/
// #define NULL   0
/********************************* Declaration of local types *****************/

/******************************* Declaration of local variables ***************/

/* After this time if tester not present it will timeout and switch to default 
   session */
uint32 ISOUDS_SessionTimeoutCntr;

/******************************* Declaration of local constants ***************/

/****************************** Declaration of exported variables *************/

/****************************** Declaration of exported constants *************/

/*******************************************************************************
**                                      FUNCTIONS                              *
*******************************************************************************/

/**************************** Internal functions declarations *****************/

/******************************** Function definitions ************************/

/*******************************************************************************
** Function                 : ISOUDS_TstrPrsnt

** Description              : Sends response to Tester Present(0x3E) service 
							  request

** Parameter canSrvDConfPtr : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : None
*******************************************************************************/
void ISOUDS_TstrPrsnt (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[])
{
    uint8 subFunc;
	
    /* If sufficient bytes are received */
    if (ISOUDSConfPtr->srvLen == (uint16)ISOUDS_TSTRPRSNTSERLEN)
    {
        /* Get the sub-function parameter */
        subFunc = dataBuff[0];

        /* Check for supported Sub-function */
        if( (subFunc == (uint8)0x00) || (subFunc == (uint8)0x80) )
        {			
            /* Store the new session value */
            dataBuff[0] = subFunc;

            /* Response length for the current Service ID */
            ISOUDSConfPtr->srvLen = (uint16)2;

            /* Send positive response */
            ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
			ISOUDS_SessionTimeoutCntr =  0x0000U;
        }
        /* Sub-Function is not supported */
        else
        {
            /* Negative response */
            ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

            /* SubFunction not supported */
            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
        }
    }
    /* Length is less than specified */
    else
    {
	    
        /* Negative response */
        ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESPNEG;

        /* Invalid Message Length Or Invalid Format */
        ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
    }
}


/*******************************************************************************
** Function name    : ISOUDS_MonitorTstrPrsnt
**
** Description      : Monitoring Tester Present
**
** Parameter 		: None
**
** Return value     : None
**
** Remarks          : None
*******************************************************************************/
void ISOUDS_MonitorTstrPrsnt(void)
{
	if (ISOUDS_DS != ISOUDS_Sess)
	{
		/* local to copy running counter value */     
		/* Check for timer overflow */
		if(ISOUDS_SessionTimeoutCntr >= ISOUDS_TSTRPRSNTSESSIONTIMERMAX)		    
		{
			ISOUDS_Sess = ISOUDS_DS;
			/* Clear Timer */
			ISOUDS_SessionTimeoutCntr = 0U;

            /* Initialize Flash Manager */
            FLSHM_Init((asdk_flashm_cbk_t*)0);

            /* Request Transfer Data Exit */
            ISOUDS_TrnsfrDaExit();
		}
		else if (ISOUDS_SessionTimeoutCntr > 0U)
		{
			ISOUDS_SessionTimeoutCntr++;
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}


