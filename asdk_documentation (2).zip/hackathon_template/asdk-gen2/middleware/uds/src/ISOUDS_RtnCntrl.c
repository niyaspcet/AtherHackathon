/***************************************************************************************************
**
** -------------------------------------------------------------------------------------------------
** File Name    : ISOUDS_RtnCntrl.c
**
** Description  : Routine Control Service
**
** -------------------------------------------------------------------------------------------------
**
***************************************************************************************************/

/**************************************** Inclusion files *****************************************/
#include "ISOUDS_RtnCntrl.h"
#include "ISOUDS_RtnCfg.h"
#include "FLSHM.h"
#include "FLSHM_Cfg.h"
#include "ISOUDS_SA.h"

/********************** Declaration of local symbol and constants *********************************/

/********************************* Declaration of local macros ************************************/
/* Start Routine */
#define     ISOUDS_STARTROUTINE     ((uint8)1)
/* Stop Routine */
#define     ISOUDS_STOPROUTINE      ((uint8)2)
/* Req Results Routine */
#define     ISOUDS_REQRESROUTINE    ((uint8)3)
/* Service length */
#define     ISOUDS_RTNCNTRLSERLEN   (4U)

/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/
/* Validation Flag value to be return after check sum validation */
const volatile uint16 ISOUDS_Chksm_Valid = (uint16)0x5A5AU;
static uint32 ISOUDS_iChksm;

/* Holds the configuration table index */
static uint8 ISOUDS_RtnTabIdx;
/* Holds whether Routine has been started or not */
static uint8 ISOUDS_RtnStarted[ISOUDS_RTNCONFTABSIZE];

static uint8 ISOUDS_iApp_BlockEr;
/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/

/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/
static uint8 ISOUDS_RtnLookUp (uint16 recvid);

/******************************** Function definitions ********************************************/

/***************************************************************************************************
** Function                 : ISOUDS_RtnCntrl

** Description              : Sends response to Read Data by ID service request

** Parameter ISOUDSConfPtr  : Pointer to service configuration structure

** Parameter dataBuff       : Data array

** Return value             : None
***************************************************************************************************/
void ISOUDS_RtnCntrl (ISOUDS_ConfType *ISOUDSConfPtr, uint8 dataBuff[])
{
    uint16  locID;    
    uint8   rtnType;
    uint8   rtnNoError = 0x00;
    uint8 Status;
    
    /* Check if received length is valid */
    if (ISOUDSConfPtr->srvLen >= (uint16)ISOUDS_RTNCNTRLSERLEN)
    {
        /* get the routine identifier value */
        locID = (uint16)((((uint16)dataBuff[(uint8)1U]) << (uint8)8U) +
                                        dataBuff[(uint8)2U]);

        //ISOUDS_iRtnID = locID; 
        /* Check if DID is configured for erase purpose */
        if (ISOUDS_TRUE == ISOUDS_RtnLookUp (locID))
        {
        	Status = ISOUDS_GetSAStLevel(1);
            
            /* Check if, ECU is locked */
            if (ISOUDS_TRUE == Status)
            {
                /* Check if DID is configured to be read in active session */
                if ((((ISOUDS_RtnConfTab[ISOUDS_RtnTabIdx].rtnIdSess) >> ISOUDS_Sess) & (uint8)1)
                                                                                    == (uint8)1)
                {
                    /* get the routine type */
                    rtnType = dataBuff[(uint8)0U];

                    /* if request for start routine */
                    if (ISOUDS_STARTROUTINE == rtnType)
                    {
                        /****************************************************************

                        INSERT CODE TO START ROUTINE BY EXTRACTING ROUTINE CONTROL OPTION
                        RECORD DATA(IF NEEDED) & UPDATE THE VARIABLE rtnNoError ACCORDINGLY

                        *****************************************************************/
                        /* invoke the corresponding function */
                        rtnNoError = (ISOUDS_RtnConfTab[ISOUDS_RtnTabIdx].ISOUDS_FunPtr)(ISOUDSConfPtr, &dataBuff[0U]);
                        
                        if ((uint8)ISOUDS_RTNCTRL_POSTIVE == rtnNoError)
                        {
                            /* Routine started */
                            ISOUDS_RtnStarted[ISOUDS_RtnTabIdx] = ISOUDS_STARTROUTINE;

                            /* Send positive response */
                            ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
                        }
                        else if ((uint8)ISOUDS_RTNCTRL_NEGTIVE == rtnNoError)
                        {
                            /* indicate negative response */
                            ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                            
                            /* General Programme Failure */
                            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
                        }
                        else if ((uint8)ISOUDS_RTNCTRL_PENDING == rtnNoError)
                        {                                      
                            /* indicate negative response */
                            ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                            
                            /* updated NRC */
                            ISOUDSConfPtr->srvNegResp = ISOUDS_RCRRP;
                        }
                        else if ((uint8)ISOUDS_RTNCTRL_SFNS == rtnNoError)
                        {                                      
                            /* indicate negative response */
                            ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                        
                            /* updated NRC */
                            ISOUDSConfPtr->srvNegResp = ISOUDS_SFNS;
                        }
						else if((uint8)ISOUDS_RTNCTRL_INVALID_LEN == rtnNoError)
						{
                            /* indicate negative response */
                            ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                            
                            /* Conditions Not Correct */
                            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
						}
                        else if ((uint8)ISOUDS_RTNCTRL_OTHER == rtnNoError)
                        {
                            /* indicate negative response */
                            ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                            
                            /* Conditions Not Correct */
                            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_CNC;
                        }
                        else
                        {
                            /* No Actions Required. */
                        }
                    }
                    else if (ISOUDS_STOPROUTINE == rtnType)
                    {
                        if (ISOUDS_RtnStarted[ISOUDS_RtnTabIdx] == ISOUDS_STARTROUTINE)
                        {
                            /****************************************************************

                            INSERT CODE TO STOP ROUTINE BY EXTRACTING ROUTINE CONTROL OPTION
                            RECORD DATA(IF NEEDED) & UPDATE THE VARIABLE rtnNoError ACCORDINGLY

                            *****************************************************************/
							rtnNoError = (ISOUDS_RtnConfTab[ISOUDS_RtnTabIdx].ISOUDS_FunPtr)(ISOUDSConfPtr, &dataBuff[0U]);
                            
	                        if ((uint8)ISOUDS_RTNCTRL_POSTIVE == rtnNoError)
							{
								/* Routine started */
								ISOUDS_RtnStarted[ISOUDS_RtnTabIdx] = ISOUDS_STARTROUTINE;

								/* Send positive response */
								ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
							}
							else if ((uint8)ISOUDS_RTNCTRL_NEGTIVE == rtnNoError)
							{
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* General Programme Failure */
								ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
							}
							else if ((uint8)ISOUDS_RTNCTRL_PENDING == rtnNoError)
							{                                      
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* updated NRC */
								ISOUDSConfPtr->srvNegResp = ISOUDS_RCRRP;
							}
							else if ((uint8)ISOUDS_RTNCTRL_SFNS == rtnNoError)
							{                                      
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
							
								/* updated NRC */
								ISOUDSConfPtr->srvNegResp = ISOUDS_SFNS;
							}
							else if((uint8)ISOUDS_RTNCTRL_INVALID_LEN == rtnNoError)
							{
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* Conditions Not Correct */
								ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
							}
							else if ((uint8)ISOUDS_RTNCTRL_OTHER == rtnNoError)
							{
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* Conditions Not Correct */
								ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_CNC;
							}
							else
							{
								/* No Actions Required. */
							}
						}
						else
						{
							/* indicate negative response */
							ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
							
							/* Routine Not Started */
							ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_RSE;
						}
                    }
                    else if (ISOUDS_REQRESROUTINE == rtnType)
                    {
                        if ((ISOUDS_RtnStarted[ISOUDS_RtnTabIdx] == ISOUDS_STARTROUTINE) ||
                            (ISOUDS_RtnStarted[ISOUDS_RtnTabIdx] == ISOUDS_STOPROUTINE))
                        {
                            /****************************************************************

                            INSERT CODE TO GET RESULTS & UPDATE THE VARIABLE rtnNoError
                            ACCORDINGLY

                            *****************************************************************/
							rtnNoError = (ISOUDS_RtnConfTab[ISOUDS_RtnTabIdx].ISOUDS_FunPtr)(ISOUDSConfPtr, &dataBuff[0U]);
                            
	                        if ((uint8)ISOUDS_RTNCTRL_POSTIVE == rtnNoError)
							{
								/* Routine started */
								ISOUDS_RtnStarted[ISOUDS_RtnTabIdx] = ISOUDS_REQRESROUTINE;

								/* Send positive response */
								ISOUDSConfPtr->srvSt = (uint8)ISOUDS_RESP;
							}
							else if ((uint8)ISOUDS_RTNCTRL_NEGTIVE == rtnNoError)
							{
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* General Programme Failure */
								ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
							}
							else if ((uint8)ISOUDS_RTNCTRL_PENDING == rtnNoError)
							{                                      
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* updated NRC */
								ISOUDSConfPtr->srvNegResp = ISOUDS_RCRRP;
							}
							else if ((uint8)ISOUDS_RTNCTRL_SFNS == rtnNoError)
							{                                      
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
							
								/* updated NRC */
								ISOUDSConfPtr->srvNegResp = ISOUDS_SFNS;
							}
							else if((uint8)ISOUDS_RTNCTRL_INVALID_LEN == rtnNoError)
							{
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* Conditions Not Correct */
								ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
							}
							else if ((uint8)ISOUDS_RTNCTRL_OTHER == rtnNoError)
							{
								/* indicate negative response */
								ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
								
								/* Conditions Not Correct */
								ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_CNC;
							}
							else
							{
								/* No Actions Required. */
							}
                        }
                        else
                        {
                            /* indicate negative response */
                            ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                            
                            /* Routine Not Started */
                            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_RSE;
                        }
                    }
                    else
                    {
                        /* indicate negative response */
                        ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                            
                        /* Sub Function Not Supported */
                        ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SFNS;
                    }
                }
                else
                {
                    /* indicate negative response */
                    ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                            
                    /* Request Out Of Range */
                    ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_ROOR;
                }
            }
            else
            {
                /* indicate negative response */
                ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
                
                /* Security Access Denied */
                ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_SAD;
            }
        }
        else
        {
            /* indicate negative response */
            ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
            
            /* Request Out Of Range */
            ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_ROOR;
        }
    }
    else
    {
        /* indicate negative response */
        ISOUDSConfPtr->srvSt = ISOUDS_RESPNEG;
        
        /* Invalid Message Length Or Invalid Format */
        ISOUDSConfPtr->srvNegResp = (uint8)ISOUDS_IMLOIF;
    }
}

/**************************** Internal Function definitions ***************************************/

/***************************************************************************************************
** Function                 : ISOUDS_RtnLookUp

** Description              : Checks whether the ID is configured for reading

** Parameter recvid         : ID received in the request

** Return value             : ISOUDS_TRUE  -> ID configured for reading
                              FALSE -> ID not configured for reading
***************************************************************************************************/
static uint8 ISOUDS_RtnLookUp (uint16 recvid)
{
    uint8 rtnidFound;
    uint8   idx;

    /* Initialize to FALSE */
    rtnidFound = ISOUDS_FALSE;

    /* Search in the routine configuration table whether the ID is configured */
    for (idx = (uint8)0U; ((idx < ((uint8)ISOUDS_RTNCONFTABSIZE)) && (rtnidFound != ISOUDS_TRUE)); idx++)
    {
        /* Check for a ID match */
        if (ISOUDS_RtnConfTab[idx].rtnid == recvid)
        {
            /* ID is configured for writing */
            rtnidFound = ISOUDS_TRUE;
            /* Save the index of the corresponding DID */
            ISOUDS_RtnTabIdx = idx;
        }
    }

    return (rtnidFound);
}

/*******************************************************************************
** Function                     : ISOUDS_EraseFlash

** Description                  : Requests for Erasing application block and 
                                  write CRC.

** Parameter                    : Pointer to CAN-Service configuration structure

** Return value                 : None

** Remarks                      : None
*******************************************************************************/
uint8 ISOUDS_EraseFlash (ISOUDS_ConfType *ISOUDS_Srv_ConfPtr, uint8 dataBuff[])
{

    FLSHM_ProgStat_t  flshjobstatus = FLSHM_SUCCESS;
    FLSHM_FlshMngrState_t flshMgrState = FLASHMGR_IDLE;

    uint8   rtnNoError = ISOUDS_RTNCTRL_INITIAL;   
    uint32 FlashEraseAddr = 0x00000000;
    uint32 FlashEraseEndAddr = 0x00000000;
	uint8 rtnType;
			
	rtnType = dataBuff[(uint8)0U];
	
	if (ISOUDS_STARTROUTINE == rtnType)
	{
		/* If received service request is a new message/request */
		if (ISOUDS_Srv_ConfPtr->srvSt == (uint8)ISOUDS_RXMSG)
		{
			if (ISOUDS_ERASE_SRV_LEN == ISOUDS_Srv_ConfPtr->srvLen)
			{ 
				/* Update service response length */
				ISOUDS_Srv_ConfPtr->srvLen = (uint16)4U;
		
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* initialize checksum erase */
				ISOUDS_iApp_BlockEr     = ISOUDS_FALSE;
				//rtnNoError = ISOUDS_RTNCTRL_INITIAL;
				
				/* Initiate erase */  
				// if ((ISOUDS_iApp_BlockEr == ISOUDS_FALSE))
				// {
				  if(FLASHMGR_IDLE == FLSHM_GetFlashState())
				  {
						FlashEraseAddr = (((uint32)dataBuff[3] << 24) | ((uint32)dataBuff[4] << 16) | ((uint32)dataBuff[5] << 8) | ((uint32)dataBuff[6] << 0));
						
						/* It is not Erase Size, but Erase end address */
						FlashEraseEndAddr = (((uint32)dataBuff[7] << 24) | ((uint32)dataBuff[8] <<16) | ((uint32)dataBuff[9] << 8) | ((uint32)dataBuff[10] << 0));

						if (FlashEraseAddr != FLSHM_SBL_START_ADDRS) {
							FlashEraseAddr		+= FLSHM_DL_ADDR_OFFSET;
							FlashEraseEndAddr	+= FLSHM_DL_ADDR_OFFSET;
						}

						/* Request erase  */
						flshjobstatus = FLSHM_EraseAppReq(FlashEraseAddr , FlashEraseEndAddr);
																
						
						if((flshjobstatus == FLSHM_INPROGRESS))
						{
						  /* indicate response pending to service provider */
						  ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPPEND;
						  rtnNoError = ISOUDS_RTNCTRL_PENDING;    
						}            
						else
						{
						  /* indicate negative response */
						  ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
						  rtnNoError = ISOUDS_RTNCTRL_NEGTIVE;              
						}
				  }
				  else
				  {
						/* indicate negative response */
						ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
						rtnNoError =ISOUDS_RTNCTRL_INITIAL;
				  }
				//}
				// else
				// {
					// /* Do nothing */
				// }
			}
			else
			{
				/* Invalid length. */
				rtnNoError = ISOUDS_RTNCTRL_INVALID_LEN;
			}
		}
		
		/* Erase operation is  pending*/
		else
		{   
			flshjobstatus = FLSHM_GetCMDStatus();
			flshMgrState = FLSHM_GetFlashState();
			
			if(flshMgrState == FLASHMGR_IDLE)
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 

			}
			else if(flshMgrState == FLASHMGR_ERASE)
			{
				
				/* Erase Pending */
									  /* indicate response pending to service provider */
			  ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPPEND;
			  rtnNoError = ISOUDS_RTNCTRL_PENDING;
			}
			else if (flshMgrState == FLASHMGR_ERASE_DONE)
			{
				if((FLSHM_SUCCESS == flshjobstatus))
				{
					/* Response length for the current Service - including SID */
					ISOUDS_Srv_ConfPtr->srvLen = 4;
					/* indicate positive response */
					rtnNoError = ISOUDS_RTNCTRL_POSTIVE;  
				}
				else
				{
					/* indicate negative response */
					ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;

					/* General Program Failure */
					ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
					rtnNoError = ISOUDS_RTNCTRL_NEGTIVE;
				}
			}
			else
			{
				/* error */
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE;
				
			}
		}
	}
	else if (ISOUDS_STOPROUTINE == rtnType)
	{
		/* indicate negative response */
		ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
		
		/* General Program Failure */
		ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_RSE;
		rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
	}
	else if (ISOUDS_REQRESROUTINE == rtnType)
	{
		flshjobstatus = FLSHM_GetCMDStatus();
		flshMgrState = FLSHM_GetFlashState();
		
		if(flshMgrState == FLASHMGR_IDLE)
		{
			if((FLSHM_ERASEFAILED == flshjobstatus))
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
			}
			else
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_RSE;
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
			}
		}
		else if (flshMgrState == FLASHMGR_ERASE_DONE)
		{
			if((FLSHM_SUCCESS == flshjobstatus))
			{
				/* Response length for the current Service - including SID */
				ISOUDS_Srv_ConfPtr->srvLen = 4;
				/* indicate positive response */
				rtnNoError = ISOUDS_RTNCTRL_POSTIVE;  
			}
			else
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;

				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE;
			}
		}
		else
		{
			/* error */
			/* indicate negative response */
		  ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
		  rtnNoError = ISOUDS_RTNCTRL_NEGTIVE;
			
		}
	}

    return (rtnNoError);
}


/***************************************************************************************************
** Function                     : ISOUDS_CheckProgrammDependency

** Description                  : Computes Digest for Application and Parameter Blocks

** Parameter CANSrvPConfPtr     : Pointer to CAN-Service configuration structure

** Return value                 : None

** Remarks                      : None
***************************************************************************************************/
uint8 ISOUDS_CheckProgrammDependency (ISOUDS_ConfType *ISOUDS_Srv_ConfPtr, uint8 dataBuff[])
{
	FLSHM_AppVldnStat_t  flshjobstatus = FLSHM_APPVALDN_IDLE;
	FLSHM_AppVldnStat_t flshMgrState = FLSHM_APPVALDN_IDLE;

    // volatile uint16 compare;  
    uint8   rtnNoError = 0U;  
    uint32  checksum;
    uint32 FlashCompStartAddr = 0x00000000;
    uint32 FlashCompEndAddr = 0x00000000;
	uint8 rtnType;

	rtnType = dataBuff[(uint8)0U];
	/* If received service request is a new message/request */
    if (ISOUDS_Srv_ConfPtr->srvSt == (uint8)ISOUDS_RXMSG)
	{
		if (ISOUDS_STARTROUTINE == rtnType)
		{
			  
			/* MISRA-C:2004 Rules 17.4 VIOLATION:
			  Array subscripting applied to an object of pointer type.
			  - Its required access the data stored in pointer */

			if(FLASHMGR_PROGRAM_DONE == FLSHM_GetFlashState())
			{
				FlashCompStartAddr = (((uint32)dataBuff[3] << 24) | ((uint32)dataBuff[4] << 16) | ((uint32)dataBuff[5] << 8) | ((uint32)dataBuff[6] << 0));
				
				FlashCompEndAddr = (((uint32)dataBuff[7] << 24) | ((uint32)dataBuff[8] <<16) | ((uint32)dataBuff[9] << 8) | ((uint32)dataBuff[10] << 0));
								
				/* get cheksum */
				checksum = (uint32)(((uint32)dataBuff[11U] << 24U) | ((uint32)dataBuff[12U] << 16U) | ((uint32)dataBuff[13U] << 8U) | ((uint32)dataBuff[14U] << 0U));

				/* store checksum */
				ISOUDS_iChksm = (uint32)checksum;

				if (FlashCompStartAddr != FLSHM_SBL_START_ADDRS) {
					FlashCompStartAddr	+= FLSHM_DL_ADDR_OFFSET;
					FlashCompEndAddr	+= FLSHM_DL_ADDR_OFFSET;
				}

				flshjobstatus = FLSHM_StartDwnlValdn(FlashCompStartAddr, FlashCompEndAddr, ISOUDS_iChksm);

				if((flshjobstatus == FLSHM_APPVALDN_REQ_ACCEPT))
				{
					/* indicate response pending to service provider */
					ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPPEND;
					rtnNoError = ISOUDS_RTNCTRL_PENDING;
				}
#if 0
				else
				{	
					/* indicate negative response */
					ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
					
					/* General Program Failure */
					ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
					rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
				}
#endif
			}
			else
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				rtnNoError =ISOUDS_RTNCTRL_INITIAL;
			}

		}
		else if (ISOUDS_STOPROUTINE == rtnType)
		{
	#if 0
			flshMgrState = FLSHM_GetAppValdnStat();
			
			if (FLSHM_DWNLD_VLDN_FLH_WRTFAIL == flshMgrState)
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
			}
			else if(FLSHM_DWNLD_VLDN_FLH_WRTPASS == flshMgrState)
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_CNC;
				
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
			}
			else if(FLSHM_DWNLD_VLDN_RUNNING == flshMgrState)
			{
				/* indicate negative response */
				FLSHM_StopAppValdn();
				
				/* Response length for the current Service - including SID */
				ISOUDS_Srv_ConfPtr->srvLen = 4;
				
				ISOUDS_Srv_ConfPtr->srvSt  = ISOUDS_RESP;
				
				rtnNoError = ISOUDS_RTNCTRL_POSTIVE;	
			}
			else
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_RSE;
				
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
			}
	#endif
		}
		else if (ISOUDS_REQRESROUTINE == rtnType)
		{
	#if 0
			flshMgrState = FLSHM_GetAppValdnStat();
			
			if (FLSHM_DWNLD_VLDN_FLH_WRTFAIL == flshMgrState)
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
			}
			else if(FLSHM_DWNLD_VLDN_FLH_WRTPASS == flshMgrState)
			{
				/* Response length for the current Service - including SID */
				ISOUDS_Srv_ConfPtr->srvLen = 4;
				
				ISOUDS_Srv_ConfPtr->srvSt  = ISOUDS_RESP;
				
				rtnNoError = ISOUDS_RTNCTRL_POSTIVE;
			}
			else if(FLSHM_DWNLD_VLDN_RUNNING != flshMgrState)
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
				
				/* General Program Failure */
				ISOUDS_Srv_ConfPtr->srvNegResp = (uint8)ISOUDS_GPF;
				
				rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
			}
			else
			{
				/* indicate negative response */
				ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPPEND;

				rtnNoError = ISOUDS_RTNCTRL_PENDING; 
			}
	#endif
		}
	}
	else
	{
		flshMgrState = FLSHM_GetAppValdnStat();
		
		if (FLSHM_DWNLD_VLDN_FAIL == flshMgrState)
		{
			/* indicate negative response */
			ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
			rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
		}
		else if(FLSHM_DWNLD_VLDN_PASS == flshMgrState)
		{
			/* Response length for the current Service - including SID */
			ISOUDS_Srv_ConfPtr->srvLen = 4;
			
			ISOUDS_Srv_ConfPtr->srvSt  = ISOUDS_RESP;
			
			rtnNoError = ISOUDS_RTNCTRL_POSTIVE;
		}
		else if(FLSHM_DWNLD_VLDN_RUNNING != flshMgrState)
		{
			/* indicate negative response */
			ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPNEG;
			rtnNoError = ISOUDS_RTNCTRL_NEGTIVE; 
		}
		else
		{
			ISOUDS_Srv_ConfPtr->srvSt = ISOUDS_RESPPEND;
			rtnNoError = ISOUDS_RTNCTRL_PENDING;
		}
	}
	
    /* Return the status */
    return (rtnNoError);

}
