
/*************************** Inclusion files **********************************/
#include "ISOUDS_AES128.h"
#include "ISOUDS_AES128_Cfg.h"
#include "Platform_Types.h"
#include <stdlib.h>
//#include "TIME.h"
#include <stdint.h>
/********************** Component configuration *******************************/

/**************** Declaration of local symbol and constants *******************/


/******************** Declaration of local macros *****************************/

/********************* Declaration of local types *****************************/

/******************* Declaration of local variables ***************************/
/**************** Substitue Box Array as per Galois Field. ***************************************************/
static uint8_t sub_box[256] =  {
	//0     1    2      3     4    5     6     7      8    9     A      B    C     D     E     F
	0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76, //0
	0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0, //1
	0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15, //2
	0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75, //3
	0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84, //4
	0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf, //5
	0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8, //6
	0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2, //7
	0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73, //8
	0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb, //9
	0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, //A
	0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08, //B
	0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a, //C
	0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e, //D
	0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf, //E
	0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 }; //F

/**************** Inverse Substitue Box Array as per Galois Field. ********************************************/
static uint8_t Inv_sub_box[256] =
{	//0		1	2		3	 4		5	 6		7	 8		9	 a		b	 c		d	 e		f
	0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,//0
 	0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,//1
 	0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,//2
 	0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,//3
 	0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,//4
 	0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,//5
 	0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,//6
 	0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,//7
 	0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,//8
 	0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,//9
 	0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,//a
 	0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,//b
 	0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,//c
 	0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,//d
 	0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,//e
 	0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d };//f


/******************** Round Constants RCon[i] calculated as per Galois field. ****************************/
static uint8_t round_const[255] = {
	0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a,
	0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39,
	0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a,
	0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8,
	0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef,
	0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc,
	0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b,
	0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3,
	0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94,
	0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20,
	0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35,
	0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd, 0x61, 0xc2, 0x9f,
	0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb, 0x8d, 0x01, 0x02, 0x04,
	0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63,
	0xc6, 0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91, 0x39, 0x72, 0xe4, 0xd3, 0xbd,
	0x61, 0xc2, 0x9f, 0x25, 0x4a, 0x94, 0x33, 0x66, 0xcc, 0x83, 0x1d, 0x3a, 0x74, 0xe8, 0xcb  };
/********************* Declaration of local constants *************************/


/******************** Declaration of exported variables ***********************/

/******************** Declaration of exported constant ************************/


/******************************************************************************
** FUNCTIONS **
*******************************************************************************/

/************************** Function definitions ******************************/

/************************** Function definitions ******************************/

/*******************************************************************************
** Function name: AES128_cipher_encrypt
** Description: AES128_cipher_encrypt() will perform rounds and calling subfunctions.
** Parameter index : message and pointer to roundkey.
** Return value: message.
** Remarks: No global variables used.
*******************************************************************************/
/* perform rounds of subfunction calling. */
uint8_t* AES128_cipher_encrypt(uint8_t Initmsgword[], const uint8_t* ptrtokey)
{
	uint8_t round;

	/* Add 1st round key to the msg_word. */
	AES128_Add_Round_Key(Initmsgword,ptrtokey,ZERO);

	/* perform the round 1 to 10 */
	for(round=ONE;round<no_of_round;round++)
	{
		AES128_Sub_Bytes(Initmsgword);
		AES128_Shift_Rows(Initmsgword);
		AES128_Mix_Column(Initmsgword);
		AES128_Add_Round_Key(Initmsgword,ptrtokey,round);
	}

	/* perform final round */
	AES128_Sub_Bytes(Initmsgword);
	AES128_Shift_Rows(Initmsgword);
	AES128_Add_Round_Key(Initmsgword,ptrtokey,no_of_round);

	return Initmsgword;
}

/*******************************************************************************
** Function name: AES128_Add_Round_key
** Description: AES128_Add_Round_key() will XORed the initial key with msg_state_word.
** Parameter index : Round count, pointer to message, pointer to roundkey.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/
/* perform XORed with round key and msg_state_word. */
void AES128_Add_Round_Key(uint8_t *ptrtomsgword, const uint8_t *ptrtokey, uint8_t round)
{
	uint8_t loop;

	if(ptrtokey != NULL)
	{
		for(loop=ZERO;loop<Two_Byte;loop++)
		{
			ptrtomsgword[loop] ^= ptrtokey[(round * key_length )+ loop ];
		}
	}
	else
	{
		/* do Nothing */
	}
}

/*******************************************************************************
** Function name: AES128_Sub_Bytes
** Description: AES128_Sub_Bytes() will substitute each msg_state_word with element from Sub_Box.
** Parameter index : pointer to message
** Return value: None
** Remarks: Sub_Box lookup table is used.
*******************************************************************************/
/* substitute the msg_state_word byte from element of Substitute box. */
void AES128_Sub_Bytes(uint8_t* ptrtomsgword)
{
	uint8_t loop;
	for(loop=ZERO;loop<Two_Byte;loop++)
	{
		/*substitute element from sub box look up table*/
		ptrtomsgword[loop] = (uint8_t)sub_box[ptrtomsgword[loop]];
	}
}

/*******************************************************************************
** Function name: AES128_Shift_Rows
** Description: AES128_Shift_Rows() will circular left shift the each row of msg_state_word.
				1st row will not shift, 2nd row left shifted by 1 byte
				3rd row left shifted by 2 bytes, 4th row left shifted by 3 bytes.
** Parameter index : pointer to message.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/
/* perform circular left shift on msg_state_word. */
void AES128_Shift_Rows(uint8_t* ptrtomsgword)
{
	uint8_t temp;
	/*1st row keep as it is*/
	/*2nd row left shifted by 1 byte.*/
	temp = ptrtomsgword[FOUR];
	ptrtomsgword[FOUR] = ptrtomsgword[FIVE];
	ptrtomsgword[FIVE] = ptrtomsgword[SIX];
	ptrtomsgword[SIX] = ptrtomsgword[SEVEN];
	ptrtomsgword[SEVEN] = temp;

	/*3rd row left shifted by 2 bytes.*/
	temp = ptrtomsgword[EIGHT];
	ptrtomsgword[EIGHT] = ptrtomsgword[TEN];
	ptrtomsgword[TEN] = temp;

	temp = ptrtomsgword[NINE];
	ptrtomsgword[NINE] = ptrtomsgword[ELEVEN];
	ptrtomsgword[ELEVEN] = temp;

	/*4th row left shifted by 3 bytes.*/
	temp = ptrtomsgword[TWELVE];
	ptrtomsgword[TWELVE] = ptrtomsgword[FIFTEEN];
	ptrtomsgword[FIFTEEN] = ptrtomsgword[FOURTEEN];
	ptrtomsgword[FOURTEEN] = ptrtomsgword[THIRTEEN];
	ptrtomsgword[THIRTEEN] = temp;

}

/*******************************************************************************
** Function name: AES128_Multiply
** Description: AES128_Multiply() will perform matrix multiplication with \
	msg_state_wordand fixed matrix as per galois field.
** Parameter index : msg_state_word and fixed matrix elemnet
** Return value: multiplication result.
** Remarks: No global variables used.
*******************************************************************************/

uint8_t AES128_Multiply(uint8_t msg_word, uint8_t element)
{
	uint8_t product=ZERO;
	uint8_t counter;
	uint8_t hi_bit;

	for(counter=ZERO;counter<EIGHT;counter++)
	{
		if((element & ONE) == ONE)  /* check the low bit of element is set */
		{
			/*if low bit is set xor the msg_word with product variable. */
			product ^= msg_word;
		}
		/* also check the higher bit of msg_word is set prior to shift operation. */
		hi_bit = ((msg_word >> SEVEN) & TRUE);
		/* left shift the msg_word by 1 byte. */
		msg_word = (uint8_t)(msg_word << ONE);
		if((hi_bit ) == TRUE)
		{
			/* higher bit of msg_word is set then xor it with 0x1b. */
			msg_word ^= FixedValue;
		}

		element >>=ONE;  /* right shift element by 1 byte. */

	}
	return product;
}

/*******************************************************************************
** Function name: AES128_Mix_Column
** Description: AES128_Mix_Column() will perform matrix multiplication and XORed with msg_state_word and fixed matrix.
** Parameter index : pointer to message.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/
/* perform matrix multiplication and XORoperation of fixed matrix with msg_state_word. */
void AES128_Mix_Column(uint8_t* ptrtomsgword)
{
	uint8_t loop;
	uint8_t temp1,temp2,temp3,temp4;

	for(loop=ZERO;loop<FOUR;loop++)
	{
		temp1 = ptrtomsgword[(loop*FOUR)];
		temp2 = ptrtomsgword[(loop*FOUR) + ONE];
		temp3 = ptrtomsgword[(loop*FOUR) + TWO];
		temp4 = ptrtomsgword[(loop*FOUR) + THREE];

		/*dot product of msg_word and fixed matrix as per galois field. */
		/* ith row 0th column. */
		ptrtomsgword[(loop*FOUR)] = AES128_Multiply(temp1, FixedMatrixData_2) ^ \
		AES128_Multiply(temp2, FixedMatrixData_1) ^ AES128_Multiply(temp3, FixedMatrixData_1)\
		 ^ AES128_Multiply(temp4, FixedMatrixData_3);

		/* ith row 1st column. */
		ptrtomsgword[(loop*FOUR) + ONE] = AES128_Multiply(temp1, FixedMatrixData_3) ^\
		 AES128_Multiply(temp2, FixedMatrixData_2) ^ AES128_Multiply(temp3, FixedMatrixData_1)\
		  ^ AES128_Multiply(temp4, FixedMatrixData_1);

		/* ith row 2nd column. */
		ptrtomsgword[(loop*FOUR) + TWO] = AES128_Multiply(temp1, FixedMatrixData_1) ^ \
		AES128_Multiply(temp2, FixedMatrixData_3) ^ AES128_Multiply(temp3, FixedMatrixData_2)\
		 ^ AES128_Multiply(temp4, FixedMatrixData_1);

		/* ith row 3rd column. */
		ptrtomsgword[(loop*FOUR) + THREE]= AES128_Multiply(temp1, FixedMatrixData_1) ^ \
		AES128_Multiply(temp2, FixedMatrixData_1) ^ AES128_Multiply(temp3, FixedMatrixData_3)\
		 ^ AES128_Multiply(temp4, FixedMatrixData_2);
	}

}

/*******************************************************************************
** Function name: AES128_Key_Expansion
** Description: AES128_Key_Expansion() will take initial key and generate different key for different round.
** Parameter index : pointer to Initialkey.
** Return value:  None.
** Remarks: Sub_Box lookup table and round const lookup table is used.
*******************************************************************************/
/* Geenrate 10 different key for 10 rounds. */
void AES128_Key_Expansion(uint8_t *ptrtokey)
{
	uint8_t outloop,inloop;
	uint8_t last_word[FOUR];
	uint8_t temp;
	/*uint8_t roundkey[176];*/

	for(outloop=no_of_words;outloop < (no_of_words * (no_of_round + ONE));outloop++)
	{
		for(inloop=ZERO;inloop<FOUR;inloop++)
		{
			/* get the last word from msg_word */
			last_word[inloop] = ptrtokey[((outloop-ONE) * FOUR) + inloop];
		}

		if((outloop % FOUR) == ZERO)
		{
			/* Rotational word */
			temp = last_word[ZERO];
			last_word[ZERO] = last_word[ONE];
			last_word[ONE] = last_word[TWO];
			last_word[TWO] = last_word[THREE];
			last_word[THREE] = temp;

			/* Substitute word */
			last_word[ZERO] = (uint8_t)sub_box[last_word[ZERO]];
			last_word[ONE] = (uint8_t)sub_box[last_word[ONE]];
			last_word[TWO] = (uint8_t)sub_box[last_word[TWO]];
			last_word[THREE] = (uint8_t)sub_box[last_word[THREE]];

			/* xor with Round constant */
			last_word[ZERO] = (uint8_t)(last_word[ZERO] ^ (uint8_t)round_const[outloop/FOUR]);
		}

		/* getting next word from 4th previous word */
		/* next word will be XOR of previous word and 4th previous word. */
		ptrtokey[(outloop * FOUR )] = ptrtokey[((outloop - FOUR) * no_of_words)] ^ last_word[ZERO];
		ptrtokey[(outloop * FOUR )+ ONE] = ptrtokey[((outloop - FOUR) * no_of_words)+ ONE] ^ last_word[ONE];
		ptrtokey[(outloop * FOUR )+ TWO] = ptrtokey[((outloop - FOUR) * no_of_words)+ TWO] ^ last_word[TWO];
		ptrtokey[(outloop * FOUR )+ THREE] = ptrtokey[((outloop - FOUR) * no_of_words)+ THREE] ^ last_word[THREE];
	}

}

/*******************************************************************************
** Function name: AES128_cipher_decrypt
** Description: AES128_cipher_decrypt() will perform rounds inverse of cipher and calling subfunctions.
** Parameter index : cipher message and round key.
** Return value: cipher message.
** Remarks: No global variables used.
*******************************************************************************/
/* perform round of subfunction calling. */
uint8_t* AES128_cipher_decrypt(uint8_t ciphermsgword[], const uint8_t* ptrtokey)
{
	uint8_t round = no_of_round - ONE;
	/* Add last round key to the msg_word. */

	AES128_Add_Round_Key(ciphermsgword,ptrtokey,no_of_round);
	/* perform the round 10 to 1 */
	for(;round>ZERO;round--)
	{
		AES128_Inv_Shift_Rows(ciphermsgword);
		AES128_Inv_Sub_Bytes(ciphermsgword);
		AES128_Add_Round_Key(ciphermsgword,ptrtokey,round);
		AES128_Inv_Mix_Column(ciphermsgword);
	}

	/* perform final round */
	AES128_Inv_Shift_Rows(ciphermsgword);
	AES128_Inv_Sub_Bytes(ciphermsgword);
	AES128_Add_Round_Key(ciphermsgword,ptrtokey,ZERO);


	return ciphermsgword;
}

/*******************************************************************************
** Function name: AES128_Inv_Shift_Rows
** Description: AES128_Inv_Shift_Rows() will circular Right shift the \
				each row of msg_state_word.
				1st row will not shift, 2nd row right shifted by 1 byte
				3rd row right shifted by 2 bytes, 4th row right shifted by 3 bytes.
** Parameter index : pointer to cipher message.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/

void AES128_Inv_Shift_Rows(uint8_t* ptrtociphermsgword)
{
	uint8_t temp;
	/*1st row keep as it is*/
	/*2nd row left shifted by 1 byte.*/
	temp = ptrtociphermsgword[SEVEN];
	ptrtociphermsgword[SEVEN] = ptrtociphermsgword[SIX];
	ptrtociphermsgword[SIX] = ptrtociphermsgword[FIVE];
	ptrtociphermsgword[FIVE] = ptrtociphermsgword[FOUR];
	ptrtociphermsgword[FOUR] = temp;

	/*3rd row left shifted by 2 bytes.*/
	temp = ptrtociphermsgword[EIGHT];
	ptrtociphermsgword[EIGHT] = ptrtociphermsgword[TEN];
	ptrtociphermsgword[TEN] = temp;

	temp = ptrtociphermsgword[NINE];
	ptrtociphermsgword[NINE] = ptrtociphermsgword[ELEVEN];
	ptrtociphermsgword[ELEVEN] = temp;

	/*4th row left shifted by 3 bytes.*/
	temp = ptrtociphermsgword[TWELVE];
	ptrtociphermsgword[TWELVE] = ptrtociphermsgword[THIRTEEN];
	ptrtociphermsgword[THIRTEEN] = ptrtociphermsgword[FOURTEEN];
	ptrtociphermsgword[FOURTEEN] = ptrtociphermsgword[FIFTEEN];
	ptrtociphermsgword[FIFTEEN] = temp;

}

/*******************************************************************************
** Function name: AES128_Inv_Sub_Bytes
** Description: AES128_Inv_Sub_Bytes() will substitute each msg_state_word \
				with element from Inv_Sub_Box.
** Parameter index : pointer to cipher message.
** Return value: None
** Remarks: Inv_sub_box lookup table is used.
*******************************************************************************/

void AES128_Inv_Sub_Bytes(uint8_t* ptrtociphermsgword)
{
	uint8_t loop;

	for(loop=ZERO;loop<Two_Byte;loop++)
	{
		/*substitute element from inverse sub box look up table.*/
		ptrtociphermsgword[loop] = (uint8_t)Inv_sub_box[ptrtociphermsgword[loop]];
	}

}

/*******************************************************************************
** Function name: AES128_Inv_Mix_Column
** Description: AES128_Inv_Mix_Column() will perform matrix multiplication \
				and XORed with msg_state_word and fixed matrix.
** Parameter index : pointer to cipher message.
** Return value: None
** Remarks: No global variables used.
*******************************************************************************/

void AES128_Inv_Mix_Column(uint8_t* ptrtociphermsgword)
{
	uint8_t loop;
	uint8_t temp1,temp2,temp3,temp4;

	for(loop=ZERO;loop<FOUR;loop++)
	{
		temp1 = ptrtociphermsgword[(loop*FOUR)];
		temp2 = ptrtociphermsgword[(loop*FOUR) + ONE];
		temp3 = ptrtociphermsgword[(loop*FOUR) + TWO];
		temp4 = ptrtociphermsgword[(loop*FOUR) + THREE];

		/*dot product of msg_word and fixed matrix as per galois field. */
		/* ith row 0th column. */
		ptrtociphermsgword[(loop*FOUR)] = AES128_Multiply(temp1, InvFixedMatrixData_4) ^ \
		AES128_Multiply(temp2, InvFixedMatrixData_1) ^ AES128_Multiply(temp3, InvFixedMatrixData_3)\
		 ^ AES128_Multiply(temp4, InvFixedMatrixData_2);

		/* ith row 1st column. */
		ptrtociphermsgword[(loop*FOUR) + ONE] = AES128_Multiply(temp1, InvFixedMatrixData_2) ^\
		 AES128_Multiply(temp2, InvFixedMatrixData_4) ^ AES128_Multiply(temp3, InvFixedMatrixData_1)\
		  ^ AES128_Multiply(temp4, InvFixedMatrixData_3);

		/* ith row 2nd column. */
		ptrtociphermsgword[(loop*FOUR) + TWO] = AES128_Multiply(temp1, InvFixedMatrixData_3) ^ \
		AES128_Multiply(temp2, InvFixedMatrixData_2) ^ AES128_Multiply(temp3, InvFixedMatrixData_4)\
		 ^ AES128_Multiply(temp4, InvFixedMatrixData_1);

		/* ith row 3rd column. */
		ptrtociphermsgword[(loop*FOUR) + THREE]= AES128_Multiply(temp1, InvFixedMatrixData_1) ^ \
		AES128_Multiply(temp2, InvFixedMatrixData_3) ^ AES128_Multiply(temp3, InvFixedMatrixData_2)\
		 ^ AES128_Multiply(temp4, InvFixedMatrixData_4);
	}
}

/*void Generatecipherkey(uint8_t msgword[], const uint8_t constantkey[],uint8_t *ptr)*/
/*void Generatecipherkey(uint8_t msgword[], const uint8_t *constantkey,uint8_t *ptr)*/
void Generatecipherkey(uint8_t *SEED,uint8_t *ptr)
{
	uint8_t *ptrtocipherkey;
	uint8_t numofbytes=ZERO;
	uint8_t count;
	/* variable holding all key requred for 10 round. */
	uint8_t roundkey[MAX_LENGHTKEY];
	uint8_t msg [Two_Byte];
	uint8_t constantkey[Two_Byte];
	for(count=ZERO;count<Two_Byte;count++)
	{
		msg[count] = SEED[count];
	}

	for(count=Two_Byte;count<Four_Byte;count++)
	{
		constantkey[numofbytes] = SEED[count];
		numofbytes++;
	}
	
		for(numofbytes=ZERO;numofbytes<Two_Byte;numofbytes++)
		{
			/* 1 round key is initial key */
			roundkey[numofbytes] = constantkey[numofbytes];
		}

		/*to generate round keys for each round.*/
		AES128_Key_Expansion(roundkey);

		ptrtocipherkey = AES128_cipher_encrypt(msg, roundkey);
		for(numofbytes=ZERO;numofbytes<Two_Byte;numofbytes++)
		{
			ptr[numofbytes] = ptrtocipherkey[numofbytes];
		}
	

}

/*void Genrerateoriginalmsg(uint8_t finalword[], const uint8_t key[],uint8_t *ptrtooriginal)*/
void Genrerateoriginalmsg(uint8_t finalword[], const uint8_t *key,uint8_t *ptrtooriginal)
{
	uint8_t numofbytes;
	/* variable holding all key requred for 10 round. */
	uint8_t roundkey[MAX_LENGHTKEY];
	uint8_t *ptrtogetoriginalmsg;

	if(key != NULL)
	{
		for(numofbytes=ZERO;numofbytes<Two_Byte;numofbytes++)
		{
			/* 1 round key is initial key */
			roundkey[numofbytes] = key[numofbytes];
		}

		/*to generate round keys for each round.*/
		AES128_Key_Expansion(roundkey);

		ptrtogetoriginalmsg = AES128_cipher_decrypt(finalword,roundkey);

		for(numofbytes=ZERO;numofbytes<Two_Byte;numofbytes++)
		{
			ptrtooriginal[numofbytes] = ptrtogetoriginalmsg[numofbytes];
		}
	}
	else
	{
		/* do nothing */
	}
}

/*******************************************************************************
** Function name: GenerateRandomNum
** Description: GenerateRandomNum() will generate the Random numbers.
** Parameter index :  Pointer to hold the generated Random Numbers.
** Return value: None
** Remarks:  No global variables used.
*******************************************************************************/

void GenerateRandomNum(uint8_t *ptrtoBuffer)
{
	static uint32_t startaddress = TopofStack-(uint32_t)ONE; /* For starting address */

	/*uint8_t Seed[16];*/
  	uint8_t value;					/* To hold the value present at address */
  	static uint8_t Prevvalue = ZERO;  /* To hold the previous value */
 	uint8_t count = ZERO;
 	void *sp;					/* To hold the address from stack pointer */

 	getstackptr(sp);			/* get the address from stack pointer */

	uint32_t stackptr_address = 0;
	/* extract value from start address */
 	value = (*(uint8_t*)startaddress);

	/* Loop for traverse in stack */
  	for(count=ZERO;count<MAX_LOOP;count++)
  	{
  		/* value should not be zero and other than previous value */
	  if(value == ZERO || Prevvalue == value)
	  {
	  	/* change the start address */
		  startaddress = startaddress - (uint32_t)ONE;

			stackptr_address = (uint32_t)sp;
			/* start address must be greater than stack pointer */
		  if(startaddress < stackptr_address)
		  {
		  		/* make start address as top of stack */
				startaddress = TopofStack-(uint32_t)ONE;
		  }

		  else
		  {
		  	/* Do Nothing */
		  }

		  /* extract value from start address */
		  value = (*(uint8_t*)startaddress);
	  }
	  else
	  {
	  	/* come out of for Loop */
		break;
	  }
  	}

	/* change the start address */
  	startaddress = startaddress - (uint32_t)ONE;
	stackptr_address = (uint32_t)sp;
	/* start address must be greater than stack pointer */
  	if(startaddress < stackptr_address)
 	 {
 	 	/* make start address as top of stack */
 		 startaddress = TopofStack-(uint32_t)ONE;
 	 }

 	 /* save the present value in Previous for next time checking */
  	Prevvalue = value;
  	/* use value for random function */
  	srand(value);

	/* loop for generating the Random Numbers */
  	if(NULL != ptrtoBuffer)
  	{
  		for(count = ZERO; count < MAX_LENGTH; count++ )
  		{
  			ptrtoBuffer[count] = (uint8_t)rand();
  		}
  	}
  	else
  	{
  		/* Do Nothing */
  	}

}

unsigned char generateKeyLevel1(unsigned long  seed, unsigned long  *p_key)
{
	(void)seed;
    p_key[0] = 0xCDABCDAB;
    
    return 0;
}

unsigned char generateKeyLevel3(unsigned long seed, unsigned long *p_key)
{
    uint8 *seed_pntr;
    
    seed_pntr = (uint8 *)&seed;
    
    seed_pntr[0] ^= 0x66;
    seed_pntr[1] ^= 0x66;
    seed_pntr[2] ^= 0x66;
    seed_pntr[3] ^= 0x66;
    
    p_key[0] = seed;
    
    return 0;
}

unsigned char generateKeyLevel7(unsigned long seed, unsigned long *p_key)
{
    uint8 *seed_pntr;
    
    seed_pntr = (uint8 *)&seed;
    
    seed_pntr[0] ^= 0x66;
    seed_pntr[1] ^= 0x66;
    seed_pntr[2] ^= 0x66;
    seed_pntr[3] ^= 0x66;
    
    p_key[0] = seed;
    
    return 0;
}


unsigned char generateKeyLevel41(unsigned long seed, unsigned long *p_key)
{
     uint8 *seed_pntr;
    
    seed_pntr = (uint8 *)&seed;
    
    seed_pntr[0] ^= 0x66;
    seed_pntr[1] ^= 0x66;
    seed_pntr[2] ^= 0x66;
    seed_pntr[3] ^= 0x66;
    
    p_key[0] = seed;
    
    return 0;
}

unsigned long GetSeedLevel3(void)
{
  unsigned long Seed;
  
  unsigned long next = 0;
  
  while (0 == next)
  {
          next = rand();
          
          next = next * 1103515245UL + 12345;
  }
  /* Passing the timer value as seed */
  Seed = next;
  
    return(Seed);
}

unsigned long GetSeedLevel7(void)
{
  unsigned long Seed;
  
  unsigned long next = 0;
  
  while (0 == next)
  {
          next = rand();
          
          next = next * 1103515245UL + 12345;
  }
  /* Passing the timer value as seed */
  Seed = next;
  
    return(Seed);
}

unsigned long GetSeedLevel41(void)
{
  unsigned long Seed;
  
  unsigned long next = 0;
  
  while (0 == next)
  {
          next = rand();
          
          next = next * 1103515245UL + 12345;
  }
  /* Passing the timer value as seed */
  Seed = next;
  
    return(Seed);
}

unsigned long GetSeedLevel1(void)
{
    return(0xCDABCDAB);
}
