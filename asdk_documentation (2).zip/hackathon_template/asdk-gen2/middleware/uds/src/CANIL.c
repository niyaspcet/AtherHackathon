/***************************************************************************************************
** Copyright (c) 2018 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL.
**
** -------------------------------------------------------------------------------------------------
** File Name    : CanIL.c
** Module Name  : Can Interface Module
** -------------------------------------------------------------------------------------------------
**
** Description : Extracts the information from CAN driver and provides to upper layer and
**               vice-versa.
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N H I S T O R Y
****************************************************************************************************
** V01.00 22/07/2019
** - Baseline Created
** ------------------------------------------------------------------------------------------------
**
**
***************************************************************************************************/
/**************************************** Inclusion files ****************************************/
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "CanIL_Cfg.h"
#include "CANIL.h"
#ifndef ASDK_CAN_INTF
#include "CANT.h"
#include "CanNM.h"
#endif
#include "CanTp.h"
#include "CanTp_Cfg.h"

/******************* Declaration of local macros ******************************/
#ifndef CANIL_GLOBAL_DIAG_REQ_ID
#define CANIL_GLOBAL_DIAG_REQ_ID	 0
#endif

#ifndef MAX_CANIL_SECHD_TIME
#define MAX_CANIL_SECHD_TIME     CANIL_SECHD_TIME
#endif
/******************* Declaration of structure variables ***********************/
static CanMod_DiagRxMsgId_st DiagRxMsgId;
uint64 CANIL_DataBufComplmt[CANIL_NO_OF_TXRX_MESSAGES];
#ifdef ASDK_CAN_INTF

CANIL_UDSmsgVal CANT_UDStxVal; 
CANIL_UDSmsgVal CANT_UDSRxVal;

ISOTPTXReq_CHTYPE ISOTP_TxReqConfTable[ISOTP_NO_OF_CHANNELS] = {0};
#endif
uint8_t Global_Index;

/******************* Declaration of local variables ***************************/
static uint8_t CANIL_TxPendingQueueData; /*count for pending queue Tx messages */
static uint8_t CANIL_TxWrQueueIndex;/*write index for Tx Queue */
static uint8_t CANIL_TxRdQueueIndex;/*read index for Tx Queue */
static CANIL_Msg_st CANIL_TxMsgQueue[CANIL_TX_MESGQUEUE_SIZE];/*Tx messages queue */
static  uint32_t CANIL_TxRxHndlrCount[CANIL_NO_OF_TXRX_MESSAGES] ={0};/*Tx & Rx CAN msg cyclic count */
/******************** Local Function Declarations ************************************************/
static void CANIL_TransmitMsg(uint8_t MsgIndex);
static void CANIL_PrepareTxDataBuffer(CANIL_Msg_st *tx_frame, uint8_t MsgIndex);
#ifndef ASDK_CAN_INTF
static void CANIL_TransmitMsgHandlar(uint8_t Index);
static void CANIL_EnQueueTxMsg (CANIL_Msg_st *Msg);
static void CANIL_DeQueueTxMsg(CANIL_Msg_st *Msg);
#endif
static CANIL_MsgValidation_enum CANIL_FindTxRxMsgIndex(uint32_t MsgId, uint8_t *MsgIndex, uint8_t MesgDir);

/**************************************************************************************************
**                                      FUNCTIONS                                                **
**************************************************************************************************/
/**************************************************************************************************
** Function name    : CANIF_Init
**
** Description      : Initialized the CANIF parameters.
**
** Parameter        : asdk_canil_cbk_t - CAN channel structure 
**
** Return value     : None
**
** Remarks          : None
**************************************************************************************************/
void CANIL_Init (asdk_canil_cbk_t *asdk_canil_cfg )
{
	// uint32_t CanBaudRate = CANIL_INIT_VAL;
	uint8_t index;

	/*Initialized required parameters for CAN IF.*/
	CANIL_TxPendingQueueData = CANIL_INIT_VAL ;
	CANIL_TxWrQueueIndex = CANIL_INIT_VAL;
	CANIL_TxRdQueueIndex = CANIL_INIT_VAL;
	memset(CANIL_TxMsgQueue,CANIL_INIT_VAL,sizeof(CANIL_TxMsgQueue));
#ifdef 	ASDK_CAN_INTF

	CANT_UDStxVal = CANIL_ENABLE; 	
	CANT_UDSRxVal = CANIL_ENABLE;

        /* store CANIL function */
	for ( index =0; index < asdk_canil_cfg->max_tx_channel; index++)
	{
		if(index < ISOTP_NO_OF_CHANNELS) 
			ISOTP_TxReqConfTable[ index ] = (asdk_canil_cfg->TxReqConfTable[index]);
	}

#else
	/*Init CAN driver*/
	CANT_Init(CanBaudRate,CANIL_TxRxMessageTable);
#endif
}

/**************************************************************************************************
** Function name : CANT_RxMsgIdSet
** Description   : Configure the Rx message id
** Parameter     : RxMsgId				Specifies the CAN_ID
** 				   MsgFormat			Specifies the CAN types, Standard or Extended.
** 				   FitIdx				Index to write the ID
** Return value  : void
** Remarks       : global variables used, side effects
**************************************************************************************************/
void CANIL_RxMsgIdSet(uint32 CANIL_RxMsgId,uint8 CANIL_MsgFormat,uint8 CANIL_FitIdx)
{
	(void)CANIL_MsgFormat;
	/*Passing the Id ,Format and Filter Idx to CAN driver*/
	// CANT_RxMsgIdSet(CANIL_RxMsgId,CANIL_MsgFormat,CANIL_FitIdx);
	if(CANIL_FALSE == CANIL_FitIdx)
	{
		/*update Rx msg Id for CANIF filter*/
		DiagRxMsgId.ServId = CANIL_RxMsgId;
	}
	else if(CANIL_TRUE == CANIL_FitIdx)
	{
		/*update Rx msg Id for CANIF filter*/
		DiagRxMsgId.ClientId = CANIL_RxMsgId;
	}
	else
	{
		/*do nothing*/
	}
}
/**************************************************************************************************
** Function name    : CANIF_ReceiveMsg
**
** Description      : Read Rx message from CAN driver and update the data buffer.
**
** Parameter        : MsgID - Messaged id of Rx CAN message
**					: dlc  -  Data length of collected RX message
**					: *Data - pointer to collected Rx data.

** Return value     : TRUE when message processed, FALSE when couldnt process the message

** Remarks          : None
**************************************************************************************************/
bool CANIL_ReceiveMsg(uint32_t MsgID, uint8_t dlc, uint8_t* Data,  uint8 ISOTP_CH)
{
	uint8_t 		Msgindex = CANIL_INIT_VAL;
	CANIL_Msg_st 	ISOTP_MsgCfg;
	ISOTP_ReqType	ReqType = ISOTP_FUNCTIONALREQ;
	bool processed = FALSE;
	uint8_t ISOTP_CHFlag = ISOTP_CH;

	if((CANIL_GLOBAL_DIAG_REQ_ID == MsgID) ||
	   (CANIL_MCM_DIAG_REQ_ID == MsgID) /*||
			(DiagRxMsgId.ClientId == MsgID)*/)
	{
		/* call Rx function to collect  Diag Msg */
		ISOTP_MsgCfg.MsgID =  MsgID;
		ISOTP_MsgCfg.dlc = dlc;
		memset(ISOTP_MsgCfg.dataBuff,CANIL_INIT_VAL,CANIL_MAX_DATA_LENGTH);
		memcpy(ISOTP_MsgCfg.dataBuff,Data,dlc);

		if(CANIL_GLOBAL_DIAG_REQ_ID == MsgID)
		{
			ReqType = ISOTP_FUNCTIONALREQ;
		}

		if(CANIL_MCM_DIAG_REQ_ID == MsgID)
		{
			ReqType = ISOTP_PHYSICALREQ;
		}
		else
		{
			/* Do nothing */
		}

		ISOTP_RxMsgCbk(ISOTP_MsgCfg.MsgID, ISOTP_MsgCfg.dlc, ISOTP_MsgCfg.dataBuff, ReqType, ISOTP_CHFlag);

		processed = TRUE;
	}
	else
	{
		/* find message index of Rx message*/
		for (Msgindex = CANIL_NO_OF_TX_MESSAGES; Msgindex < CANIL_NO_OF_TXRX_MESSAGES; Msgindex++)
		{
			if(CANIL_TxRxMessageTable[Msgindex].MesgID == MsgID )
			{
				/* update the read DLC*/
				if(CANIL_NULL_PTR != CANIL_TxRxMessageTable[Msgindex].RxdDLC)
				{
					/* update the read DLC*/
					(*(CANIL_TxRxMessageTable[Msgindex].RxdDLC)) = dlc;
					/*store data in respective message data buffer*/
					memcpy(CANIL_TxRxMessageTable[Msgindex].DataPtr,Data,CANIL_MAX_DATA_LENGTH);

					/* Invert the Rx Data and store */
					CANIL_DataBufComplmt[Msgindex] = ~(*CANIL_TxRxMessageTable[Msgindex].DataPtr);

					(*CANIL_TxRxMessageTable[Msgindex].CalbackFun)(MsgID, dlc, (uint8 *)CANIL_TxRxMessageTable[Msgindex].DataPtr);

					/*Indicating the updation of new Rx data*/
					(*(CANIL_TxRxMessageTable[Msgindex].MsgIndcn)) = CANIL_FLAG_SET;

					Msgindex = CANIL_NO_OF_TXRX_MESSAGES;

					processed = TRUE;
				}
				else
				{
					/* do nothing */
				}
			}
		}
	}

	//CanNMClearBusOffStat(); //TODO AFR

	return processed;
}

/**************************************************************************************************
** Function name    : App_GetRxMsg
**
** Description      : Read requested signal data from the Rx data buffer.
**
** Parameter        : MsgId - Message Id
**					  *SignalData - pointer to collect requested signal data

** Return value     : ErrorCode - Error code as par collected data.

** Remarks          : None
**************************************************************************************************/
uint8_t CANIL_GetRxMsg (uint32_t MsgId, float * DataBuff, uint8_t *SignCount)
{
	uint8_t MsgIndex = CANIL_UINT8_MAX_VAL;
	uint8_t ErrorCode = (uint8_t)CANIL_INVALID_CAN_MSG;

	/*Collect the requested signal data from the Rx Signal data buffer */
	if( CANIL_VALID_CAN_MSG == CANIL_FindTxRxMsgIndex(MsgId,&MsgIndex, CANIL_RXMESG))
	{
		/*collect signal data of the message*/
		(*SignCount) = CANIL_GetMesgSignals(MsgIndex, DataBuff);

		ErrorCode = (uint8_t)CANIL_VALID_CAN_MSG;
	}

	/*return with error code as per collected signal data */
	return ErrorCode;
}

/**************************************************************************************************
** Function name    : CANIF_SetTxMsg
**
** Description      : Set requested signal data in Tx data buffer.
**
** Parameter        : SignalId - signal Id
**					  SignalData - signal data to transmit

** Return value     : ErrorCode - Error code as par signal data set for Tx message.

** Remarks          : None
**************************************************************************************************/
uint8_t CANIL_SetTxMsg (uint32_t MsgId, float * DataBuff, uint8_t SignCount)
{
	uint8_t MsgIndex = CANIL_UINT8_MAX_VAL;
	uint8_t ErrorCode = (uint8_t)CANIL_INVALID_CAN_MSG;
	uint8_t NumbOfSig = CANIL_INIT_VAL;

	/*set the requested signal data to the Tx Signal data buffer */
	if( CANIL_VALID_CAN_MSG == CANIL_FindTxRxMsgIndex(MsgId,&MsgIndex, CANIL_TXMESG))
	{
		/* store data in CAN Message buffer*/
		NumbOfSig = CANIL_PutMesgSignals(CANIL_TxRxMessageTable[MsgIndex].MesgID, DataBuff);

		if(NumbOfSig == SignCount)
		{
			/*Set flag for Tx event message */
			if(CANIL_EVENT == CANIL_TxRxMessageTable[MsgIndex].TxMethod)
			{
				/*set event flag for respective CAN msg. Each bit represents the respective msg buffer index */
				CANIL_TxRxHndlrCount[MsgIndex] = CANIL_TRUE;
			}
			ErrorCode = (uint8_t)CANIL_VALID_CAN_MSG;
		}
		else
		{
			/*do nothing*/
		}

	}
	/*return with error code as par signal data set for Tx message */
	return ErrorCode;
}
/**************************************************************************************************
** Function name : CANIL_SetTx_Event_Msg
** Description   : set tx event message 
** Parameter     : MsgIndex
** Return value  : status
** Remarks       : None
**************************************************************************************************/
uint8_t CANIL_SetTx_Event_Msg (uint8_t MsgIndex )
{

	uint8_t ErrorCode = (uint8_t)CANIL_FLAG_RESET;

	/*Set flag for Tx event message */
	if(CANIL_EVENT == CANIL_TxRxMessageTable[MsgIndex].TxMethod)
	{
		/*set event flag for respective CAN msg. Each bit represents the respective msg buffer index */
		CANIL_TxRxHndlrCount[MsgIndex] = CANIL_TRUE;
		ErrorCode = (uint8_t)CANIL_FLAG_SET;
	}
	
	return ErrorCode;
}
/**************************************************************************************************
** Function name    : CANIF_TxConfCbk
**
** Description      : Send acknowledgment for data transmission completed.
**
** Parameter        : MailBoxIndex - mail box index of transmission complete message.

** Return value     : None

** Remarks          : None
**************************************************************************************************/
#ifndef ASDK_CAN_INTF
void CANIL_TxDeQueue(){
	CANIL_Msg_st tx_frame;
	uint8_t MsgIndex = CANIL_UINT8_MAX_VAL;
#ifdef ASDK_CAN_INTF
	ISOTP_CHType iso_ch = ISOTP_CH_CAN_0;
#endif
	/*check for pending to transmit */
	if(CANIL_TxPendingQueueData)
	{
		/*Prepare the Tx msg frame */
		CANIL_DeQueueTxMsg(&tx_frame);

		if( CANIL_VALID_CAN_MSG == CANIL_FindTxRxMsgIndex(tx_frame.MsgID,&MsgIndex, CANIL_TXMESG))
		{
#ifdef  ASDK_CAN_INTF

			(*ISOTP_TxReqConfTable[iso_ch])(tx_frame.MsgID, CANIL_STANDARD, tx_frame.dlc, &tx_frame.dataBuff[0]);
#else	
			/* Set Tx message frame to write on CAN Tx line */
			CAN0_TxMsg(tx_frame.MsgID,tx_frame.dlc,&tx_frame.dataBuff[0],tx_frame.IDFormat,MsgIndex);
#endif
		}
		else
		{
			/*do nothing*/
		}
	}
}
#endif
/**************************************************************************************************
** Function name    : CANIF_TxConfCbk
**
** Description      : Send acknowledgment for data transmission completed.
**
** Parameter        : MailBoxIndex - mail box index of transmission complete message.

** Return value     : None

** Remarks          : None
**************************************************************************************************/
void CANIL_TxConfCbk(uint32_t MsgId)
{
	// CANIL_Msg_st tx_frame;
	uint8 RetVal=0,Msgindex=0;

	/*Get the Index value for the transmitted Msgid*/
	RetVal = CANIL_FindTxRxMsgIndex(MsgId, &Msgindex, CANIL_TXMESG);


	if(CANIL_VALID_CAN_MSG == RetVal)
	{
		/*Initialize the callback function,dlc*/
		(*CANIL_TxRxMessageTable[Msgindex].CalbackFun)(MsgId,CANIL_TxRxMessageTable[Msgindex].MesgDLC,(uint8 *)(CANIL_TxRxMessageTable[Msgindex].DataPtr));
	}
	else
	{
		/* Do nothing */
	}

	/* Clear Tx flag if the message is transmitted from CAN sL layer*/
	/*CanSL_TxCallBack(MsgId,CANIL_TxRxMessageTable[Msgindex].MesgDLC,(uint8 *)(CANIL_TxRxMessageTable[Msgindex].DataPtr));*/

	/*check for pending to transmit */
//	CANIL_TxDeQueue();

}

/**************************************************************************************************
** Function                 : CANIf_Scheduler

** Description              : Schedule the CAN Interaction Layer

** Parameter                : None

** Return value             : None

** Remarks                  : None
**************************************************************************************************/
void CANIL_Scheduler(void)
{

 uint32_t temp = 0;

	/* Check if Tx is enabled */
	if(CANIL_ENABLE == CANT_UDStxVal)
	{
		/*schedule the Tx and Rx CAN message as per the configuration*/
		for(Global_Index = CANIL_INIT_VAL; Global_Index < CANIL_NO_OF_TX_MESSAGES; Global_Index++)
		{
			/* process if msg is Tx type*/
			if ((CANIL_TXMESG == CANIL_TxRxMessageTable[Global_Index].MesgDir) && (CANIL_CYCLIC == CANIL_TxRxMessageTable[Global_Index].TxMethod))
			{
				temp = CANIL_TxRxHndlrCount[Global_Index] ;
				CANIL_TxRxHndlrCount[Global_Index] = (  CANIL_SECHD_TIME + temp);
				
				if  (CANIL_TxRxHndlrCount[Global_Index] >= CANIL_TxRxMessageTable[Global_Index].CycleTime )
				{
					/* Transmit the message */
					CANIL_TransmitMsg(Global_Index);
					/* Reset Transmit handler count */
					CANIL_TxRxHndlrCount[Global_Index] = CANIL_INIT_VAL;
				}
			}
			/* Process Event based message */
			else if ((CANIL_TXMESG == CANIL_TxRxMessageTable[Global_Index].MesgDir) && 
					 (CANIL_EVENT == CANIL_TxRxMessageTable[Global_Index].TxMethod))
			{			
				CANIL_ProcessEventTxn(Global_Index);
			}
			else
			{
				/* do nothing  */
			}
			
		}
	}
	else
	{
		/* Tx is disbaled */
	}
}

/**************************************************************************************************
** Function                 : CANIL_DiagTransmitMsg

** Description              : Transmits the message to CAN driver.

** Parameter                : CANIL_Msg_st tx_frame- Message structure of Tx.

** Return value             : None

** Remarks                  : None
**************************************************************************************************/
void CANIL_DiagTransmitMsg(uint32_t MsgId, uint8_t IDFormat, uint8  DLC, uint8* dataBuff, uint8 ISOTP_CH)
{
#ifndef ASDK_CAN_INTF
	CANIL_Msg_st tx_frame;
	uint32_t TxBuffStatus ;
	uint8_t MsgIndex = CANIL_UINT8_MAX_VAL;
#endif
#ifdef ASDK_CAN_INTF
	(void)IDFormat;
	ISOTP_CHType iso_ch = ISOTP_CH;
#endif
#ifndef ASDK_CAN_INTF
	/*Get the ID to be transmitted */
	tx_frame.MsgID = MsgId;

	/* Get the DLC of the message */
	tx_frame.dlc	= DLC;

	/* Get the message ID format */
	tx_frame.IDFormat	= IDFormat;

	CANIL_FindTxRxMsgIndex(MsgId,&MsgIndex, CANIL_TXMESG);

	/*copy CAN msg payload to Tx buffer */
	memcpy(&tx_frame.dataBuff[CANIL_INIT_VAL],dataBuff,CANIL_MAX_DATA_LENGTH);
#endif
#ifdef  ASDK_CAN_INTF
	(*ISOTP_TxReqConfTable[iso_ch])(MsgId, CANIL_STANDARD, DLC, dataBuff);

#else	
	/* Check for Tx buffer status */
	//TxBuffStatus = CANT_TX_STATE();

	/* Check TxBuffStatus is non zero or not? */
	//if(CAN_TX_IDLE == TxBuffStatus)
	//{
		/* Set Tx message frame to write on CAN Tx line */
		CAN0_TxMsg(tx_frame.MsgID,tx_frame.dlc,&tx_frame.dataBuff[0],tx_frame.IDFormat, MsgIndex);
	//}
	//else
	//{
		/* push the message in queue */
	///	CANIL_EnQueueTxMsg(&tx_frame);
	//}
#endif
}

/**************************************************************************************************
** Function                 : CANIL_TransmitMsg

** Description              : Transmits the message to CAN driver.

** Parameter                : MsgIndex - Message index of Tx message.

** Return value             : None

** Remarks                  : None
**************************************************************************************************/
static void CANIL_TransmitMsg(uint8_t MsgIndex)
{
	CANIL_Msg_st tx_frame;
	// uint32_t TxBuffStatus ;
#ifdef ASDK_CAN_INTF
	ISOTP_CHType iso_ch = ISOTP_CH_CAN_0;
#endif
	/* Update the Tx data buffer frame */
	CANIL_PrepareTxDataBuffer(&tx_frame,MsgIndex);

#ifdef ASDK_CAN_INTF
	(*ISOTP_TxReqConfTable[iso_ch])(tx_frame.MsgID, CANIL_STANDARD, tx_frame.dlc, &tx_frame.dataBuff[0]);

#else	
	/* Check for Tx buffer status */
	//TxBuffStatus = CANT_TX_STATE();

	/* Check TxBuffStatus is non zero or not? */
	//if(CAN_TX_IDLE == TxBuffStatus)
	//{
		/* Set Tx message frame to write on CAN Tx line */
		CAN0_TxMsg(tx_frame.MsgID,tx_frame.dlc,&tx_frame.dataBuff[0],tx_frame.IDFormat, MsgIndex);
	//}
	//else
	///{
		/* push the message in queue */
		//CANIL_EnQueueTxMsg(&tx_frame);
	//}
#endif
}

/**************************************************************************************************
** Function name    : CANIL_PrepareTxDataBuffer
**
** Description      : Prepare Tx data frame to write on CAN bus.
**
** Parameter        : *tx_frame - pointer to prepare Tx data frame.
**					   MsgIndex - Message index
**
** Return value     : None
**
** Remarks          : None
**************************************************************************************************/
static void CANIL_PrepareTxDataBuffer(CANIL_Msg_st *tx_frame, uint8_t MsgIndex)
{
	/*Get the ID to be transmitted */
	tx_frame->MsgID = CANIL_TxRxMessageTable[MsgIndex].MesgID;

	/* Get the DLC of the message */
	tx_frame->dlc	= CANIL_TxRxMessageTable[MsgIndex].MesgDLC;

	/* Get the message ID format */
	tx_frame->IDFormat	= CANIL_TxRxMessageTable[MsgIndex].IDFormat;

	/*copy CAN msg payload to Tx buffer */
	memcpy(&tx_frame->dataBuff[CANIL_INIT_VAL],CANIL_TxRxMessageTable[MsgIndex].DataPtr,CANIL_MAX_DATA_LENGTH);
}

/**************************************************************************************************
** Function name    : CANIL_ProcessEventTxn
**
** Description      : Collect event base message and send write on CAN bus.
**
** Parameter        : Index - Message index of the Tx message

** Return value     : None

** Remarks          : None
***************************************************************************************************/
void CANIL_ProcessEventTxn(uint8_t Index)
{
	/*check event flag for the msg */
	if(CANIL_TRUE == CANIL_TxRxHndlrCount[Index])
	{
		/* Transmit the message */
		CANIL_TransmitMsg(Index);
		/*Clear event flag for respective CAN msg. Each bit represents the respective msg buffer index */
		CANIL_TxRxHndlrCount[Index] = CANIL_FALSE;
	}
	else
	{
		/* Do nothing */
	}
}

/**************************************************************************************************
** Function name    : CANIL_ProcessPeriodicTxn
**
** Description      : Collect periodic message and send write on CAN bus.
**
** Parameter        : Index - Message index of the Tx message.

** Return value     : None

** Remarks          : None
**************************************************************************************************/
void CANIL_ProcessPeriodicTxn(uint8_t Index)
{
	CANIL_TxRxHndlrCount[Index] += MAX_CANIL_SECHD_TIME;
	if (CANIL_TxRxHndlrCount[Index] >= CANIL_TxRxMessageTable[Index].CycleTime )
	{
		/* Transmit the message */
		CANIL_TransmitMsg(Index);
		/* Reset Transmit handler count */
		CANIL_TxRxHndlrCount[Index] = CANIL_INIT_VAL;
	}
}

/**************************************************************************************************
** Function name    : CANIF_TransmitMsgHandlar
**
** Description      : Handle Tx messages (periodic or event base) to write on CAN bus.
**
** Parameter        : Index - Message index of the Tx message

** Return value     : None

** Remarks          : None
**************************************************************************************************/
#ifndef ASDK_CAN_INTF
static void CANIL_TransmitMsgHandlar(uint8_t Index)
{

	uint8_t MsgIndex = CANIL_UINT8_MAX_VAL;
	uint32_t TxBuffStatus;
	CANIL_Msg_st tx_frame;

	/*check for pending to transmit */
	if(CANIL_TxPendingQueueData)
	{
		/*clear the Tx data buffer */
		memset(&tx_frame, CANIL_INIT_VAL, sizeof(CANIL_Msg_st));
		/*Prepare the Tx msg frame */
		CANIL_DeQueueTxMsg(&tx_frame);

		/*search for msg index and if it is valid than try to send the msg */
		if (CANIL_VALID_CAN_MSG == CANIL_FindTxRxMsgIndex(tx_frame.MsgID,&MsgIndex, CANIL_TXMESG))
		{
			/* Check for Tx buffer status */
			TxBuffStatus = CANT_TX_STATE();

			/* check TxBuffStatus is non zero or not? */
			if(CAN_TX_IDLE == TxBuffStatus)
			{
				/* Set Tx message frame to write on CAN Tx line */
				CAN0_TxMsg(tx_frame.MsgID,tx_frame.dlc,&tx_frame.dataBuff[0],tx_frame.IDFormat);
			}
			else
			{
				/* push the message in queue */
				CANIL_EnQueueTxMsg(&tx_frame);
			}
		}
	}

}
#endif

/**************************************************************************************************
** Function                 : CANIL_EnQueueTxMsg

** Description              : Enqueue the message into the Transmit buffer

** Parameter                : *Msg - message pointer to en-queue the message.

** Return value             : None

** Remarks                  : None
**************************************************************************************************/
#ifndef ASDK_CAN_INTF
static void CANIL_EnQueueTxMsg(CANIL_Msg_st *Msg)
{
	if (CANIL_TX_MESGQUEUE_SIZE > CANIL_TxPendingQueueData )
	{
		/* Check for max buffer count */
		if (CANIL_TX_MESGQUEUE_SIZE <= CANIL_TxWrQueueIndex)
		{
			/* roll back the count */
			CANIL_TxWrQueueIndex = CANIL_INIT_VAL;
		}
		else
		{
			/* Do nothing */
		}
		/* Push incoming data into Tx queue */
		memcpy(&CANIL_TxMsgQueue[CANIL_TxWrQueueIndex],Msg,sizeof(CANIL_Msg_st));

		/* increment Tx buffer count for each message push in a queue */
		CANIL_TxWrQueueIndex++;
		/* Increment Tx pending msg count for each message push in a queue */
		CANIL_TxPendingQueueData++;
	}
	else
	{
		/* Do nothing */
	}
}
#endif
/**************************************************************************************************
** Function                 : CANIL_DeQueueTxMsg

** Description              : Dequeue the message into the Tx message buffer

** Parameter                : *Msg - pointer to de-queue message buffer.

** Return value             : None

** Remarks                  : None
**************************************************************************************************/
#ifndef ASDK_CAN_INTF
static void CANIL_DeQueueTxMsg(CANIL_Msg_st *Msg)
{
	/*check  for new CAN messages in Tx queue */
	if(CANIL_INIT_VAL != CANIL_TxPendingQueueData)
	{
		/*clear the Tx queue */
		memcpy(Msg,&CANIL_TxMsgQueue[CANIL_TxRdQueueIndex],sizeof(CANIL_Msg_st));

		/* Increment the Read index of the Transmit Queue for next transmission */
		CANIL_TxRdQueueIndex++;
		if ((CANIL_TX_MESGQUEUE_SIZE <= CANIL_TxRdQueueIndex))
		{
			/* Roll back the index */
			CANIL_TxRdQueueIndex = CANIL_INIT_VAL;
		}

		if (CANIL_TxWrQueueIndex == CANIL_TxRdQueueIndex)
		{
			CANIL_TxWrQueueIndex = CANIL_INIT_VAL;
			CANIL_TxRdQueueIndex = CANIL_INIT_VAL;
		}

		/* Number of CAN msg pending in a Tx queue */
		CANIL_TxPendingQueueData--;
	}
}
#endif
/**************************************************************************************************
** Function name    : CANIL_FindTxRxMsgIndex
**
** Description      : Find message index for requested Tx/Rx Msg.
**
** Parameter        : MsgId - Message ID
**					  *MsgIndex  - Pointer to collect CAN message index

** Return value     : CANIF_VALID_CAN_SIGNAL  or CANIF_INVALID_CAN_SIGNAL

** Remarks          : None
**************************************************************************************************/
static CANIL_MsgValidation_enum CANIL_FindTxRxMsgIndex(uint32_t MsgId, uint8_t *MsgIndex, uint8_t MesgDir)
{
	uint8_t Strt_index;
	uint8_t End_index;
	CANIL_MsgValidation_enum RetVal = CANIL_INVALID_CAN_MSG;

	if (CANIL_RXMESG == MesgDir)
	{
		Strt_index = CANIL_NO_OF_TX_MESSAGES;
		End_index = CANIL_NO_OF_TXRX_MESSAGES;
	}
	else
	{
		Strt_index = CANIL_INIT_VAL;
		End_index = CANIL_NO_OF_TX_MESSAGES;
	}

	/*collect the message index for the requested Tx or Rx Msg ID */
	while (Strt_index < End_index)
	{
		if(CANIL_TxRxMessageTable[Strt_index].MesgID == MsgId )
		{
			(*MsgIndex) = Strt_index;

			Strt_index = End_index;
			RetVal = CANIL_VALID_CAN_MSG;
		}
		else
		{
			/* Do nothing */
		}
		/* Next message */
		Strt_index++;
	}
	return RetVal;
}
/**************************************************************************************************
** Function name    	: CANIL_RxTxCtrl
** Description      	: Controls the Tx and Rx of CAN module.
** Parameter        	: CANIL_Dir->Tx or Rx, CANIL_Ctrl->Enable/Disable
** Return value     	: None
** Remarks          	: None
**************************************************************************************************/
void CANIL_RxTxCtrl(CANIL_UDSmsgMode CANIL_Ctrl,CANIL_UDSmsgVal CANIL_Val)
{
	/*update depend on the CAN Tx or Rx*/
	if(CANIL_Ctrl == CANIL_FLAG_SET){
		CANT_UDStxVal = CANIL_Val;
	}else{
		CANT_UDSRxVal = CANIL_Val;
	}
}
/**************************************************************************************************
** Function name : CANT_EnInterrupt
** Description   : Enable the CAN interrupt
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_EnInterrupt(void)
{
#ifndef ASDK_CAN_INTF
	/* Enable can0 interrupt */
	CANT_EnInterrupt();
#endif
}

/**************************************************************************************************
** Function name : CANT_DisInterrupt
** Description   : Disable the CAN interrupt
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_DisInterrupt(void)
{
#ifndef ASDK_CAN_INTF
	/* Disable can0 interrupt */
	CANT_DisInterrupt();
#endif
}

/**************************************************************************************************
** Function name : CANT_Enable
** Description   : Enable the CAN module
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_Enable(void)
{
#ifndef ASDK_CAN_INTF
	/* Enabling the CAN module */
	CANT_Enable();
#endif
}

/**************************************************************************************************
** Function name : CANT_Disable
** Description   : Disable the CAN module
** Parameter     : void
** Return value  : None
** Remarks       : None
**************************************************************************************************/
void CANIL_Disable(void)
{
#ifndef ASDK_CAN_INTF
	/* Disabling the CAN module */
	CANT_Disable();
#endif
}
