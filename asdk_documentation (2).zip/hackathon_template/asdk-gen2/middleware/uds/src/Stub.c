/***************************************************************************************************
** Copyright (c) 2018 EMBITEL
**
** This software is the property of EMBITEL.
** It can not be used or duplicated without EMBITEL authorization.
**
** -------------------------------------------------------------------------------------------------
** File Name    : Stub.c
** Module name  : 
** -------------------------------------------------------------------------------------------------
** Description : Include file of component Stub.c
**
** -------------------------------------------------------------------------------------------------
**
** Documentation reference : None
**
****************************************************************************************************
** R E V I S I O N  H I S T O R Y
****************************************************************************************************
** V01.00 
** - Baseline Created
**
***************************************************************************************************/
#include "Fcm.h"
#include "FLSHM.h"
#include <stddef.h>
// #include "errordef.h"
/********************** Declaration of local symbol and constants *********************************/
/********************************* Declaration of local macros ************************************/
#define CLEAR_ALL_DTC_IDX   0x00U
/********************************* Declaration of local types *************************************/

/******************************* Declaration of local variables ***********************************/

/******************************* Declaration of local constants ***********************************/

/****************************** Declaration of exported variables *********************************/
extern  asdk_flashm_cbk_t asdk_flashm_cbk;
static bool nvm_dtc_read_done = false;
/****************************** Declaration of exported constants *********************************/

/***************************************************************************************************
**                                      FUNCTIONS                                                 **
***************************************************************************************************/

/**************************** Internal functions declarations *************************************/

/******************************** Function definitions ********************************************/
/***************************************************************************************************
** Function                 : appFcmInitStatus

** Description              : returns TRUE after reading all DTC successfully from NVM

** Parameter                : None

** Return value             : None
***************************************************************************************************/
uint8_t appFcmInitStatus(void)
{
	/* return asynchronous NVM DTC read status */
    return nvm_dtc_read_done;
}

/***************************************************************************************************
** Function                 : APP_FCM_ReadDTCInfo

** Description              : Read snapshot data from NVM at fcm init(power on) time

** Parameter                : base address FCM_DTC_Info and its size

** Return value             : None
***************************************************************************************************/
void APP_FCM_ReadDTCInfo (FCM_DTC_InfoType * FCM_DTC_Info, uint16_t Size)
{

	uint8_t read_status = FALSE; 

    /* Read snapshot data from NVM at fcm init(power on) time */
	if(asdk_fcm_dtc_cbk.asdk_fcm_read_dtc_cbk_fun != NULL) 
	{
		read_status = asdk_fcm_dtc_cbk.asdk_fcm_read_dtc_cbk_fun((void*)FCM_DTC_Info, (uint32)Size, FCM_DTC_INFO);
	}

	/* update read status */
	nvm_dtc_read_done = (!!read_status);

	/* Control return */
	return;
}

/***************************************************************************************************
** Function                 : APP_FCM_ReadDTCSnapShotAddInfo

** Description              : Read snapshot data from NVM at fcm init(power on) time

** Parameter                : base address FCM_DTCSnapShotInfo and its size

** Return value             : None
***************************************************************************************************/
void APP_FCM_ReadDTCSnapShotAddInfo (FCM_DTCSnpShot_Info * FCM_DTC_SnapShot_Info, uint16_t Size)
{

	uint8_t read_status = FALSE; 

    /* Read snapshot data from NVM at fcm init(power on) time */
	if((asdk_fcm_dtc_cbk.asdk_fcm_read_dtc_cbk_fun  != NULL) && ( nvm_dtc_read_done == true))
	{
		read_status = asdk_fcm_dtc_cbk.asdk_fcm_read_dtc_cbk_fun ((void*)FCM_DTC_SnapShot_Info, (uint32)Size, FCM_DTC_SNAP_INFO);
	}

	/* update read status */
	nvm_dtc_read_done = (!!read_status);

	/* Control return */
	return;
}

/***************************************************************************************************
** Function                 : APP_FCM_ReadDTCExtSnapShotAddInfo

** Description              : Read extened snapshot data from NVM at fcm init(power on) time

** Parameter                : base address ofFCM_DTCExtSnapShotInfo and its size

** Return value             : None
***************************************************************************************************/
void APP_FCM_ReadDTCExtSnapShotAddInfo (FCM_DTCExtndSnpsht_Info * FCM_DTC_Ext_SnapShot_Info, uint16_t Size)
{

	uint8_t read_status = FALSE; 

    /* Read extened snapshot data from NVM at fcm init(power on) time */
	if((asdk_fcm_dtc_cbk.asdk_fcm_read_dtc_cbk_fun != NULL) && ( nvm_dtc_read_done == true))
	{
		read_status = asdk_fcm_dtc_cbk.asdk_fcm_read_dtc_cbk_fun ((void*)FCM_DTC_Ext_SnapShot_Info, (uint32)Size, FCM_DTC_EXT_SNAP_INFO);
	}

	/* update read status */
	nvm_dtc_read_done = (!!read_status);

	/* Control return */
	return;
}

/***************************************************************************************************
** Function                 : App_FCM_OpCyclChngUpdt

** Description              : Always return TRUE DTC structure memory is defined by FCM module itself

** Parameter                : DTC_GroupIndex - DTC group index, CycleStatus - operation cycle state

** Return value             : None
***************************************************************************************************/
void App_FCM_OpCyclChngUpdt(eFCM_GroupType DTC_GroupIndex, eFCM_OperationCycleType CycleStatus)
{
	(void)DTC_GroupIndex;
	(void)CycleStatus;
    /* Need to be modified by application engineer according to requirement */
	return;
}

/***************************************************************************************************
** Function                 : App_FCMClearReqDTCUpdate

** Description              : Clear NVM DTC val by DTC Group Number

** Parameter                : DTC_Number - DTC index Number and DTC count

** Return value             : uint8_t - NVM dtc clear status( 1- success, 0- fail )
***************************************************************************************************/
uint8_t App_FCMClearReqDTCUpdate(uint32_t DTC_index_number, uint8_t DTC_count)
{

	uint8_t clear_status = FALSE;

	/* clear the requested DTC */
	if(asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun != NULL)
	{
		/* NVM Clear DTC Info */
		clear_status = asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun(DTC_index_number, (sizeof(FCM_DTC_InfoType) * DTC_count), FCM_DTC_INFO);
				/* NVM Clear DTC SNAPSHOT Info */
		if (clear_status)
			clear_status = asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun(DTC_index_number, (sizeof(FCM_DTCSnpShot_Info) * DTC_count), FCM_DTC_SNAP_INFO);
		
		/* NVM Clear DTC EXTND-SNAPSHOT Info */
		if (clear_status)
			clear_status = asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun(DTC_index_number, (sizeof(FCM_DTCExtndSnpsht_Info) * DTC_count), FCM_DTC_EXT_SNAP_INFO);
	}

	/* return status */
	return clear_status;

}

/***************************************************************************************************
** Function                 : App_FCM_DTC_StatusChange

** Description              : update snapshot, dtc and ext snapshot into nvm after changing DTC status
FCM_DTC_SNAP_INFO
** Parameter                : FCM_DTC_Idx - DTC index 

** Return value             : uint8_t - NVM dtc update status ( 1- success, 0- fail )
***************************************************************************************************/
uint8_t App_FCM_DTC_StatusChange(uint8_t FCM_DTC_Idx)
{

	uint8_t update_status = FALSE; 

	/* update the requested DTC */
	if(asdk_fcm_dtc_cbk.asdk_fcm_update_dtc_cbk_fun != NULL)
	{
		/* NVM update DTC Info */
		update_status = asdk_fcm_dtc_cbk.asdk_fcm_update_dtc_cbk_fun((void*)(&FCM_DTCInfo[FCM_DTC_Idx]),
		 sizeof(FCM_DTC_InfoType), FCM_DTC_Idx, FCM_DTC_INFO);

		/* NVM update DTC SNAPSHOT Info */
		if (update_status)
		{
			update_status = asdk_fcm_dtc_cbk.asdk_fcm_update_dtc_cbk_fun((void*)(&FCM_DTCSnapShotInfo[FCM_DTC_Idx]), 
			sizeof(FCM_DTCSnpShot_Info), FCM_DTC_Idx, FCM_DTC_SNAP_INFO);
		}
		/* NVM update DTC EXTND-SNAPSHOT Info */
		if (update_status)
		{
			update_status = asdk_fcm_dtc_cbk.asdk_fcm_update_dtc_cbk_fun((void*)(&FCM_DTCExtndSnapShotInfo[FCM_DTC_Idx]), 
			sizeof(FCM_DTCExtndSnpsht_Info), FCM_DTC_Idx, FCM_DTC_EXT_SNAP_INFO);
		}
	}
	/* Control return */
	return update_status;
}

/***************************************************************************************************
** Function                 : App_FCMClearAllDTC

** Description              : Erase all NVM DTC val

** Parameter                : None

** Return value             : uint8_t - NVM dtc clear status ( 1- success, 0- fail )
***************************************************************************************************/
uint8_t App_FCMClearAllDTC(void)
{ 

	uint8_t clear_status = FALSE; 

	/* clear the requested DTC */
	if(asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun != NULL)
	{
		/* NVM Clear DTC Info */
		clear_status = asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun(CLEAR_ALL_DTC_IDX, sizeof(FCM_DTCInfo), FCM_DTC_INFO);

		/* NVM Clear DTC SNAPSHOT Info */
		if (clear_status)
			clear_status = asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun(CLEAR_ALL_DTC_IDX, sizeof(FCM_DTCSnapShotInfo), FCM_DTC_SNAP_INFO);
		
		/* NVM Clear DTC EXTND-SNAPSHOT Info */
		if (clear_status)
			clear_status = asdk_fcm_dtc_cbk.asdk_fcm_clear_dtc_cbk_fun(CLEAR_ALL_DTC_IDX, sizeof(FCM_DTCExtndSnapShotInfo), FCM_DTC_EXT_SNAP_INFO);
	}

	/* return status */
	return clear_status;

}
