#include "asdk_app.h"

#include "gpio_app.h"

void app_init(void)
{
    /* system init, do not modify*/
    system_init();

    /* add application init calls */
    gpio_input_init();
    gpio_output_init();

    can_int();
}

void app_loop(void)
{
    for (;;)
    {
        /* system loop, do not modify */
        system_loop();

        /* add application iteration calls */
        gpio_app_iteration();

        /* add application iteration calls */
        can_app_iteration();
    }
}
